package com.example

import com.example.genix.core.EventSystem
import com.example.genix.core.ExecutionMode
import com.example.genix.core.RequestCategory
import com.example.genix.core.VerificationStatus
import com.example.genix.firebase.CrystalXModelId
import com.example.genix.intelligence.coding.CodingEngine
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.genix.intelligence.planning.PlanningEngine
import com.example.genix.intelligence.reasoning.ReasoningEngine
import com.example.genix.models.ModelRegistry
import com.example.genix.router.ModelRouter
import com.example.genix.training.ExperimentalTransformerSpec
import com.example.genix.training.GenixTokenizer
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GenixFoundationUnitTest {

    @Test
    fun `multilingual detector identifies Turkish, English, German, Arabic, Japanese, Chinese`() {
        val tr = MultilingualLanguageSystem.detectLanguage("Merhaba, nasılsın? Türkçe cevap ver.")
        assertEquals("tr", tr.primaryCode)
        assertEquals("tr", tr.explicitSwitchTarget)

        val en = MultilingualLanguageSystem.detectLanguage("Hello, how are you? Please explain FastAPI.")
        assertEquals("en", en.primaryCode)
        assertTrue(en.preservedTechnicalTerms.contains("FastAPI"))

        val de = MultilingualLanguageSystem.detectLanguage("Hallo, wie geht es dir heute?")
        assertEquals("de", de.primaryCode)

        val ar = MultilingualLanguageSystem.detectLanguage("مرحبا كيف حالك")
        assertEquals("ar", ar.primaryCode)

        val ja = MultilingualLanguageSystem.detectLanguage("こんにちは、元気ですか")
        assertEquals("ja", ja.primaryCode)

        val zh = MultilingualLanguageSystem.detectLanguage("你好，请问今天怎么样")
        assertEquals("zh", zh.primaryCode)
    }

    @Test
    fun `reasoning engine solves and verifies arithmetic and linear equations`() {
        val engine = ReasoningEngine()

        val math = engine.evaluate("24 * (15 + 5) + sqrt(144)", "en")
        assertEquals(VerificationStatus.VERIFIED_COMPUTATION, math.verificationStatus)
        assertTrue(math.answer.contains("492"))

        val linear = engine.evaluate("2x + 6 = 20", "tr")
        assertEquals(VerificationStatus.VERIFIED_COMPUTATION, linear.verificationStatus)
        assertTrue(linear.answer.contains("x = 7"))

        val openEnded = engine.evaluate("What is the meaning of consciousness?", "en")
        assertEquals(VerificationStatus.UNSUPPORTED_CAPABILITY, openEnded.verificationStatus)
    }

    @Test
    fun `coding engine detects language, delimiter mismatch, and eval risk`() {
        val coding = CodingEngine()
        val risky = coding.analyzeCode(
            """
            def run_user(data):
                return eval(data
            """.trimIndent(),
            "en"
        )
        assertEquals("Python", risky.detectedLanguage)
        assertFalse(risky.delimitersBalanced)
        assertTrue(risky.securityFindings.any { it.contains("eval") })
    }

    @Test
    fun `genix tokenizer encodes and decodes Turkish and multilingual Unicode losslessly`() {
        val tokenizer = GenixTokenizer()
        val samples = listOf(
            "Merhaba Cloudy! Şğüöçı İÖÜÇŞĞ test.",
            "def f(x): return x ** 2 # PyTorch + FastAPI",
            "Hallo Welt • Bonjour • Hola • مرحبا • 日本語 • 中文"
        )
        for (sample in samples) {
            val report = tokenizer.analyze(sample)
            assertTrue("Round trip failed for: $sample", report.roundTripExactMatch)
            assertEquals(sample, report.decodedText)
        }
    }

    @Test
    fun `model registry blocks unverified checkpoint and router avoids large remote model in cpu mode`() = runTest {
        val events = EventSystem()
        val registry = ModelRegistry(events)
        val blocked = registry.toggleModelLoad("genix-base-nano-15m-exp")
        assertTrue(blocked.isFailure)

        val router = ModelRouter(ReasoningEngine(), CodingEngine(), PlanningEngine(), GenixTokenizer())
        val decision = router.route(
            prompt = "24 * 15 + 4",
            languageCode = "en",
            availableModels = registry.models.value,
            executionMode = ExecutionMode.LOCAL_CPU_FOUNDATION
        )
        assertEquals(RequestCategory.REASONING_MATH, decision.requestCategory)
        assertEquals("genix-reason-ast-v1", decision.selectedModelId)
    }

    @Test
    fun `experimental transformer spec computes positive parameter and memory estimates`() {
        val est = ExperimentalTransformerSpec.estimate(ExperimentalTransformerSpec.presets[1])
        assertTrue(est.totalParameters > 10_000_000L)
        assertTrue(est.fp32WeightsMb > est.fp16WeightsMb)
        assertTrue(est.fp16WeightsMb > est.int8WeightsMb)
    }

    @Test
    fun `cloudy model registry, legacy compatibility, themes, and 19 countries work properly`() {
        val events = EventSystem()
        val registry = ModelRegistry(events)
        val ids = registry.models.value.map { it.metadata.id }
        assertTrue(ids.contains("cloudy-2.0-breeze"))
        assertTrue(ids.contains("cloudy-1.1-neo"))
        assertTrue(ids.contains("cloudy-1.0-pro"))
        assertTrue(ids.contains("cloudy-vision-code"))
        assertTrue(ids.contains("cloudy-voice-live"))
        assertTrue(ids.contains("cloudy-multi-ai"))

        // Current and legacy ID compatibility
        assertEquals(CrystalXModelId.BREEZE_2_0, CrystalXModelId.fromId("cloudy-2.0-breeze"))
        assertEquals(CrystalXModelId.NEO_1_1, CrystalXModelId.fromId("cloudy-1.1-neo"))
        assertEquals(CrystalXModelId.NEO_1_1, CrystalXModelId.fromId("crystalx-1.1-neo"))
        assertEquals(CrystalXModelId.PRO_1_0, CrystalXModelId.fromId("cloudy-1.0-pro"))
        assertEquals(CrystalXModelId.PRO_1_0, CrystalXModelId.fromId("crystalx-1.0-pro"))
        assertEquals(CrystalXModelId.VOICE_LIVE, CrystalXModelId.fromId("cloudy-voice-live"))
        assertEquals(CrystalXModelId.MULTI_AI, CrystalXModelId.fromId("cloudy-multi-ai"))

        // Universal natural studio & API voice personas (plus legacy ID compatibility)
        assertEquals(
            com.example.genix.voice.CloudyVoicePersona.AOEDE,
            com.example.genix.voice.CloudyVoicePersona.fromId("nova_crystal")
        )
        assertEquals(
            com.example.genix.voice.CloudyVoicePersona.CHARON,
            com.example.genix.voice.CloudyVoicePersona.fromId("glacial_titan")
        )
        assertEquals(
            com.example.genix.voice.CloudyVoicePersona.PUCK,
            com.example.genix.voice.CloudyVoicePersona.fromId("cyber_aero")
        )
        assertEquals(
            com.example.genix.voice.CloudyVoicePersona.KORE,
            com.example.genix.voice.CloudyVoicePersona.fromId("velvet_echo")
        )
        assertTrue(com.example.genix.voice.CloudyVoicePersona.entries.size >= 6)

        // Theme tiers
        assertFalse(AppThemeMode.LIGHT_WHITE.isPro)
        assertTrue(AppThemeMode.ICE_CRYSTAL_PRO.isPro)
        assertFalse(AppThemeMode.DARK_OBSIDIAN.isPro)
        assertEquals(AppThemeMode.ICE_CRYSTAL_PRO, AppThemeMode.fromId("ICE_CRYSTAL_PRO"))

        // Country and system language support
        assertTrue(MultilingualLanguageSystem.supportedCountries.size >= 18)
        assertTrue(MultilingualLanguageSystem.resolveSystemLanguageCode().isNotBlank())
        assertTrue(MultilingualLanguageSystem.resolveDefaultCountryCode().isNotBlank())
        assertTrue(MultilingualLanguageSystem.authStrings("en").googleButton.contains("Google"))
        assertTrue(MultilingualLanguageSystem.authStrings("tr").googleButton.contains("Google"))
        assertEquals("Türkiye", MultilingualLanguageSystem.countryForCode("TR").countryName)
    }

    @Test
    fun `subscription plans enforce shared vs plan-exclusive models and oauth providers are configured`() {
        val free = com.example.genix.core.SubscriptionPlan.FREE
        val pro = com.example.genix.core.SubscriptionPlan.PRO
        val ultra = com.example.genix.core.SubscriptionPlan.ULTRA

        // Shared models available on Free, Pro, Ultra
        assertTrue(free.canAccess(CrystalXModelId.BREEZE_2_0))
        assertTrue(free.canAccess(CrystalXModelId.NEO_1_1))
        assertTrue(free.canAccess(CrystalXModelId.LOCAL_CPU))

        // Pro-exclusive models blocked on Free, unlocked on Pro & Ultra
        assertFalse(free.canAccess(CrystalXModelId.PRO_1_0))
        assertFalse(free.canAccess(CrystalXModelId.VISION_CODE))
        assertFalse(free.canAccess(CrystalXModelId.VOICE_LIVE))
        assertTrue(pro.canAccess(CrystalXModelId.PRO_1_0))
        assertTrue(pro.canAccess(CrystalXModelId.VISION_CODE))
        assertTrue(pro.canAccess(CrystalXModelId.VOICE_LIVE))
        assertTrue(ultra.canAccess(CrystalXModelId.PRO_1_0))

        // Ultra-exclusive models blocked on Free & Pro, unlocked on Ultra
        assertFalse(pro.canAccess(CrystalXModelId.MULTI_AI))
        assertFalse(pro.canAccess(CrystalXModelId.DEEPTHINK_ULTRA))
        assertTrue(ultra.canAccess(CrystalXModelId.MULTI_AI))
        assertTrue(ultra.canAccess(CrystalXModelId.DEEPTHINK_ULTRA))

        // Theme gating
        assertTrue(free.canAccessTheme(AppThemeMode.LIGHT_WHITE))
        assertTrue(free.canAccessTheme(AppThemeMode.DARK_OBSIDIAN))
        assertFalse(free.canAccessTheme(AppThemeMode.ICE_CRYSTAL_PRO))
        assertTrue(pro.canAccessTheme(AppThemeMode.ICE_CRYSTAL_PRO))

        // OAuth provider IDs
        assertEquals("github.com", com.example.genix.firebase.SocialAuthProvider.GITHUB.providerId)
        assertEquals("twitter.com", com.example.genix.firebase.SocialAuthProvider.TWITTER.providerId)
        assertEquals("facebook.com", com.example.genix.firebase.SocialAuthProvider.FACEBOOK.providerId)
    }

    @Test
    fun `cloudy model catalog covers all 9 categories and computes availability accurately`() {
        val catalog = com.example.genix.ai.registry.CloudyModelCatalog()
        for (cat in com.example.genix.ai.core.AiModelCategory.entries) {
            val matches = catalog.modelsInCategory(cat)
            assertTrue("Expected at least one model in category $cat", matches.isNotEmpty())
        }

        val proModel = catalog.findById(CrystalXModelId.PRO_1_0.id)
        val openAiModel = catalog.findById("openai-gpt-4o")
        val fastApiModel = com.example.genix.ai.core.CloudyAiModel(
            id = "remote-fastapi-node",
            upstreamModelName = "vllm-qwen-72b",
            displayName = "FastAPI Node",
            shortBadge = "FASTAPI",
            provider = com.example.genix.ai.core.AiProviderKind.REMOTE_FASTAPI,
            category = com.example.genix.ai.core.AiModelCategory.CODING,
            capabilities = com.example.genix.ai.core.ModelCapabilities(),
            speedTier = com.example.genix.ai.core.SpeedTier.TURBO,
            contextWindowTokens = 32_768,
            description = "Self-hosted FastAPI endpoint",
            isDynamicFetched = true
        )
        catalog.registerFetchedModels(com.example.genix.ai.core.AiProviderKind.REMOTE_FASTAPI, listOf(fastApiModel))
        assertEquals("remote-fastapi-node", catalog.findById("remote-fastapi-node").id)

        assertEquals(
            com.example.genix.ai.core.ModelAvailabilityStatus.PLAN_LOCKED,
            catalog.availabilityFor(proModel, com.example.genix.core.SubscriptionPlan.FREE, emptyMap(), "")
        )
        assertEquals(
            com.example.genix.ai.core.ModelAvailabilityStatus.READY,
            catalog.availabilityFor(proModel, com.example.genix.core.SubscriptionPlan.PRO, emptyMap(), "")
        )
        assertEquals(
            com.example.genix.ai.core.ModelAvailabilityStatus.KEY_REQUIRED,
            catalog.availabilityFor(openAiModel, com.example.genix.core.SubscriptionPlan.FREE, emptyMap(), "")
        )
        val openAiCreds = mapOf(
            com.example.genix.ai.core.AiProviderKind.OPENAI to
                com.example.genix.ai.security.ProviderCredentialRecord(
                    provider = com.example.genix.ai.core.AiProviderKind.OPENAI,
                    apiKey = "test-placeholder-key"
                )
        )
        assertEquals(
            com.example.genix.ai.core.ModelAvailabilityStatus.READY,
            catalog.availabilityFor(openAiModel, com.example.genix.core.SubscriptionPlan.FREE, openAiCreds, "")
        )
        assertEquals(
            com.example.genix.ai.core.ModelAvailabilityStatus.REMOTE_CONFIG_NEEDED,
            catalog.availabilityFor(fastApiModel, com.example.genix.core.SubscriptionPlan.FREE, emptyMap(), "")
        )
        assertEquals(
            com.example.genix.ai.core.ModelAvailabilityStatus.READY,
            catalog.availabilityFor(fastApiModel, com.example.genix.core.SubscriptionPlan.FREE, emptyMap(), "https://node.example.com")
        )
    }

    @Test
    fun `intelligent model router respects manual mode, auto-upgrades for vision, and routes coding intents`() {
        val catalog = com.example.genix.ai.registry.CloudyModelCatalog()
        val router = com.example.genix.ai.routing.IntelligentModelRouter(catalog)
        val localCpu = catalog.findById(CrystalXModelId.LOCAL_CPU.id)
        val breeze = catalog.findById(CrystalXModelId.BREEZE_2_0.id)

        // Manual mode keeps non-image requests on selected model
        val manualDecision = router.resolveModelForTurn(
            prompt = "Write a Python binary search",
            selectedModel = breeze,
            autoRouteEnabled = false,
            hasImages = false,
            hasDocument = false,
            codingMode = true,
            plan = com.example.genix.core.SubscriptionPlan.PRO,
            credentials = emptyMap(),
            fastApiUrl = ""
        )
        assertFalse(manualDecision.wasAutoSwitched)
        assertEquals(breeze.id, manualDecision.selectedModel.id)

        // Manual mode upgrades non-vision model when photo is attached
        val visionUpgrade = router.resolveModelForTurn(
            prompt = "Describe this diagram",
            selectedModel = localCpu,
            autoRouteEnabled = false,
            hasImages = true,
            hasDocument = false,
            codingMode = false,
            plan = com.example.genix.core.SubscriptionPlan.PRO,
            credentials = emptyMap(),
            fastApiUrl = ""
        )
        assertTrue(visionUpgrade.wasAutoSwitched)
        assertTrue(visionUpgrade.selectedModel.capabilities.visionInput)

        // Auto-route selects Vision+Code for coding intent on PRO plan
        val autoCoding = router.resolveModelForTurn(
            prompt = "Refactor this Kotlin coroutine ViewModel bug",
            selectedModel = breeze,
            autoRouteEnabled = true,
            hasImages = false,
            hasDocument = false,
            codingMode = true,
            plan = com.example.genix.core.SubscriptionPlan.PRO,
            credentials = emptyMap(),
            fastApiUrl = ""
        )
        assertEquals(com.example.genix.ai.core.AiModelCategory.CODING, autoCoding.detectedCategory)
        assertEquals(CrystalXModelId.VISION_CODE.id, autoCoding.selectedModel.id)
    }

    @Test
    fun `markdown parser structures headings, code blocks, quotes, bullets, and dividers`() {
        val sample = """
            # Cloudy Heading
            Here is a concise summary paragraph.

            > Important quote line

            - First bullet point
            1. Ordered item

            ```kotlin
            fun greet() = "Cloudy"
            ```

            ---
        """.trimIndent()

        val blocks = com.example.ui.components.MarkdownParser.parse(sample)
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Heading && it.level == 1 && it.text == "Cloudy Heading" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Paragraph && it.text.contains("concise summary") })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Quote && it.text == "Important quote line" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.BulletItem && it.text == "First bullet point" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.CodeBlock && it.language == "kotlin" && it.code.contains("greet") })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Divider })
    }

    @Test
    fun `markdown parser handles h1-h6, setext headers, nested task lists, tables, tilde fences, and unclosed streaming blocks`() {
        val advanced = """
            Setext Title
            ============

            ## Subheader
            ###### Level Six

            > Quote line 1
            > Quote line 2

            - [x] Done task
              - Nested bullet with **bold** and `inline_fn()`
                - Deep nested item
            1. Ordered step one

            | Model | Speed |
            | --- | --- |
            | Breeze 2.0 | Turbo |

            ~~~python
            def hello_world():
                return True
            ~~~

            ```kotlin
            val streaming = "still open
        """.trimIndent()

        val blocks = com.example.ui.components.MarkdownParser.parse(advanced)
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Heading && it.level == 1 && it.text == "Setext Title" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Heading && it.level == 2 && it.text == "Subheader" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Heading && it.level == 6 && it.text == "Level Six" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Quote && it.text == "Quote line 1\nQuote line 2" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.BulletItem && it.isChecked == true && it.text == "Done task" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.BulletItem && it.indentLevel == 1 && it.prefix == "◦" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.BulletItem && it.indentLevel == 2 && it.prefix == "▪" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.BulletItem && it.prefix == "1." && it.text == "Ordered step one" })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.Table && it.headers == listOf("Model", "Speed") && it.rows.first() == listOf("Breeze 2.0", "Turbo") })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.CodeBlock && it.language == "python" && it.code.contains("hello_world") })
        assertTrue(blocks.any { it is com.example.ui.components.MarkdownBlock.CodeBlock && it.language == "kotlin" && it.code.contains("still open") })
    }

    @Test
    fun `inline markdown parser formats bold, italic, strikethrough, inline code, links and preserves snake_case`() {
        val annotated = com.example.ui.components.parseInlineMarkdown(
            text = "Use **bold**, __alsoBold__, *italic*, ~~old~~, `val x = 1`, [Cloudy](https://cloudy.example.com), and my_snake_case_var",
            accent = androidx.compose.ui.graphics.Color.Cyan,
            codeBg = androidx.compose.ui.graphics.Color.DarkGray
        )
        val plain = annotated.text
        assertTrue(plain.contains("bold"))
        assertTrue(plain.contains("alsoBold"))
        assertTrue(plain.contains("italic"))
        assertTrue(plain.contains("old"))
        assertTrue(plain.contains("val x = 1"))
        assertTrue(plain.contains("Cloudy"))
        assertTrue(plain.contains("my_snake_case_var"))
        assertFalse(plain.contains("**bold**"))
        assertFalse(plain.contains("~~old~~"))
        assertTrue(annotated.spanStyles.any { it.item.fontWeight == androidx.compose.ui.text.font.FontWeight.Bold })
        assertTrue(annotated.spanStyles.any { it.item.fontStyle == androidx.compose.ui.text.font.FontStyle.Italic })
        assertTrue(annotated.spanStyles.any { it.item.textDecoration == androidx.compose.ui.text.style.TextDecoration.LineThrough })
        assertTrue(annotated.getLinkAnnotations(0, plain.length).isNotEmpty())
    }

    @Test
    fun `live state enum covers all 8 lifecycle states and system theme is registered`() {
        assertEquals(8, com.example.genix.ai.live.LiveConnectionState.entries.size)
        assertTrue(com.example.genix.ai.live.LiveTransportBackend.FIREBASE_GEMINI_LIVE.isNativeBidirectional)
        assertFalse(com.example.genix.ai.live.LiveTransportBackend.TURN_BASED_FALLBACK.isNativeBidirectional)

        assertEquals(AppThemeMode.SYSTEM, AppThemeMode.fromId("SYSTEM"))
        assertFalse(AppThemeMode.SYSTEM.isPro)

        val enHome = MultilingualLanguageSystem.homeStrings("en")
        val trHome = MultilingualLanguageSystem.homeStrings("tr")
        assertTrue(enHome.greetingTitle.contains("Cloudy"))
        assertTrue(trHome.greetingTitle.contains("Cloudy"))
        assertFalse(enHome.greetingSubtitle == trHome.greetingSubtitle)
    }
}
