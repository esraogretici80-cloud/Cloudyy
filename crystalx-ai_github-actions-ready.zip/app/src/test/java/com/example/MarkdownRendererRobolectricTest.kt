package com.example

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import com.example.ui.components.RichMarkdownText
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.GenixTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MarkdownRendererRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `rich markdown text renders headers, bold text, lists, tables, and code blocks`() {
        composeTestRule.setContent {
            GenixTheme(themeMode = AppThemeMode.LIGHT_WHITE) {
                Box(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    RichMarkdownText(
                        markdown = """
                            # Cloudy Response Header
                            Here is **critical** guidance with `inlineCode()`.

                            - Bullet item one
                            1. Numbered step

                            | Feature | Status |
                            | --- | --- |
                            | Markdown | Ready |

                            ```kotlin
                            fun cloudyReady(): Boolean = true
                            ```
                        """.trimIndent(),
                        selectable = true
                    )
                }
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("rich_markdown_root").assertIsDisplayed()
        composeTestRule.onNodeWithTag("markdown_heading_1").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Cloudy Response Header").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("markdown_table").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("markdown_code_block").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("copy_code_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("KOTLIN").performScrollTo().assertIsDisplayed()
    }
}
