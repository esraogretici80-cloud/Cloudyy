package com.example

import android.graphics.Bitmap
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.core.app.ApplicationProvider
import com.example.genix.ai.core.ModelAvailabilityStatus
import com.example.genix.ai.registry.CloudyModelCatalog
import com.example.genix.core.GenixConfig
import com.example.genix.firebase.AppCheckDiagnostics
import com.example.genix.firebase.CloudMessage
import com.example.genix.firebase.CrystalXModelId
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.genix.voice.VoicePlaybackState
import com.example.ui.UiState
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CoreConsoleScreen
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.GenixTheme
import com.google.firebase.FirebaseApp
import java.io.File
import java.io.FileOutputStream
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

/**
 * Renders the redesigned sign-in and chat screens. Set CLOUDY_SHOTS_DIR to also save PNG screenshots.
 */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36], qualifiers = "w390dp-h844dp-xxhdpi")
class ChatGptStyleScreensRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<androidx.activity.ComponentActivity>()

    @Before
    fun initFirebase() {
        val ctx = ApplicationProvider.getApplicationContext<android.content.Context>()
        if (FirebaseApp.getApps(ctx).isEmpty()) FirebaseApp.initializeApp(ctx)
    }

    private fun saveShot(name: String) {
        val dir = System.getenv("CLOUDY_SHOTS_DIR") ?: return
        composeTestRule.mainClock.advanceTimeBy(1500)
        var bmp: Bitmap? = null
        composeTestRule.runOnIdle {
            val view = composeTestRule.activity.window.decorView
            val b = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(b))
            bmp = b
        }
        val out = bmp ?: return
        File(dir).mkdirs()
        FileOutputStream(File(dir, "$name.png")).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    @Test
    fun `sign in screen shows four providers and no setup hints`() {
        composeTestRule.setContent {
            GenixTheme(themeMode = AppThemeMode.LIGHT_WHITE) { AuthScreen(onAuthSuccess = {}) }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("github_sign_in_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("twitter_sign_in_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("facebook_sign_in_button").assertIsDisplayed()
        composeTestRule.onNodeWithText("Firebase Auth + Isolated Cloud Vault").assertDoesNotExist()
        composeTestRule.onNodeWithText("App Check Guard").assertDoesNotExist()
        saveShot("auth_light")
    }

    @Test
    fun `sign in screen dark`() {
        composeTestRule.setContent {
            GenixTheme(themeMode = AppThemeMode.DARK_OBSIDIAN) { AuthScreen(onAuthSuccess = {}) }
        }
        composeTestRule.waitForIdle()
        saveShot("auth_dark")
    }

    private fun chat(messages: List<CloudMessage>, theme: AppThemeMode, shot: String, streaming: String? = null) {
        val models = CloudyModelCatalog().models.value
        val active = models.first { it.id == CrystalXModelId.BREEZE_2_0.id }
        composeTestRule.setContent {
            GenixTheme(themeMode = theme) {
                CoreConsoleScreen(
                    uiStrings = MultilingualLanguageSystem.uiStrings("tr"),
                    homeStrings = MultilingualLanguageSystem.homeStrings("tr"),
                    config = GenixConfig(themeMode = theme),
                    selectedModel = CrystalXModelId.BREEZE_2_0,
                    activePlatformModel = active,
                    platformModels = models,
                    availabilityProvider = { ModelAvailabilityStatus.READY },
                    conversationsState = UiState.Success(emptyList()),
                    activeConversationId = null,
                    cloudMessagesState = UiState.Success(messages),
                    streamingText = streaming,
                    streamingModelLabel = null,
                    attachedIntegrationNotes = emptyList(),
                    attachedImages = emptyList(),
                    attachedDocument = null,
                    webSearchEnabled = false,
                    codingModeEnabled = false,
                    hasAppCheckIssue = true,
                    appCheckDiagnostics = AppCheckDiagnostics(),
                    isProcessing = streaming != null,
                    voicePlaybackState = VoicePlaybackState(),
                    estimateTokens = { it.length / 4 },
                    onSelectModel = {}, onSelectPlatformModel = {}, onToggleAutoRoute = {},
                    onSpeakMessage = {}, onStopSpeaking = {}, onVerifyAppCheck = {}, onCycleTheme = {},
                    onSelectConversation = {}, onCreateConversation = {}, onRenameConversation = { _, _ -> },
                    onToggleConversationPin = {}, onDeleteConversation = {}, onToggleMessageStar = {},
                    onSendToWebhooks = {}, onEditUserMessageAndResend = { _, _ -> }, onRegenerateMessage = {},
                    onContinueMessage = {}, onStopGeneration = {}, onClearAttachedNotes = {},
                    onAttachImagesUris = {}, onClearAttachedImages = {}, onAttachDocumentUri = {},
                    onClearAttachedDocument = {}, onToggleWebSearch = {}, onToggleCodingMode = {},
                    onOpenLiveVoice = {}, onOpenImageStudio = {}, onSendPrompt = {},
                    onOpenDrawer = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        saveShot(shot)
    }

    @Test
    fun `empty chat shows chatgpt style home without app check banner`() {
        chat(emptyList(), AppThemeMode.LIGHT_WHITE, "chat_empty_light")
        composeTestRule.onNodeWithTag("history_drawer_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("model_selector_pill").assertIsDisplayed()
        composeTestRule.onNodeWithTag("new_thread_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("composer_live_button").assertIsDisplayed()
        composeTestRule.onNodeWithText("Refresh").assertDoesNotExist()
    }

    @Test
    fun `conversation renders user bubble and assistant text`() {
        val msgs = listOf(
            CloudMessage(id = "1", role = "user", content = "İstanbul'da hafta sonu ne yapabilirim?"),
            CloudMessage(
                id = "2", role = "assistant", modelLabel = "Cloudy 2.0 Breeze",
                content = "İşte hafta sonu için birkaç öneri:\n\n- **Balat** sokaklarında yürüyüş yapın\n- Boğaz'da vapur turuna çıkın\n- Karaköy'de kahvaltı edin\n\nHangisini daha detaylı anlatmamı istersiniz?"
            ),
            CloudMessage(id = "3", role = "user", content = "Vapur turu hakkında bilgi ver")
        )
        chat(msgs, AppThemeMode.LIGHT_WHITE, "chat_conversation_light", streaming = "Boğaz vapur turları Eminönü'nden")
    }

    @Test
    fun `conversation dark`() {
        val msgs = listOf(
            CloudMessage(id = "1", role = "user", content = "Kotlin'de coroutine nedir?"),
            CloudMessage(id = "2", role = "assistant", modelLabel = "Cloudy 2.0 Breeze", content = "**Coroutine**, hafif iş parçacıklarıdır.\n\n```kotlin\nlaunch { delay(1000) }\n```")
        )
        chat(msgs, AppThemeMode.DARK_OBSIDIAN, "chat_conversation_dark")
    }
}
