package com.example

import com.example.genix.firebase.CrystalXModelId
import com.example.genix.firebase.normalizeHistoryTurns
import com.example.ui.builder.BuilderArtifacts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CloudyBuilderAndHistoryUnitTest {

    @Test
    fun `history merges same-role turns and starts with user and ends with model`() {
        val result = normalizeHistoryTurns(
            listOf(
                "assistant" to "hello from model",
                "user" to "first",
                "user" to "second",
                "assistant" to "answer",
                "assistant" to "more answer",
                "user" to "   ",
                "user" to "dangling question"
            )
        )
        assertEquals(listOf("user", "model"), result.map { it.first })
        assertEquals("first\n\nsecond", result[0].second)
        assertEquals("answer\n\nmore answer", result[1].second)
    }

    @Test
    fun `history of only a user turn becomes empty`() {
        assertTrue(normalizeHistoryTurns(listOf("user" to "hi")).isEmpty())
    }

    @Test
    fun `builder model id resolves`() {
        assertEquals(CrystalXModelId.BUILDER_3_0, CrystalXModelId.fromId("cloudy-3.0-builder"))
    }

    @Test
    fun `builder extracts html block and title`() {
        val md = """
            Here is your game:
            ```html
            <!DOCTYPE html>
            <html><head><title>Snake Game</title></head><body><canvas id="c"></canvas><script>1+1</script></body></html>
            ```
            Have fun!
        """.trimIndent()
        val html = BuilderArtifacts.extractRunnableHtml(md)
        assertNotNull(html)
        assertEquals("Snake Game", BuilderArtifacts.titleOf(html!!))
    }

    @Test
    fun `builder ignores non-html code blocks`() {
        val md = "```kotlin\nfun main() { println(\"<div>\") }\n```"
        assertNull(BuilderArtifacts.extractRunnableHtml(md))
    }
}
