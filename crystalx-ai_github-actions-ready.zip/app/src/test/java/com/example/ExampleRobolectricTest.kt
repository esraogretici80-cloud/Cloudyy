package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name matches Cloudy`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Cloudy", appName)
    }

    @Test
    fun `cold start without signed in user renders Cloudy AuthScreen with multi-provider logins`() {
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("Cloudy", substring = true).performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("google_sign_in_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("github_sign_in_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("twitter_sign_in_button").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("facebook_sign_in_button").performScrollTo().assertIsDisplayed()
        // The sign-in screen is intentionally clean: no model badges or provider setup hints.
        composeTestRule.onNodeWithText("2.0 BREEZE").assertDoesNotExist()
        composeTestRule.onNodeWithText("DEEPTHINK ULTRA").assertDoesNotExist()
    }

    @Test
    fun `auth screen Google button and Cloudy subtitle are accessible`() {
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("google_sign_in_button").assertExists()
        composeTestRule.onNodeWithTag("github_sign_in_button").assertExists()
        composeTestRule.onNodeWithTag("twitter_sign_in_button").assertExists()
        composeTestRule.onNodeWithTag("facebook_sign_in_button").assertExists()
    }
}
