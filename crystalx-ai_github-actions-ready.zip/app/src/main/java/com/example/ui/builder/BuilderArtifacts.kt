package com.example.ui.builder

/**
 * Extracts a runnable single-file HTML document from an assistant markdown message
 * (Cloudy 3.0 Builder output: games, 3D scenes, calculators, small web apps).
 */
object BuilderArtifacts {

    private val fencedBlock = Regex("```([A-Za-z0-9_+-]*)[ \\t]*\\r?\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)
    private val htmlStart = Regex("^\\s*(<!doctype\\s+html|<html[\\s>])", RegexOption.IGNORE_CASE)
    private val htmlMarkers = listOf("<body", "<canvas", "<script", "<div", "<main", "<section", "<svg", "<style")
    private val titleTag = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    /** Returns the HTML of the best runnable ```html block in [content], or null if there is none. */
    fun extractRunnableHtml(content: String): String? {
        if (content.isBlank()) return null
        var best: String? = null
        for (match in fencedBlock.findAll(content)) {
            val lang = match.groupValues[1].lowercase()
            val body = match.groupValues[2].trim()
            if (body.isEmpty()) continue
            val isHtmlLang = lang == "html" || lang == "htm"
            val looksLikeDocument = lang.isEmpty() && htmlStart.containsMatchIn(body)
            if ((isHtmlLang || looksLikeDocument) && isRunnable(body)) {
                // Prefer the longest block when the model emits several.
                if (best == null || body.length > best.length) best = body
            }
        }
        return best
    }

    /** Human-readable title: the <title> tag of the document, or [fallback]. */
    fun titleOf(html: String, fallback: String = "Cloudy Builder"): String {
        val raw = titleTag.find(html)?.groupValues?.getOrNull(1)?.trim().orEmpty()
        return raw.replace(Regex("\\s+"), " ").take(60).ifBlank { fallback }
    }

    private fun isRunnable(html: String): Boolean {
        if (html.length < 20) return false
        val lower = html.lowercase()
        return htmlStart.containsMatchIn(html) || htmlMarkers.any { lower.contains(it) }
    }
}
