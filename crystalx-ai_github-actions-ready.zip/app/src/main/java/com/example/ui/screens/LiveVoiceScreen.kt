package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.genix.ai.live.LiveConnectionState
import com.example.genix.ai.live.LiveSessionTelemetry
import com.example.genix.intelligence.language.LiveUiStrings
import com.example.genix.voice.CloudyVoicePersona
import com.example.ui.components.RichMarkdownText
import com.example.ui.components.TelemetryChip
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCloudyStyle
import com.example.ui.theme.RoseError
import java.util.Locale

@Composable
fun LiveVoiceScreen(
    telemetry: LiveSessionTelemetry,
    activePersona: CloudyVoicePersona,
    liveStrings: LiveUiStrings,
    hasOpenAiKey: Boolean,
    preferOpenAiRealtime: Boolean,
    onToggleOpenAiRealtime: (Boolean) -> Unit,
    onSelectPersona: (CloudyVoicePersona) -> Unit,
    onStartSession: () -> Unit,
    onToggleMute: () -> Unit,
    onInterrupt: () -> Unit,
    onReconnect: () -> Unit,
    onEndSession: () -> Unit,
    onNavigateBack: () -> Unit
) {
    BackHandler {
        onNavigateBack()
    }

    val context = LocalContext.current
    val cloudyStyle = LocalCloudyStyle.current
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            onStartSession()
        }
    }

    val transcriptListState = rememberLazyListState()
    LaunchedEffect(telemetry.transcripts.size) {
        if (telemetry.transcripts.isNotEmpty()) {
            transcriptListState.animateScrollToItem(telemetry.transcripts.lastIndex)
        }
    }

    val isActiveSession = telemetry.connectionState in setOf(
        LiveConnectionState.CONNECTING,
        LiveConnectionState.LISTENING,
        LiveConnectionState.PROCESSING,
        LiveConnectionState.SPEAKING,
        LiveConnectionState.INTERRUPTED,
        LiveConnectionState.RECONNECTING
    )

    val stateLabel = when (telemetry.connectionState) {
        LiveConnectionState.IDLE -> liveStrings.idleHint
        LiveConnectionState.CONNECTING -> liveStrings.connectingLabel
        LiveConnectionState.LISTENING -> liveStrings.listeningLabel
        LiveConnectionState.PROCESSING -> liveStrings.processingLabel
        LiveConnectionState.SPEAKING -> liveStrings.speakingLabel
        LiveConnectionState.INTERRUPTED -> liveStrings.interruptedLabel
        LiveConnectionState.RECONNECTING -> liveStrings.reconnectingLabel
        LiveConnectionState.ERROR -> liveStrings.errorLabel
    }

    val orbTargetColor by animateColorAsState(
        targetValue = when (telemetry.connectionState) {
            LiveConnectionState.LISTENING -> MaterialTheme.colorScheme.primary
            LiveConnectionState.SPEAKING -> EmeraldVerified
            LiveConnectionState.PROCESSING -> Color(0xFF6366F1)
            LiveConnectionState.INTERRUPTED, LiveConnectionState.RECONNECTING, LiveConnectionState.CONNECTING -> AmberWarning
            LiveConnectionState.ERROR -> RoseError
            LiveConnectionState.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
        },
        label = "orb_color"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "live_orb_pulse")
    val idleBreath by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    val audioEnergy = maxOf(telemetry.micLevel, telemetry.speakerLevel)
    val animatedScale by animateFloatAsState(
        targetValue = if (isActiveSession) (1f + audioEnergy * 0.24f) * idleBreath else 1f,
        label = "orb_scale"
    )

    val mins = telemetry.elapsedSeconds / 60L
    val secs = telemetry.elapsedSeconds % 60L
    val formattedTimer = String.format(Locale.US, "%02d:%02d", mins, secs)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(cloudyStyle.backgroundBrush)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("live_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = liveStrings.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = telemetry.backend.displayName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                TelemetryChip(
                    label = "${telemetry.connectionState.name} • $formattedTimer",
                    accent = orbTargetColor
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Voice Persona & Transport Selector
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(
                    CloudyVoicePersona.entries.filter { it != CloudyVoicePersona.CUSTOM_API },
                    key = { it.id }
                ) { persona ->
                    FilterChip(
                        selected = persona == activePersona,
                        onClick = { onSelectPersona(persona) },
                        label = { Text(persona.displayName) }
                    )
                }
                if (hasOpenAiKey) {
                    item {
                        FilterChip(
                            selected = preferOpenAiRealtime,
                            onClick = { onToggleOpenAiRealtime(!preferOpenAiRealtime) },
                            label = { Text("OpenAI Realtime WS") }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Central Animated Audio Orb
            Box(
                modifier = Modifier.size(196.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val baseR = (size.minDimension / 2f) * 0.62f * animatedScale
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                orbTargetColor.copy(alpha = 0.28f),
                                orbTargetColor.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = baseR * 1.48f
                        ),
                        radius = baseR * 1.48f,
                        center = center
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                orbTargetColor.copy(alpha = 0.92f),
                                orbTargetColor.copy(alpha = 0.48f)
                            ),
                            center = center,
                            radius = baseR
                        ),
                        radius = baseR,
                        center = center
                    )
                }
                Icon(
                    imageVector = Icons.Filled.GraphicEq,
                    contentDescription = "Live Voice State",
                    tint = Color.White,
                    modifier = Modifier.size(44.dp)
                )
            }

            Text(
                text = stateLabel,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Dynamic 24-Bar Real-Time Waveform
            Row(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .height(34.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                telemetry.waveformBars.forEach { bar ->
                    val h by animateDpAsState(targetValue = (4f + bar * 28f).dp, label = "live_wave")
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(h)
                            .clip(RoundedCornerShape(3.dp))
                            .background(orbTargetColor.copy(alpha = if (isActiveSession) 0.85f else 0.3f))
                    )
                }
            }

            if (!telemetry.errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = RoseError.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, RoseError.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = telemetry.errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = RoseError,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onReconnect) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Reconnect", tint = RoseError)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Transcripts Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    Text(
                        text = liveStrings.transcriptTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontFamily = JetBrainsMonoFontFamily
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    if (telemetry.transcripts.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = liveStrings.noTranscriptHint,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            state = transcriptListState,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(telemetry.transcripts, key = { it.id }) { entry ->
                                val isUser = entry.role == "user"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (isUser) {
                                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                        },
                                        modifier = Modifier.widthIn(max = 520.dp)
                                    ) {
                                        if (isUser) {
                                            Text(
                                                text = entry.text,
                                                style = MaterialTheme.typography.bodyMedium,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                            )
                                        } else {
                                            RichMarkdownText(
                                                markdown = entry.text,
                                                textColor = MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Control Dock
            if (!hasMicPermission) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = AmberWarning.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, AmberWarning),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = liveStrings.permissionRequired,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                            Text(liveStrings.grantMicButton)
                        }
                    }
                }
            } else if (!isActiveSession) {
                Button(
                    onClick = onStartSession,
                    shape = CircleShape,
                    modifier = Modifier
                        .height(56.dp)
                        .fillMaxWidth(0.75f)
                        .testTag("live_start_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(liveStrings.startCallLabel, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FilledIconButton(
                            onClick = onToggleMute,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = if (telemetry.isMuted) AmberWarning else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.size(56.dp).testTag("live_mute_button")
                        ) {
                            Icon(
                                imageVector = if (telemetry.isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                                contentDescription = liveStrings.muteLabel
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (telemetry.isMuted) liveStrings.unmuteLabel else liveStrings.muteLabel,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    if (telemetry.connectionState == LiveConnectionState.SPEAKING) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(
                                onClick = onInterrupt,
                                shape = CircleShape,
                                modifier = Modifier.height(52.dp).testTag("live_interrupt_button")
                            ) {
                                Icon(Icons.Filled.PanTool, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(liveStrings.interruptLabel)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FilledIconButton(
                            onClick = onEndSession,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = RoseError,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.size(56.dp).testTag("live_end_button")
                        ) {
                            Icon(Icons.Filled.CallEnd, contentDescription = liveStrings.endCallLabel)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(liveStrings.endCallLabel, style = MaterialTheme.typography.labelSmall, color = RoseError)
                    }
                }
            }
        }
    }
}
