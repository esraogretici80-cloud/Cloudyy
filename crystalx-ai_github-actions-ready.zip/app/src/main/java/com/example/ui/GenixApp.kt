package com.example.ui

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.credentials.CredentialManager
import com.example.genix.firebase.AuthHelper
import com.example.ui.components.CloudyDrawerContent
import com.example.ui.components.SecondaryPageTopBar
import kotlinx.coroutines.launch
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.genix.ai.core.AiProviderKind
import com.example.genix.core.GenixConfig
import com.example.genix.core.GenixConfigRepository
import com.example.genix.core.SubscriptionPlan
import com.example.genix.voice.CloudyVoicePersona
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ControlPlaneScreen
import com.example.ui.screens.CoreConsoleScreen
import com.example.ui.screens.LabMemoryScreen
import com.example.ui.screens.LiveVoiceScreen
import com.example.ui.screens.ModelsRouterScreen
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.GenixTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth

object GenixRoutes {
    const val ROUTE_CORE = "core"
    const val ROUTE_MODELS = "models"
    const val ROUTE_LAB = "lab"
    const val ROUTE_SYSTEM = "system"
    const val ROUTE_LIVE = "live"
}

private data class NavDestinationItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun GenixApp() {
    val auth = remember { Firebase.auth }
    var currentUser by remember { mutableStateOf<FirebaseUser?>(auth.currentUser) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    val signedInUser = currentUser
    if (signedInUser == null) {
        val context = LocalContext.current
        val localRepo = remember(context) { GenixConfigRepository(context) }
        val previewConfig by localRepo.configFlow.collectAsStateWithLifecycle(
            initialValue = GenixConfig(themeMode = AppThemeMode.SYSTEM)
        )
        GenixTheme(themeMode = previewConfig.themeMode) {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                }
            )
        }
    } else {
        val app = LocalContext.current.applicationContext as Application
        key(signedInUser.uid) {
            val viewModel: GenixViewModel = viewModel(
                key = signedInUser.uid,
                factory = GenixViewModelFactory(app, signedInUser.uid)
            )
            AuthenticatedCloudyApp(viewModel = viewModel)
        }
    }
}

@Composable
private fun AuthenticatedCloudyApp(viewModel: GenixViewModel) {
    val config by viewModel.config.collectAsStateWithLifecycle()
    val uiStrings by viewModel.uiStrings.collectAsStateWithLifecycle()
    val homeStrings by viewModel.homeStrings.collectAsStateWithLifecycle()
    val liveStrings by viewModel.liveStrings.collectAsStateWithLifecycle()

    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val activePlatformModel by viewModel.activePlatformModel.collectAsStateWithLifecycle()
    val platformModels by viewModel.platformModels.collectAsStateWithLifecycle()
    val providerCredentials by viewModel.providerCredentials.collectAsStateWithLifecycle()

    val conversationsState by viewModel.conversations.collectAsStateWithLifecycle()
    val activeConversationId by viewModel.activeConversationId.collectAsStateWithLifecycle()
    val cloudMessagesState by viewModel.cloudMessages.collectAsStateWithLifecycle()
    val cloudMemoriesState by viewModel.cloudMemories.collectAsStateWithLifecycle()
    val knowledgeDocuments by viewModel.knowledgeDocuments.collectAsStateWithLifecycle()
    val integrationsState by viewModel.integrationsState.collectAsStateWithLifecycle()
    val runningIntegrationId by viewModel.runningIntegrationId.collectAsStateWithLifecycle()
    val attachedIntegrationNotes by viewModel.attachedIntegrationNotes.collectAsStateWithLifecycle()
    val attachedImages by viewModel.attachedImages.collectAsStateWithLifecycle()
    val attachedDocument by viewModel.attachedDocument.collectAsStateWithLifecycle()
    val webSearchEnabled by viewModel.webSearchEnabled.collectAsStateWithLifecycle()
    val codingModeEnabled by viewModel.codingModeEnabled.collectAsStateWithLifecycle()

    val studioImageState by viewModel.studioImageState.collectAsStateWithLifecycle()
    val generatedImages by viewModel.generatedImages.collectAsStateWithLifecycle()
    val documentArtifacts by viewModel.documentArtifacts.collectAsStateWithLifecycle()

    val liveTelemetry by viewModel.liveTelemetry.collectAsStateWithLifecycle()
    val preferOpenAiRealtime by viewModel.preferOpenAiRealtime.collectAsStateWithLifecycle()

    val upgradePromptModel by viewModel.upgradePromptModel.collectAsStateWithLifecycle()
    val hasAppCheckIssue by viewModel.hasAppCheckIssue.collectAsStateWithLifecycle()
    val appCheckDiagnostics by viewModel.appCheckDiagnostics.collectAsStateWithLifecycle()
    val voicePlaybackState by viewModel.voicePlaybackState.collectAsStateWithLifecycle()

    val streamingText by viewModel.streamingText.collectAsStateWithLifecycle()
    val streamingModelLabel by viewModel.streamingModelLabel.collectAsStateWithLifecycle()

    val models by viewModel.registeredModels.collectAsStateWithLifecycle()
    val routerPreview by viewModel.routerPreview.collectAsStateWithLifecycle()
    val labState by viewModel.labState.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val remoteProbe by viewModel.remoteProbe.collectAsStateWithLifecycle()
    val isProbingRemote by viewModel.isProbingRemote.collectAsStateWithLifecycle()

    val threadList = (conversationsState as? UiState.Success)?.data.orEmpty()
    val vaultCount = (cloudMemoriesState as? UiState.Success)?.data?.size ?: 0
    val currentMessages = (cloudMessagesState as? UiState.Success)?.data.orEmpty()
    val estimatedUsedTokens = currentMessages.sumOf { viewModel.estimateTokenCount(it.content) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeStatusMessage()
        }
    }

    GenixTheme(themeMode = config.themeMode) {
        val navController = rememberNavController()
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = backStackEntry?.destination?.route ?: GenixRoutes.ROUTE_CORE
        val isFullScreenLive = currentRoute == GenixRoutes.ROUTE_LIVE

        val navigateToRoute: (String) -> Unit = { route ->
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        val cycleTheme: () -> Unit = {
            val next = when (config.themeMode) {
                AppThemeMode.SYSTEM -> AppThemeMode.LIGHT_WHITE
                AppThemeMode.LIGHT_WHITE -> AppThemeMode.ICE_CRYSTAL_PRO
                AppThemeMode.ICE_CRYSTAL_PRO -> AppThemeMode.DARK_OBSIDIAN
                AppThemeMode.DARK_OBSIDIAN -> AppThemeMode.SYSTEM
            }
            viewModel.selectThemeMode(next)
        }

        val lockedModel = upgradePromptModel
        if (lockedModel != null) {
            val requiredPlan = SubscriptionPlan.requiredPlanFor(lockedModel)
            AlertDialog(
                onDismissRequest = viewModel::dismissUpgradePrompt,
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LockOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${requiredPlan.displayName} Required")
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "${lockedModel.displayName} (${lockedModel.accessScope.shortBadge}) is a plan-exclusive model.",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${requiredPlan.summary}\n\nCurrent plan: ${config.subscriptionPlan.displayName}. Shared models are free for all users.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.activatePlanAndSelectModel(requiredPlan, lockedModel) },
                        modifier = Modifier.testTag("confirm_upgrade_plan_button")
                    ) {
                        Text("Activate ${requiredPlan.displayName} (Sandbox)")
                    }
                },
                dismissButton = {
                    TextButton(onClick = viewModel::dismissUpgradePrompt) {
                        Text("Not Now")
                    }
                }
            )
        }

        val drawerState = rememberDrawerState(DrawerValue.Closed)
        val drawerScope = rememberCoroutineScope()
        val openDrawer: () -> Unit = { drawerScope.launch { drawerState.open() } }
        val closeDrawerThen: (() -> Unit) -> Unit = { action ->
            drawerScope.launch { drawerState.close() }
            action()
        }
        val drawerUser = Firebase.auth.currentUser
        val drawerContext = LocalContext.current
        val credentialManager = remember(drawerContext) { CredentialManager.create(drawerContext) }

        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = !isFullScreenLive,
            drawerContent = {
                CloudyDrawerContent(
                    threads = threadList,
                    activeConversationId = activeConversationId,
                    currentRoute = currentRoute,
                    userName = drawerUser?.displayName?.takeIf { it.isNotBlank() }
                        ?: drawerUser?.email?.substringBefore("@")
                        ?: "Cloudy",
                    userEmail = drawerUser?.email.orEmpty(),
                    planBadge = config.subscriptionPlan.badge,
                    newChatLabel = homeStrings.newChatLabel,
                    historyLabel = homeStrings.historyLabel,
                    modelsLabel = uiStrings.navModels,
                    labLabel = uiStrings.navLab,
                    settingsLabel = uiStrings.navSystem,
                    liveVoiceLabel = homeStrings.liveVoiceShortcut,
                    onNewChat = {
                        closeDrawerThen {
                            viewModel.createNewConversation()
                            navigateToRoute(GenixRoutes.ROUTE_CORE)
                        }
                    },
                    onSelectConversation = { thread ->
                        closeDrawerThen {
                            viewModel.selectConversation(thread)
                            navigateToRoute(GenixRoutes.ROUTE_CORE)
                        }
                    },
                    onRenameConversation = viewModel::renameConversation,
                    onTogglePin = viewModel::toggleConversationPin,
                    onDeleteConversation = viewModel::deleteConversation,
                    onNavigate = { route -> closeDrawerThen { navigateToRoute(route) } },
                    onCycleTheme = cycleTheme,
                    onSignOut = {
                        closeDrawerThen { AuthHelper.signOut(credentialManager, drawerScope) }
                    }
                )
            }
        ) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    val secondaryTitle = when (currentRoute) {
                        GenixRoutes.ROUTE_MODELS -> uiStrings.navModels
                        GenixRoutes.ROUTE_LAB -> uiStrings.navLab
                        GenixRoutes.ROUTE_SYSTEM -> uiStrings.navSystem
                        else -> null
                    }
                    if (secondaryTitle != null) {
                        SecondaryPageTopBar(
                            title = secondaryTitle,
                            onOpenMenu = openDrawer,
                            onBackToChat = { navigateToRoute(GenixRoutes.ROUTE_CORE) }
                        )
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        NavHost(
                            navController = navController,
                            startDestination = GenixRoutes.ROUTE_CORE
                        ) {
                            composable(GenixRoutes.ROUTE_CORE) {
                                CoreConsoleScreen(
                                    uiStrings = uiStrings,
                                    homeStrings = homeStrings,
                                    config = config,
                                    selectedModel = selectedModel,
                                    activePlatformModel = activePlatformModel,
                                    platformModels = platformModels,
                                    availabilityProvider = viewModel::availabilityFor,
                                    conversationsState = conversationsState,
                                    activeConversationId = activeConversationId,
                                    cloudMessagesState = cloudMessagesState,
                                    streamingText = streamingText,
                                    streamingModelLabel = streamingModelLabel,
                                    attachedIntegrationNotes = attachedIntegrationNotes,
                                    attachedImages = attachedImages,
                                    attachedDocument = attachedDocument,
                                    webSearchEnabled = webSearchEnabled,
                                    codingModeEnabled = codingModeEnabled,
                                    hasAppCheckIssue = hasAppCheckIssue,
                                    appCheckDiagnostics = appCheckDiagnostics,
                                    isProcessing = isProcessing,
                                    voicePlaybackState = voicePlaybackState,
                                    estimateTokens = viewModel::estimateTokenCount,
                                    onSelectModel = { modelId -> viewModel.selectModel(modelId) },
                                    onSelectPlatformModel = { m -> viewModel.selectPlatformModel(m) },
                                    onToggleAutoRoute = { enabled ->
                                        viewModel.updatePersonalization(autoRouteEnabled = enabled)
                                    },
                                    onSpeakMessage = { msg -> viewModel.speakText(msg.content, msg.id) },
                                    onStopSpeaking = viewModel::stopSpeaking,
                                    onVerifyAppCheck = viewModel::verifyAppCheckNow,
                                    onCycleTheme = cycleTheme,
                                    onSelectConversation = viewModel::selectConversation,
                                    onCreateConversation = { viewModel.createNewConversation() },
                                    onRenameConversation = viewModel::renameConversation,
                                    onToggleConversationPin = viewModel::toggleConversationPin,
                                    onDeleteConversation = viewModel::deleteConversation,
                                    onToggleMessageStar = viewModel::toggleMessageStar,
                                    onSendToWebhooks = viewModel::sendMessageToActiveWebhooks,
                                    onEditUserMessageAndResend = viewModel::editUserMessageAndResend,
                                    onRegenerateMessage = viewModel::regenerateAssistantMessage,
                                    onContinueMessage = viewModel::continueGeneratingFrom,
                                    onStopGeneration = viewModel::stopGeneration,
                                    onClearAttachedNotes = viewModel::clearAttachedIntegrationNotes,
                                    onAttachImagesUris = viewModel::attachImagesFromUris,
                                    onClearAttachedImages = viewModel::clearAttachedImage,
                                    onAttachDocumentUri = viewModel::attachDocumentUri,
                                    onClearAttachedDocument = viewModel::clearAttachedDocument,
                                    onToggleWebSearch = viewModel::toggleWebSearchMode,
                                    onToggleCodingMode = viewModel::toggleCodingMode,
                                    onOpenLiveVoice = { navigateToRoute(GenixRoutes.ROUTE_LIVE) },
                                    onOpenImageStudio = { navigateToRoute(GenixRoutes.ROUTE_MODELS) },
                                    onSendPrompt = { text -> viewModel.submitPrompt(text) },
                                    onOpenDrawer = openDrawer
                                )
                            }

                            composable(GenixRoutes.ROUTE_MODELS) {
                                ModelsRouterScreen(
                                    models = models,
                                    loadedMemoryMb = viewModel.loadedMemoryMb(),
                                    activePlatformModel = activePlatformModel,
                                    platformModels = platformModels,
                                    availabilityProvider = viewModel::availabilityFor,
                                    currentPlan = config.subscriptionPlan,
                                    routerPreview = routerPreview,
                                    labState = labState,
                                    studioImageState = studioImageState,
                                    generatedImages = generatedImages,
                                    attachedDocument = attachedDocument,
                                    documentArtifacts = documentArtifacts,
                                    onActivatePlatformModel = { m ->
                                        if (viewModel.selectPlatformModel(m)) {
                                            navigateToRoute(GenixRoutes.ROUTE_CORE)
                                        }
                                    },
                                    onOpenPlanSettings = { navigateToRoute(GenixRoutes.ROUTE_SYSTEM) },
                                    onToggleLoad = viewModel::toggleModelLoad,
                                    onHealthCheck = viewModel::runModelHealthCheck,
                                    onSimulateRoute = viewModel::simulateRouter,
                                    onTokenizerInputChange = viewModel::updateTokenizerInput,
                                    onSelectTransformerPreset = viewModel::selectTransformerPreset,
                                    onAnalyzeCode = viewModel::analyzeLabCode,
                                    onGenerateStudioImage = viewModel::generateStudioImage,
                                    onExportImageToGallery = viewModel::exportGeneratedImageToGallery,
                                    onDeleteGeneratedImage = viewModel::deleteGeneratedImage,
                                    onAttachDocumentUri = viewModel::attachDocumentUri,
                                    onDeleteDocumentArtifact = viewModel::deleteDocumentArtifact,
                                    onAskAboutDocument = { prompt ->
                                        viewModel.submitPrompt(prompt)
                                        navigateToRoute(GenixRoutes.ROUTE_CORE)
                                    }
                                )
                            }

                            composable(GenixRoutes.ROUTE_LAB) {
                                LabMemoryScreen(
                                    labState = labState,
                                    integrationsState = integrationsState,
                                    runningIntegrationId = runningIntegrationId,
                                    cloudMemoriesState = cloudMemoriesState,
                                    knowledgeDocuments = knowledgeDocuments,
                                    onAddIntegration = viewModel::addIntegration,
                                    onToggleIntegration = viewModel::toggleIntegration,
                                    onRunIntegration = viewModel::runIntegrationAction,
                                    onDeleteIntegration = viewModel::deleteIntegration,
                                    onAddCloudMemory = viewModel::addCloudMemory,
                                    onUpdateCloudMemory = viewModel::updateCloudMemory,
                                    onToggleCloudMemoryPin = viewModel::toggleCloudMemoryPin,
                                    onDeleteCloudMemory = viewModel::deleteCloudMemory,
                                    onRunPromptTemplate = { template ->
                                        viewModel.submitPrompt(template)
                                        navigateToRoute(GenixRoutes.ROUTE_CORE)
                                    },
                                    onAddKnowledgeDocument = viewModel::addKnowledgeDocument,
                                    onDeleteKnowledgeDocument = viewModel::deleteKnowledgeDocument,
                                    onSearchKnowledge = viewModel::searchKnowledge
                                )
                            }

                            composable(GenixRoutes.ROUTE_SYSTEM) {
                                ControlPlaneScreen(
                                    config = config,
                                    threadCount = threadList.size,
                                    vaultCount = vaultCount,
                                    estimatedUsedTokens = estimatedUsedTokens,
                                    providerCredentials = providerCredentials,
                                    appCheckDiagnostics = appCheckDiagnostics,
                                    voicePlaybackState = voicePlaybackState,
                                    remoteProbe = remoteProbe,
                                    isProbingRemote = isProbingRemote,
                                    auditLogs = auditLogs,
                                    onSelectSubscriptionPlan = { plan -> viewModel.selectSubscriptionPlan(plan) },
                                    onSelectThemeMode = viewModel::selectThemeMode,
                                    onSelectVoicePersona = viewModel::selectVoicePersona,
                                    onUpdateVoiceTuning = viewModel::updateVoiceTuning,
                                    onUpdateCustomVoiceApi = viewModel::updateCustomVoiceApi,
                                    onTestVoice = viewModel::testActiveVoice,
                                    onStopVoice = viewModel::stopSpeaking,
                                    onVerifyAppCheck = viewModel::verifyAppCheckNow,
                                    onApplyManualAppCheckToken = viewModel::applyManualAppCheckToken,
                                    onSelectCountry = viewModel::selectCountry,
                                    onSelectLanguage = viewModel::updatePreferredLanguage,
                                    onSelectExecutionMode = viewModel::updateExecutionMode,
                                    onProbeRemote = viewModel::probeRemoteControlPlane,
                                    onSaveProviderKey = viewModel::saveProviderKey,
                                    onClearProviderKey = viewModel::clearProviderKey,
                                    onFetchProviderModels = viewModel::fetchProviderModels,
                                    onUpdatePersonalization = viewModel::updatePersonalization,
                                    onExportWorkspaceData = viewModel::exportAllWorkspaceData,
                                    onDeleteAllConversations = viewModel::deleteAllUserConversations,
                                    onClearGeneratedImages = viewModel::clearAllGeneratedImages,
                                    onResetLocalKeysAndPrefs = viewModel::resetLocalPreferencesAndKeys,
                                    onClearLogs = viewModel::clearAuditLogs
                                )
                            }

                            composable(GenixRoutes.ROUTE_LIVE) {
                                LiveVoiceScreen(
                                    telemetry = liveTelemetry,
                                    activePersona = CloudyVoicePersona.fromId(config.voiceProfileId),
                                    liveStrings = liveStrings,
                                    hasOpenAiKey = providerCredentials[AiProviderKind.OPENAI]?.hasKey == true,
                                    preferOpenAiRealtime = preferOpenAiRealtime,
                                    onToggleOpenAiRealtime = viewModel::togglePreferOpenAiRealtime,
                                    onSelectPersona = viewModel::selectVoicePersona,
                                    onStartSession = viewModel::startLiveVoiceSession,
                                    onToggleMute = viewModel::toggleLiveMute,
                                    onInterrupt = viewModel::interruptLiveVoice,
                                    onReconnect = viewModel::reconnectLiveVoice,
                                    onEndSession = viewModel::endLiveVoiceSession,
                                    onNavigateBack = {
                                        viewModel.endLiveVoiceSession()
                                        navigateToRoute(GenixRoutes.ROUTE_CORE)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
