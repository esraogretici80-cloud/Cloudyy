package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 1. Deep Charcoal Dark Theme — Minimalist Productivity & Conversational AI
val ObsidianBg = Color(0xFF212121)
val ObsidianSurface = Color(0xFF2A2A2A)
val ObsidianSurfaceVariant = Color(0xFF303030)
val ObsidianOutline = Color(0xFF3D3D3D)

val DarkMinimalPrimary = Color(0xFFECECEC)
val DarkMinimalOnPrimary = Color(0xFF0D0D0D)
val DarkMinimalPrimaryContainer = Color(0xFF303030)
val DarkMinimalOnPrimaryContainer = Color(0xFFF3F4F6)

val DarkMinimalSecondary = Color(0xFF4C8DFF)
val DarkMinimalOnSecondary = Color(0xFFFFFFFF)
val DarkMinimalSecondaryContainer = Color(0xFF1E2A44)
val DarkMinimalOnSecondaryContainer = Color(0xFFDCE7FF)

val EmeraldVerified = Color(0xFF10B981)
val EmeraldOnTertiary = Color(0xFF002B1C)
val EmeraldContainer = Color(0xFF0F2E24)
val EmeraldOnContainer = Color(0xFFA7F3D0)

val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)
val RoseContainer = Color(0xFF4C1120)
val RoseOnContainer = Color(0xFFFFD5DC)

val SlateTextPrimary = Color(0xFFECECEC)
val SlateTextSecondary = Color(0xFFA3A3A3)

// 2. Clean Off-White Light Theme — Minimalist Studio Surface
val WhiteBg = Color(0xFFFFFFFF)
val WhiteSurface = Color(0xFFFFFFFF)
val WhiteSurfaceVariant = Color(0xFFF4F4F4)
val WhiteOutline = Color(0xFFE6E6E6)

val WhitePrimary = Color(0xFF0D0D0D)
val WhitePrimaryContainer = Color(0xFFF4F4F4)
val WhiteOnPrimaryContainer = Color(0xFF0D0D0D)

val WhiteSecondary = Color(0xFF2F6FEB)
val WhiteSecondaryContainer = Color(0xFFE8F0FE)
val WhiteOnSecondaryContainer = Color(0xFF0B2A66)

val WhiteTertiary = Color(0xFF0D9488)
val WhiteTertiaryContainer = Color(0xFFCCFBF1)
val WhiteOnTertiaryContainer = Color(0xFF042F2E)

val WhiteTextPrimary = Color(0xFF0D0D0D)
val WhiteTextSecondary = Color(0xFF6B6B6B)

// 3. Ice Crystal Pro — Serene Nordic Frost & Translucent Sapphire
val IceCrystalBg = Color(0xFFEDF6FC)
val IceCrystalSurface = Color(0xFFF8FCFF)
val IceCrystalSurfaceVariant = Color(0xFFDFF0FA)
val IceCrystalOutline = Color(0xFFBDE0F5)

val IcePrimary = Color(0xFF0369A1)
val IcePrimaryContainer = Color(0xFFD0ECFC)
val IceOnPrimaryContainer = Color(0xFF062C46)

val IceSecondary = Color(0xFF0E7490)
val IceSecondaryContainer = Color(0xFFD6F5FA)
val IceOnSecondaryContainer = Color(0xFF083344)

val IceTertiary = Color(0xFF0D9488)
val IceTertiaryContainer = Color(0xFFD2FAF4)
val IceOnTertiaryContainer = Color(0xFF042F2E)

val IceTextPrimary = Color(0xFF0C2D48)
val IceTextSecondary = Color(0xFF3B698A)

// ChatGPT-style accent used for the live-voice orb, upgrade pill and links
val CloudyAccentBlue = Color(0xFF2F6FEB)
val CloudyAccentBlueDark = Color(0xFF4C8DFF)
