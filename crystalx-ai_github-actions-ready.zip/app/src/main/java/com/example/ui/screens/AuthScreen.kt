package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.genix.firebase.AuthHelper
import com.example.genix.firebase.SocialAuthProvider
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.ui.components.CloudyAppLogo

/** Short, localized copy for the sign-in screen (no technical hints). */
private data class SignInCopy(
    val title: String,
    val subtitle: String,
    val continueWith: String, // "%s" = provider name
    val connecting: String,
    val legal: String
)

private fun signInCopy(lang: String): SignInCopy = when (lang) {
    "tr" -> SignInCopy("Cloudy'ye hoş geldiniz", "Sorun, yazın, öğrenin ve üretin.", "%s ile devam et", "Bağlanılıyor...", "Devam ederek Kullanım Koşulları'nı ve Gizlilik Politikası'nı kabul etmiş olursunuz.")
    "de" -> SignInCopy("Willkommen bei Cloudy", "Fragen, schreiben, lernen und erschaffen.", "Weiter mit %s", "Verbinden...", "Mit dem Fortfahren akzeptierst du die Nutzungsbedingungen und die Datenschutzerklärung.")
    "fr" -> SignInCopy("Bienvenue sur Cloudy", "Demandez, écrivez, apprenez et créez.", "Continuer avec %s", "Connexion...", "En continuant, vous acceptez les Conditions d'utilisation et la Politique de confidentialité.")
    "es" -> SignInCopy("Te damos la bienvenida a Cloudy", "Pregunta, escribe, aprende y crea.", "Continuar con %s", "Conectando...", "Al continuar, aceptas los Términos de uso y la Política de privacidad.")
    "ar" -> SignInCopy("مرحبًا بك في Cloudy", "اسأل واكتب وتعلّم وأبدع.", "المتابعة باستخدام %s", "جارٍ الاتصال...", "بالمتابعة، فإنك توافق على شروط الاستخدام وسياسة الخصوصية.")
    "ja" -> SignInCopy("Cloudy へようこそ", "質問・執筆・学習・創作をもっと簡単に。", "%s で続行", "接続中...", "続行すると、利用規約とプライバシーポリシーに同意したことになります。")
    "ko" -> SignInCopy("Cloudy에 오신 것을 환영합니다", "질문하고, 쓰고, 배우고, 만들어 보세요.", "%s(으)로 계속하기", "연결 중...", "계속하면 이용약관 및 개인정보 처리방침에 동의하게 됩니다.")
    "zh" -> SignInCopy("欢迎使用 Cloudy", "提问、写作、学习与创作。", "通过 %s 继续", "正在连接...", "继续即表示你同意使用条款和隐私政策。")
    "ru" -> SignInCopy("Добро пожаловать в Cloudy", "Спрашивайте, пишите, учитесь и создавайте.", "Продолжить с %s", "Подключение...", "Продолжая, вы принимаете Условия использования и Политику конфиденциальности.")
    else -> SignInCopy("Welcome to Cloudy", "Ask, write, learn and create.", "Continue with %s", "Connecting...", "By continuing, you agree to the Terms of Use and Privacy Policy.")
}

private val AuthLanguages = listOf(
    "tr" to "Türkçe",
    "en" to "English",
    "de" to "Deutsch",
    "fr" to "Français",
    "es" to "Español",
    "ar" to "العربية",
    "ja" to "日本語",
    "ko" to "한국어",
    "zh" to "中文",
    "ru" to "Русский"
)

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val systemLangCode = remember { MultilingualLanguageSystem.resolveSystemLanguageCode() }
    var selectedLang by rememberSaveable {
        mutableStateOf(if (AuthLanguages.any { it.first == systemLangCode }) systemLangCode else "en")
    }
    val copy = remember(selectedLang) { signInCopy(selectedLang) }
    var languageMenuOpen by remember { mutableStateOf(false) }

    var activeLoadingProvider by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val isLoading = activeLoadingProvider != null

    val succeed: () -> Unit = {
        activeLoadingProvider = null
        onAuthSuccess()
    }
    val fail: (String) -> Unit = { msg ->
        activeLoadingProvider = null
        errorMessage = msg
    }
    val cancel: () -> Unit = { activeLoadingProvider = null }

    LaunchedEffect(Unit) {
        // Finish a GitHub / X / Facebook sign-in interrupted by an activity restart.
        AuthHelper.recoverPendingOAuthResult(onAuthSuccess = succeed, onAuthError = fail, scope = scope)
        AuthHelper.attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = { },
            scope = scope
        )
    }

    fun startOAuth(provider: SocialAuthProvider) {
        activeLoadingProvider = provider.displayName
        errorMessage = null
        AuthHelper.signInWithOAuthProvider(
            context = context,
            provider = provider,
            onAuthSuccess = succeed,
            onAuthError = fail,
            scope = scope,
            onAuthCancelled = cancel
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val pageHeight = if (maxHeight < 640.dp) 640.dp else maxHeight
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(pageHeight)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.height(72.dp))

            CloudyAppLogo(size = 68.dp)
            Spacer(Modifier.height(24.dp))
            Text(
                text = copy.title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = copy.subtitle,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.weight(1f))
            Spacer(Modifier.height(40.dp))

            Column(
                modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AnimatedVisibility(visible = !errorMessage.isNullOrBlank(), enter = fadeIn(), exit = fadeOut()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth().testTag("auth_error_message")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = errorMessage.orEmpty(),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }

                SignInPillButton(
                    label = copy.continueWith.format("Google"),
                    loadingLabel = copy.connecting,
                    isLoading = activeLoadingProvider == "Google",
                    enabled = !isLoading,
                    primary = true,
                    testTag = "google_sign_in_button",
                    logo = {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .background(MaterialTheme.colorScheme.background, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_logo_google),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    },
                    onClick = {
                        activeLoadingProvider = "Google"
                        errorMessage = null
                        AuthHelper.onGoogleSignInClicked(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = succeed,
                            onAuthError = fail,
                            scope = scope,
                            onAuthCancelled = cancel
                        )
                    }
                )

                SignInPillButton(
                    label = copy.continueWith.format("GitHub"),
                    loadingLabel = copy.connecting,
                    isLoading = activeLoadingProvider == SocialAuthProvider.GITHUB.displayName,
                    enabled = !isLoading,
                    testTag = "github_sign_in_button",
                    logo = {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_logo_github),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    onClick = { startOAuth(SocialAuthProvider.GITHUB) }
                )

                SignInPillButton(
                    label = copy.continueWith.format("X"),
                    loadingLabel = copy.connecting,
                    isLoading = activeLoadingProvider == SocialAuthProvider.TWITTER.displayName,
                    enabled = !isLoading,
                    testTag = "twitter_sign_in_button",
                    logo = {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_logo_x),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(17.dp)
                        )
                    },
                    onClick = { startOAuth(SocialAuthProvider.TWITTER) }
                )

                SignInPillButton(
                    label = copy.continueWith.format("Facebook"),
                    loadingLabel = copy.connecting,
                    isLoading = activeLoadingProvider == SocialAuthProvider.FACEBOOK.displayName,
                    enabled = !isLoading,
                    testTag = "facebook_sign_in_button",
                    logo = {
                        Image(
                            painter = painterResource(id = R.drawable.ic_logo_facebook),
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    onClick = { startOAuth(SocialAuthProvider.FACEBOOK) }
                )

                Spacer(Modifier.height(6.dp))
                Text(
                    text = copy.legal,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Spacer(Modifier.height(20.dp))
            }
        }
        }
        }

        // Language picker (top-right)
        Box(modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)) {
            Surface(
                onClick = { languageMenuOpen = true },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.testTag("auth_language_picker")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = AuthLanguages.firstOrNull { it.first == selectedLang }?.second ?: selectedLang.uppercase(),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
            DropdownMenu(expanded = languageMenuOpen, onDismissRequest = { languageMenuOpen = false }) {
                AuthLanguages.forEach { (code, label) ->
                    DropdownMenuItem(
                        text = { Text(label) },
                        trailingIcon = {
                            if (code == selectedLang) Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        },
                        onClick = {
                            selectedLang = code
                            languageMenuOpen = false
                        },
                        modifier = Modifier.testTag("auth_lang_$code")
                    )
                }
            }
        }

    }
}

@Composable
private fun SignInPillButton(
    label: String,
    loadingLabel: String,
    isLoading: Boolean,
    enabled: Boolean,
    testTag: String,
    onClick: () -> Unit,
    logo: @Composable () -> Unit,
    primary: Boolean = false
) {
    val container = if (primary) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.background
    val content = if (primary) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onBackground
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(28.dp),
        color = container,
        contentColor = content,
        border = if (primary) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag(testTag)
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Box(modifier = Modifier.align(Alignment.CenterStart).size(28.dp), contentAlignment = Alignment.Center) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = content)
                } else {
                    logo()
                }
            }
            Text(
                text = if (isLoading) loadingLabel else label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = content,
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}
