package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.genix.firebase.CloudyIntegrationsEngine
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import kotlinx.coroutines.delay

sealed interface MarkdownBlock {
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class Paragraph(val text: String) : MarkdownBlock
    data class BulletItem(
        val prefix: String,
        val text: String,
        val indentLevel: Int = 0,
        val isChecked: Boolean? = null
    ) : MarkdownBlock
    data class Quote(val text: String) : MarkdownBlock
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownBlock
    data object Divider : MarkdownBlock
}

object MarkdownParser {

    private val headingRegex = Regex("^(#{1,6})\\s+(.*)$")
    private val bulletRegex = Regex("^(\\s*)([*\\-+•]|\\d+[.)])\\s+(.*)$")
    private val taskPrefixRegex = Regex("^\\[([ xX])]\\s*(.*)$")
    private val dividerRegex = Regex("^(?:-\\s*){3,}$|^(?:\\*\\s*){3,}$|^(?:_\\s*){3,}$")
    private val tableSeparatorRegex = Regex("^\\|?(\\s*:?-{2,}:?\\s*\\|)+(\\s*:?-{2,}:?\\s*)?\\|?$")

    fun parse(raw: String): List<MarkdownBlock> {
        val normalized = raw.replace("\r\n", "\n").replace("\r", "\n")
        val lines = normalized.split("\n")
        val blocks = mutableListOf<MarkdownBlock>()
        var i = 0
        val paragraphBuf = mutableListOf<String>()

        fun flushParagraph() {
            if (paragraphBuf.isNotEmpty()) {
                val joined = paragraphBuf.joinToString("\n").trim()
                if (joined.isNotEmpty()) blocks.add(MarkdownBlock.Paragraph(joined))
                paragraphBuf.clear()
            }
        }

        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trim()

            // 1. Fenced code block (``` or ~~~), also resilient to unclosed fences during streaming
            val fenceToken = when {
                trimmed.startsWith("```") -> "```"
                trimmed.startsWith("~~~") -> "~~~"
                else -> null
            }
            if (fenceToken != null) {
                flushParagraph()
                val lang = trimmed.removePrefix(fenceToken).trim()
                    .substringBefore(' ')
                    .ifBlank { "code" }
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trim().startsWith(fenceToken)) {
                    codeLines.add(lines[i])
                    i++
                }
                blocks.add(
                    MarkdownBlock.CodeBlock(
                        language = lang,
                        code = codeLines.joinToString("\n")
                    )
                )
                i++
                continue
            }

            // 2. Blank line flushes paragraph
            if (trimmed.isEmpty()) {
                flushParagraph()
                i++
                continue
            }

            // 3. Horizontal rule (---, ***, ___)
            if (dividerRegex.matches(trimmed)) {
                flushParagraph()
                blocks.add(MarkdownBlock.Divider)
                i++
                continue
            }

            // 4. ATX Heading (# .. ######)
            val headingMatch = headingRegex.find(trimmed)
            if (headingMatch != null) {
                flushParagraph()
                blocks.add(
                    MarkdownBlock.Heading(
                        level = headingMatch.groupValues[1].length.coerceIn(1, 6),
                        text = headingMatch.groupValues[2].trimEnd('#', ' ')
                    )
                )
                i++
                continue
            }

            // 5. Setext Heading (Title followed by === or ---)
            if (i + 1 < lines.size) {
                val nextTrimmed = lines[i + 1].trim()
                if (nextTrimmed.length >= 3 && nextTrimmed.all { it == '=' }) {
                    flushParagraph()
                    blocks.add(MarkdownBlock.Heading(level = 1, text = trimmed))
                    i += 2
                    continue
                }
                if (nextTrimmed.length >= 3 && nextTrimmed.all { it == '-' } && !trimmed.startsWith("|")) {
                    flushParagraph()
                    blocks.add(MarkdownBlock.Heading(level = 2, text = trimmed))
                    i += 2
                    continue
                }
            }

            // 6. GitHub-Flavored Markdown Table
            if (trimmed.contains('|') && i + 1 < lines.size && tableSeparatorRegex.matches(lines[i + 1].trim())) {
                flushParagraph()
                val headers = parseTableRow(trimmed)
                i += 2 // skip header & separator
                val rows = mutableListOf<List<String>>()
                while (i < lines.size) {
                    val rowTrimmed = lines[i].trim()
                    if (rowTrimmed.isEmpty() || !rowTrimmed.contains('|')) break
                    rows.add(parseTableRow(rowTrimmed, expectedCols = headers.size))
                    i++
                }
                if (headers.isNotEmpty()) {
                    blocks.add(MarkdownBlock.Table(headers = headers, rows = rows))
                    continue
                }
            }

            // 7. Grouped Blockquote (> ...)
            if (trimmed.startsWith(">")) {
                flushParagraph()
                val quoteLines = mutableListOf<String>()
                while (i < lines.size && lines[i].trim().startsWith(">")) {
                    quoteLines.add(lines[i].trim().removePrefix(">").trimStart())
                    i++
                }
                blocks.add(MarkdownBlock.Quote(quoteLines.joinToString("\n").trim()))
                continue
            }

            // 8. Unordered, Ordered & Task Lists (with indentation levels)
            val bulletMatch = bulletRegex.find(line)
            if (bulletMatch != null) {
                flushParagraph()
                val leadingSpaces = bulletMatch.groupValues[1].replace("\t", "    ").length
                val indentLevel = (leadingSpaces / 2).coerceIn(0, 3)
                val marker = bulletMatch.groupValues[2]
                val rawBody = bulletMatch.groupValues[3].trim()

                val taskMatch = taskPrefixRegex.find(rawBody)
                val isChecked = taskMatch?.let { it.groupValues[1].equals("x", ignoreCase = true) }
                val bodyText = taskMatch?.groupValues?.get(2)?.trim() ?: rawBody

                val prefix = when {
                    marker.endsWith(".") || marker.endsWith(")") -> marker.removeSuffix(")") + if (marker.endsWith(")")) "." else ""
                    indentLevel == 0 -> "•"
                    indentLevel == 1 -> "◦"
                    else -> "▪"
                }

                blocks.add(
                    MarkdownBlock.BulletItem(
                        prefix = prefix,
                        text = bodyText,
                        indentLevel = indentLevel,
                        isChecked = isChecked
                    )
                )
                i++
                continue
            }

            // 9. Plain paragraph line
            paragraphBuf.add(line)
            i++
        }
        flushParagraph()
        return blocks
    }

    private fun parseTableRow(line: String, expectedCols: Int = 0): List<String> {
        val stripped = line.trim().removePrefix("|").removeSuffix("|")
        val cells = stripped.split("|").map { it.trim() }
        return if (expectedCols > 0 && cells.size < expectedCols) {
            cells + List(expectedCols - cells.size) { "" }
        } else {
            cells
        }
    }
}

@Composable
fun RichMarkdownText(
    markdown: String,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    selectable: Boolean = false,
    modifier: Modifier = Modifier
) {
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }
    val inlineCodeBg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
    val primaryColor = MaterialTheme.colorScheme.primary

    val content: @Composable () -> Unit = {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .testTag("rich_markdown_root"),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            blocks.forEachIndexed { idx, block ->
                when (block) {
                    is MarkdownBlock.Heading -> {
                        val style = when (block.level) {
                            1 -> MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            2 -> MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            3 -> MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                            else -> MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                        }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = if (idx == 0) 0.dp else 4.dp)
                                .testTag("markdown_heading_${block.level}"),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = parseInlineMarkdown(block.text, primaryColor, inlineCodeBg),
                                style = style,
                                color = textColor
                            )
                            if (block.level <= 2) {
                                HorizontalDivider(
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                                )
                            }
                        }
                    }

                    is MarkdownBlock.Paragraph -> {
                        Text(
                            text = parseInlineMarkdown(block.text, primaryColor, inlineCodeBg),
                            style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 23.sp),
                            color = textColor,
                            modifier = Modifier.testTag("markdown_paragraph")
                        )
                    }

                    is MarkdownBlock.BulletItem -> {
                        val indentPadding = (block.indentLevel * 16).dp
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 4.dp + indentPadding)
                                .testTag("markdown_list_item"),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            if (block.isChecked != null) {
                                Icon(
                                    imageVector = if (block.isChecked) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                                    contentDescription = if (block.isChecked) "Checked" else "Unchecked",
                                    tint = if (block.isChecked) EmeraldVerified else primaryColor,
                                    modifier = Modifier
                                        .padding(top = 3.dp)
                                        .size(18.dp)
                                )
                            } else {
                                Text(
                                    text = block.prefix,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryColor
                                )
                            }
                            Text(
                                text = parseInlineMarkdown(block.text, primaryColor, inlineCodeBg),
                                style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 22.sp),
                                color = textColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    is MarkdownBlock.Quote -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("markdown_quote")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(4.dp)
                                        .fillMaxHeight()
                                        .background(primaryColor)
                                )
                                Text(
                                    text = parseInlineMarkdown(block.text, primaryColor, inlineCodeBg),
                                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                                    fontStyle = FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
                                )
                            }
                        }
                    }

                    is MarkdownBlock.Table -> {
                        MarkdownTableCard(
                            headers = block.headers,
                            rows = block.rows,
                            primaryColor = primaryColor,
                            inlineCodeBg = inlineCodeBg,
                            textColor = textColor
                        )
                    }

                    is MarkdownBlock.Divider -> {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
                        )
                    }

                    is MarkdownBlock.CodeBlock -> {
                        SyntaxHighlightedCodeBlock(
                            language = block.language,
                            code = block.code
                        )
                    }
                }
            }
        }
    }

    if (selectable) {
        SelectionContainer { content() }
    } else {
        content()
    }
}

@Composable
private fun MarkdownTableCard(
    headers: List<String>,
    rows: List<List<String>>,
    primaryColor: Color,
    inlineCodeBg: Color,
    textColor: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("markdown_table")
    ) {
        Column(modifier = Modifier.horizontalScroll(rememberScrollState())) {
            // Header row
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                headers.forEach { header ->
                    Text(
                        text = parseInlineMarkdown(header, primaryColor, inlineCodeBg),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = textColor,
                        modifier = Modifier
                            .widthIn(min = 100.dp, max = 220.dp)
                            .padding(end = 12.dp)
                    )
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            rows.forEachIndexed { rowIdx, row ->
                Row(
                    modifier = Modifier
                        .background(
                            if (rowIdx % 2 == 1) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                            else Color.Transparent
                        )
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    headers.indices.forEach { colIdx ->
                        val cell = row.getOrElse(colIdx) { "" }
                        Text(
                            text = parseInlineMarkdown(cell, primaryColor, inlineCodeBg),
                            style = MaterialTheme.typography.bodySmall,
                            color = textColor,
                            modifier = Modifier
                                .widthIn(min = 100.dp, max = 220.dp)
                                .padding(end = 12.dp)
                        )
                    }
                }
                if (rowIdx < rows.lastIndex) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                }
            }
        }
    }
}

@Composable
fun SyntaxHighlightedCodeBlock(
    language: String,
    code: String
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1800)
            copied = false
        }
    }

    val highlighted = remember(code) { highlightCodeSyntax(code) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF111318),
        border = BorderStroke(1.dp, Color(0xFF282D38)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("markdown_code_block")
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = Color(0xFF94A3B8)
                )
                IconButton(
                    onClick = {
                        CloudyIntegrationsEngine.copyToClipboard(context, "Cloudy Code", code)
                        copied = true
                    },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("copy_code_button")
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                        contentDescription = if (copied) "Copied code" else "Copy code",
                        tint = if (copied) EmeraldVerified else Color(0xFFCBD5E1),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            HorizontalDivider(color = Color(0xFF232732))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                Text(
                    text = highlighted,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        lineHeight = 19.sp
                    )
                )
            }
        }
    }
}

/**
 * Parses inline Markdown spans (bold, italic, bold+italic, strikethrough, inline code, and clickable links)
 * cleanly without corrupting snake_case identifiers.
 */
internal fun parseInlineMarkdown(
    text: String,
    accent: Color,
    codeBg: Color
): AnnotatedString = buildAnnotatedString {
    appendInlineMarkdown(text, accent, codeBg)
}

private fun AnnotatedString.Builder.appendInlineMarkdown(
    text: String,
    accent: Color,
    codeBg: Color
) {
    var i = 0
    while (i < text.length) {
        when {
            // Escaped character \* \_ \`
            text[i] == '\\' && i + 1 < text.length && text[i + 1] in charArrayOf('*', '_', '`', '~', '[', ']', '\\') -> {
                append(text[i + 1])
                i += 2
            }

            // Inline code span (protects literal formatting chars inside backticks)
            text[i] == '`' -> {
                val fenceLen = if (text.startsWith("``", i)) 2 else 1
                val delimiter = if (fenceLen == 2) "``" else "`"
                val end = text.indexOf(delimiter, i + fenceLen)
                if (end > i + fenceLen) {
                    val codeContent = text.substring(i + fenceLen, end).trim()
                    withStyle(
                        SpanStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            background = codeBg,
                            color = accent,
                            fontSize = 13.sp
                        )
                    ) {
                        append(" $codeContent ")
                    }
                    i = end + fenceLen
                } else {
                    append(text[i])
                    i++
                }
            }

            // Bold + Italic (***text*** or ___text___)
            text.startsWith("***", i) || text.startsWith("___", i) -> {
                val marker = text.substring(i, i + 3)
                val end = text.indexOf(marker, i + 3)
                if (end > i + 3) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)) {
                        appendInlineMarkdown(text.substring(i + 3, end), accent, codeBg)
                    }
                    i = end + 3
                } else {
                    append(text[i])
                    i++
                }
            }

            // Bold (**text** or __text__)
            text.startsWith("**", i) || text.startsWith("__", i) -> {
                val marker = text.substring(i, i + 2)
                val end = text.indexOf(marker, i + 2)
                if (end > i + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        appendInlineMarkdown(text.substring(i + 2, end), accent, codeBg)
                    }
                    i = end + 2
                } else {
                    append(text[i])
                    i++
                }
            }

            // Strikethrough (~~text~~)
            text.startsWith("~~", i) -> {
                val end = text.indexOf("~~", i + 2)
                if (end > i + 2) {
                    withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                        appendInlineMarkdown(text.substring(i + 2, end), accent, codeBg)
                    }
                    i = end + 2
                } else {
                    append(text[i])
                    i++
                }
            }

            // Italic (*text* or _text_ at non-identifier boundaries)
            text[i] == '*' || text[i] == '_' -> {
                val marker = text[i]
                val prevIsWord = i > 0 && (text[i - 1].isLetterOrDigit() || text[i - 1] == '_')
                val nextIsSpace = i + 1 >= text.length || text[i + 1].isWhitespace()
                val end = if (!(marker == '_' && prevIsWord) && !nextIsSpace) {
                    findClosingSingleItalic(text, i + 1, marker)
                } else {
                    -1
                }
                if (end > i + 1) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        appendInlineMarkdown(text.substring(i + 1, end), accent, codeBg)
                    }
                    i = end + 1
                } else {
                    append(text[i])
                    i++
                }
            }

            // Markdown Link [label](https://...)
            text[i] == '[' -> {
                val closeBracket = text.indexOf(']', i + 1)
                val openParen = if (closeBracket > 0 && closeBracket + 1 < text.length && text[closeBracket + 1] == '(') {
                    closeBracket + 1
                } else {
                    -1
                }
                val closeParen = if (openParen > 0) text.indexOf(')', openParen + 1) else -1
                if (closeBracket > i && openParen > 0 && closeParen > openParen) {
                    val label = text.substring(i + 1, closeBracket)
                    val url = text.substring(openParen + 1, closeParen).trim()
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        withLink(
                            LinkAnnotation.Url(
                                url = url,
                                styles = TextLinkStyles(
                                    style = SpanStyle(
                                        color = accent,
                                        fontWeight = FontWeight.SemiBold,
                                        textDecoration = TextDecoration.Underline
                                    )
                                )
                            )
                        ) {
                            appendInlineMarkdown(label, accent, codeBg)
                        }
                    } else {
                        withStyle(SpanStyle(color = accent, fontWeight = FontWeight.SemiBold)) {
                            appendInlineMarkdown(label, accent, codeBg)
                        }
                    }
                    i = closeParen + 1
                } else {
                    append(text[i])
                    i++
                }
            }

            else -> {
                append(text[i])
                i++
            }
        }
    }
}

private fun findClosingSingleItalic(text: String, start: Int, marker: Char): Int {
    var idx = start
    while (idx < text.length) {
        if (text[idx] == '`') {
            val endTick = text.indexOf('`', idx + 1)
            if (endTick > idx) {
                idx = endTick + 1
                continue
            }
        }
        if (text[idx] == marker) {
            val prevChar = text[idx - 1]
            val nextIsWord = idx + 1 < text.length && text[idx + 1].isLetterOrDigit()
            if (!prevChar.isWhitespace() && !(marker == '_' && nextIsWord)) {
                return idx
            }
        }
        idx++
    }
    return -1
}

private val codeKeywords = setOf(
    "fun", "val", "var", "class", "interface", "object", "data", "sealed", "enum",
    "suspend", "override", "private", "public", "internal", "return", "if", "else",
    "when", "for", "while", "import", "package", "def", "async", "await", "try",
    "catch", "finally", "throw", "const", "let", "function", "export", "SELECT",
    "FROM", "WHERE", "INSERT", "UPDATE", "JOIN", "true", "false", "null", "None",
    "True", "False"
)

private val codeTokenRegex =
    Regex("(\"[^\"]*\"|'[^']*'|@[A-Za-z_][A-Za-z0-9_]*|\\b[A-Za-z_][A-Za-z0-9_]*\\b|\\b\\d+(?:\\.\\d+)?\\b|\\s+|.)")

private fun highlightCodeSyntax(code: String): AnnotatedString = buildAnnotatedString {
    val lines = code.split("\n")
    lines.forEachIndexed { lineIdx, line ->
        val trimmed = line.trimStart()
        if (trimmed.startsWith("//") || trimmed.startsWith("#") || trimmed.startsWith("--")) {
            withStyle(SpanStyle(color = Color(0xFF6B7280), fontStyle = FontStyle.Italic)) {
                append(line)
            }
        } else {
            codeTokenRegex.findAll(line).forEach { m ->
                val tok = m.value
                val color = when {
                    tok.startsWith("\"") || tok.startsWith("'") -> Color(0xFF86EFAC)
                    tok.startsWith("@") -> Color(0xFFF472B6)
                    tok in codeKeywords -> Color(0xFFC084FC)
                    tok.matches(Regex("\\d+(?:\\.\\d+)?")) -> Color(0xFFFBBF24)
                    tok.firstOrNull()?.isUpperCase() == true -> Color(0xFF38BDF8)
                    else -> Color(0xFFE2E8F0)
                }
                withStyle(SpanStyle(color = color)) {
                    append(tok)
                }
            }
        }
        if (lineIdx < lines.lastIndex) append("\n")
    }
}
