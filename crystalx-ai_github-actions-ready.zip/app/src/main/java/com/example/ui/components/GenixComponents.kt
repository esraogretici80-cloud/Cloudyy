package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.genix.core.VerificationStatus
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCloudyStyle
import com.example.ui.theme.RoseError

@Composable
fun VerificationBadge(
    statusName: String,
    modifier: Modifier = Modifier
) {
    val status = runCatching { VerificationStatus.valueOf(statusName) }
        .getOrDefault(VerificationStatus.LOCAL_DETERMINISTIC)

    val (label, color, icon) = when (status) {
        VerificationStatus.VERIFIED_COMPUTATION ->
            Triple("VERIFIED MATH/LOGIC", EmeraldVerified, Icons.Filled.CheckCircle)
        VerificationStatus.STATIC_ANALYSIS_VERIFIED ->
            Triple("STATIC AUDIT VERIFIED", EmeraldVerified, Icons.Filled.Shield)
        VerificationStatus.LOCAL_DETERMINISTIC ->
            Triple("LOCAL DETERMINISTIC", MaterialTheme.colorScheme.primary, Icons.Filled.Info)
        VerificationStatus.REMOTE_MODEL_UNVERIFIED ->
            Triple("REMOTE MODEL OUTPUT", AmberWarning, Icons.Filled.WarningAmber)
        VerificationStatus.UNSUPPORTED_CAPABILITY ->
            Triple("PHASE 1 BOUNDARY", RoseError, Icons.Filled.ErrorOutline)
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun TelemetryChip(
    label: String,
    accent: Color = MaterialTheme.colorScheme.secondary,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(0.8.dp, accent.copy(alpha = 0.28f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = JetBrainsMonoFontFamily,
            color = accent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun LanguagePill(
    languageCode: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Translate,
                contentDescription = "Active language",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = languageCode.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EmptyPlaceholderCard(
    title: String,
    body: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(34.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun CloudyDetailCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val cloudyStyle = LocalCloudyStyle.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
        border = BorderStroke(
            width = if (highlighted) 1.5.dp else 1.dp,
            brush = if (highlighted) cloudyStyle.crystalAccentBrush else cloudyStyle.borderBrush
        ),
        tonalElevation = if (highlighted) 4.dp else 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun MetricProgressRow(
    label: String,
    fraction: Float,
    valueLabel: String,
    accent: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = valueLabel,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction.coerceIn(0.05f, 1f))
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(accent.copy(alpha = 0.72f), accent)
                        )
                    )
            )
        }
    }
}

@Composable
fun PulsingStatusDot(
    color: Color = EmeraldVerified,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "pulse_dot")
    val scale by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    Box(
        modifier = modifier.size(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.28f))
        )
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
    }
}

@Composable
fun CloudyMinimalCloudMark(
    modifier: Modifier = Modifier,
    strokeColor: Color = Color(0xFF0A0A0C),
    containerColor: Color = Color.White,
    strokeWidthDp: Float = 2.6f,
    shape: androidx.compose.ui.graphics.Shape = CircleShape,
    showBorder: Boolean = true,
    innerPadding: androidx.compose.ui.unit.Dp = 8.dp
) {
    Surface(
        modifier = modifier,
        shape = shape,
        color = containerColor,
        border = if (showBorder) BorderStroke(1.dp, strokeColor.copy(alpha = 0.14f)) else null,
        shadowElevation = if (showBorder) 2.dp else 0.dp
    ) {
        androidx.compose.foundation.Canvas(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            val w = size.width
            val h = size.height
            val path = androidx.compose.ui.graphics.Path().apply {
                // Balanced geometric hollow cloud path normalized to Canvas bounds
                moveTo(w * 0.27f, h * 0.78f)
                lineTo(w * 0.74f, h * 0.78f)
                cubicTo(
                    w * 0.89f, h * 0.78f,
                    w * 0.96f, h * 0.67f,
                    w * 0.94f, h * 0.56f
                )
                cubicTo(
                    w * 0.92f, h * 0.45f,
                    w * 0.82f, h * 0.39f,
                    w * 0.73f, h * 0.40f
                )
                cubicTo(
                    w * 0.69f, h * 0.23f,
                    w * 0.53f, h * 0.15f,
                    w * 0.39f, h * 0.21f
                )
                cubicTo(
                    w * 0.28f, h * 0.26f,
                    w * 0.23f, h * 0.36f,
                    w * 0.23f, h * 0.44f
                )
                cubicTo(
                    w * 0.12f, h * 0.46f,
                    w * 0.06f, h * 0.55f,
                    w * 0.07f, h * 0.65f
                )
                cubicTo(
                    w * 0.08f, h * 0.73f,
                    w * 0.16f, h * 0.78f,
                    w * 0.27f, h * 0.78f
                )
                close()
            }
            drawPath(
                path = path,
                color = strokeColor,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = strokeWidthDp.dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round,
                    join = androidx.compose.ui.graphics.StrokeJoin.Round
                )
            )
        }
    }
}


/**
 * Cloudy brand logo: white outlined cloud inside a solid rounded square
 * (matches the official Cloudy app icon). Colors follow the active theme.
 */
@Composable
fun CloudyAppLogo(
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 56.dp
) {
    CloudyMinimalCloudMark(
        modifier = modifier.size(size),
        strokeColor = MaterialTheme.colorScheme.background,
        containerColor = MaterialTheme.colorScheme.onBackground,
        strokeWidthDp = (size.value / 16f).coerceIn(2f, 6f),
        shape = RoundedCornerShape(size * 0.28f),
        showBorder = false,
        innerPadding = size * 0.16f
    )
}
