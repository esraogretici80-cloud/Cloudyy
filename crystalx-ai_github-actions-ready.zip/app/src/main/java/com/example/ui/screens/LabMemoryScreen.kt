package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.remember
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.genix.firebase.CloudMemoryItem
import com.example.genix.firebase.UserIntegration
import com.example.genix.memory.KnowledgeDocumentEntity
import com.example.genix.memory.KnowledgeSearchHit
import com.example.ui.LabState
import com.example.ui.UiState
import com.example.ui.components.PulsingStatusDot
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryChip
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCloudyStyle
import com.example.ui.theme.RoseError

@Composable
fun LabMemoryScreen(
    labState: LabState,
    integrationsState: UiState<List<UserIntegration>>,
    runningIntegrationId: String?,
    cloudMemoriesState: UiState<List<CloudMemoryItem>>,
    knowledgeDocuments: List<KnowledgeDocumentEntity>,
    onAddIntegration: (type: String, name: String, targetUrl: String, notes: String) -> Unit,
    onToggleIntegration: (UserIntegration) -> Unit,
    onRunIntegration: (UserIntegration) -> Unit,
    onDeleteIntegration: (String) -> Unit,
    onAddCloudMemory: (title: String, category: String, content: String, tagsRaw: String, pinned: Boolean) -> Unit,
    onUpdateCloudMemory: (memoryId: String, title: String, category: String, content: String, tagsRaw: String) -> Unit,
    onToggleCloudMemoryPin: (CloudMemoryItem) -> Unit,
    onDeleteCloudMemory: (String) -> Unit,
    onRunPromptTemplate: (String) -> Unit,
    onAddKnowledgeDocument: (title: String, source: String, content: String) -> Unit,
    onDeleteKnowledgeDocument: (Long) -> Unit,
    onSearchKnowledge: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val cloudyStyle = LocalCloudyStyle.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf("Entegrasyonlar", "Bulut & Yerel Kasa")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(cloudyStyle.backgroundBrush)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 840.dp).fillMaxSize()) {
                Spacer(modifier = Modifier.height(12.dp))
                SectionHeader(
                    title = "Cloudy Entegrasyon Merkezi & Kasa",
                    subtitle = "GitHub • Webhook • Web/RSS • FastAPI • TTS • Kişiye Özel Kasa"
                )
                Spacer(modifier = Modifier.height(10.dp))

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    tabs.forEachIndexed { index, label ->
                        SegmentedButton(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = tabs.size),
                            modifier = Modifier.testTag("lab_tab_$index")
                        ) {
                            Text(label, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (selectedTab == 0) {
                    IntegrationsHubTab(
                        integrationsState = integrationsState,
                        runningIntegrationId = runningIntegrationId,
                        onAddIntegration = onAddIntegration,
                        onToggleIntegration = onToggleIntegration,
                        onRunIntegration = onRunIntegration,
                        onDeleteIntegration = onDeleteIntegration
                    )
                } else {
                    CloudVaultTab(
                        labState = labState,
                        cloudMemoriesState = cloudMemoriesState,
                        knowledgeDocuments = knowledgeDocuments,
                        onAddCloudMemory = onAddCloudMemory,
                        onUpdateCloudMemory = onUpdateCloudMemory,
                        onToggleCloudMemoryPin = onToggleCloudMemoryPin,
                        onDeleteCloudMemory = onDeleteCloudMemory,
                        onRunPromptTemplate = onRunPromptTemplate,
                        onAddKnowledgeDocument = onAddKnowledgeDocument,
                        onDeleteKnowledgeDocument = onDeleteKnowledgeDocument,
                        onSearchKnowledge = onSearchKnowledge
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun IntegrationsHubTab(
    integrationsState: UiState<List<UserIntegration>>,
    runningIntegrationId: String?,
    onAddIntegration: (type: String, name: String, targetUrl: String, notes: String) -> Unit,
    onToggleIntegration: (UserIntegration) -> Unit,
    onRunIntegration: (UserIntegration) -> Unit,
    onDeleteIntegration: (String) -> Unit
) {
    val cloudyStyle = LocalCloudyStyle.current
    val types = listOf(
        "github_repo" to "GitHub Repo",
        "webhook" to "Webhook (Slack/Discord/n8n)",
        "web_feed" to "Web / RSS Link",
        "fastapi_node" to "FastAPI / Ollama Node"
    )
    var selectedType by rememberSaveable { mutableStateOf("github_repo") }
    var name by rememberSaveable { mutableStateOf("") }
    var targetUrl by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    val loadedList = (integrationsState as? UiState.Success)?.data.orEmpty()
    val enabledCount = loadedList.count { it.enabled }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.2.dp, cloudyStyle.crystalAccentBrush)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        PulsingStatusDot(color = EmeraldVerified)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Bağlantı Orkestratörü",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$enabledCount/${loadedList.size} entegrasyon aktif • Kişisel Firestore izole",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    TelemetryChip(label = "${loadedList.size} NODE", accent = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // Add New Private Integration Card + Quick Presets
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Hub, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Yeni Entegrasyon Ekle (Sadece Senin Hesabına Özel)", style = MaterialTheme.typography.titleMedium)
                    }

                    Text("Hızlı Şablonlar:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        AssistChip(
                            onClick = {
                                selectedType = "github_repo"
                                name = "Compose Samples"
                                targetUrl = "android/compose-samples"
                                notes = "Jetpack Compose reference examples"
                            },
                            label = { Text("GitHub Compose") }
                        )
                        AssistChip(
                            onClick = {
                                selectedType = "webhook"
                                name = "Team Webhook"
                                targetUrl = "https://discord.com/api/webhooks/YOUR_HOOK"
                                notes = "Dispatches AI summaries to Discord/Slack"
                            },
                            label = { Text("Webhook Şablon") }
                        )
                        AssistChip(
                            onClick = {
                                selectedType = "fastapi_node"
                                name = "Local GPU FastAPI"
                                targetUrl = "http://10.0.2.2:8000"
                                notes = "Self-hosted vLLM/FastAPI node"
                            },
                            label = { Text("FastAPI Node") }
                        )
                    }

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        types.forEach { (typeKey, label) ->
                            FilterChip(
                                selected = selectedType == typeKey,
                                onClick = { selectedType = typeKey },
                                label = { Text(label) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Bağlantı Adı (örn. Backend Repo, Ekip Webhook)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("integration_name_input")
                    )

                    OutlinedTextField(
                        value = targetUrl,
                        onValueChange = { targetUrl = it },
                        label = {
                            Text(
                                when (selectedType) {
                                    "github_repo" -> "GitHub Repo (örn. google/generative-ai-android)"
                                    "webhook" -> "Webhook HTTPS URL"
                                    "web_feed" -> "Web Sayfası veya RSS URL"
                                    else -> "FastAPI Base URL (http://...)"
                                }
                            )
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("integration_target_input")
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Açıklama (isteğe bağlı)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            onAddIntegration(selectedType, name, targetUrl, notes)
                            name = ""
                            targetUrl = ""
                            notes = ""
                        },
                        enabled = name.isNotBlank() && targetUrl.isNotBlank(),
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("add_integration_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Entegrasyonu Kaydet")
                    }
                }
            }
        }

        when (integrationsState) {
            is UiState.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    Text(integrationsState.message, color = RoseError, style = MaterialTheme.typography.bodySmall)
                }
            }
            is UiState.Success -> {
                items(integrationsState.data, key = { it.id }) { item ->
                    val icon = when (item.type) {
                        "github_repo" -> Icons.Filled.Code
                        "webhook" -> Icons.Filled.Http
                        "web_feed" -> Icons.Filled.Language
                        "fastapi_node" -> Icons.Filled.Dns
                        "voice_tts" -> Icons.Filled.RecordVoiceOver
                        else -> Icons.Filled.Storage
                    }
                    val isRunning = runningIntegrationId == item.id

                    Surface(
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                        border = BorderStroke(
                            1.dp,
                            if (item.enabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(item.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${item.type} • ${item.targetUrl}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Switch(
                                    checked = item.enabled,
                                    onCheckedChange = { onToggleIntegration(item) }
                                )
                            }

                            if (item.notes.isNotBlank()) {
                                Text(item.notes, style = MaterialTheme.typography.bodySmall)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TelemetryChip(
                                    label = item.lastStatus.ifBlank { "Ready" },
                                    accent = EmeraldVerified
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (item.type in listOf("github_repo", "web_feed", "webhook", "fastapi_node")) {
                                        OutlinedButton(
                                            onClick = { onRunIntegration(item) },
                                            enabled = !isRunning && item.targetUrl.isNotBlank(),
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            if (isRunning) {
                                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                            } else {
                                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                            }
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                when (item.type) {
                                                    "github_repo" -> "Fetch & Attach"
                                                    "web_feed" -> "Read & Attach"
                                                    "webhook" -> "Test Send"
                                                    else -> "Probe"
                                                }
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = { onDeleteIntegration(item.id) },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete integration")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CloudVaultTab(
    labState: LabState,
    cloudMemoriesState: UiState<List<CloudMemoryItem>>,
    knowledgeDocuments: List<KnowledgeDocumentEntity>,
    onAddCloudMemory: (title: String, category: String, content: String, tagsRaw: String, pinned: Boolean) -> Unit,
    onUpdateCloudMemory: (memoryId: String, title: String, category: String, content: String, tagsRaw: String) -> Unit,
    onToggleCloudMemoryPin: (CloudMemoryItem) -> Unit,
    onDeleteCloudMemory: (String) -> Unit,
    onRunPromptTemplate: (String) -> Unit,
    onAddKnowledgeDocument: (title: String, source: String, content: String) -> Unit,
    onDeleteKnowledgeDocument: (Long) -> Unit,
    onSearchKnowledge: (String) -> Unit
) {
    val cloudyStyle = LocalCloudyStyle.current
    val categories = listOf("all", "knowledge", "prompt_template", "preference", "code_snippet")
    var filterCat by rememberSaveable { mutableStateOf("all") }
    var searchText by rememberSaveable { mutableStateOf("") }

    var newTitle by rememberSaveable { mutableStateOf("") }
    var newCategory by rememberSaveable { mutableStateOf("knowledge") }
    var newContent by rememberSaveable { mutableStateOf("") }
    var newTags by rememberSaveable { mutableStateOf("") }
    var newPinned by rememberSaveable { mutableStateOf(true) }

    var editingMemory by remember { mutableStateOf<CloudMemoryItem?>(null) }
    var editTitle by remember { mutableStateOf("") }
    var editCategory by remember { mutableStateOf("knowledge") }
    var editContent by remember { mutableStateOf("") }
    var editTags by remember { mutableStateOf("") }

    var localDocTitle by rememberSaveable { mutableStateOf("") }
    var localDocContent by rememberSaveable { mutableStateOf("") }
    var localSearchQuery by rememberSaveable { mutableStateOf(labState.knowledgeQuery) }

    if (editingMemory != null) {
        AlertDialog(
            onDismissRequest = { editingMemory = null },
            title = { Text("Edit Cloud Vault Memory") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("knowledge", "prompt_template", "preference", "code_snippet").forEach { cat ->
                            FilterChip(
                                selected = editCategory == cat,
                                onClick = { editCategory = cat },
                                label = { Text(cat) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = editContent,
                        onValueChange = { editContent = it },
                        label = { Text("Content") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editTags,
                        onValueChange = { editTags = it },
                        label = { Text("Tags (comma separated)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        editingMemory?.let {
                            onUpdateCloudMemory(it.id, editTitle, editCategory, editContent, editTags)
                        }
                        editingMemory = null
                    },
                    enabled = editTitle.isNotBlank() && editContent.isNotBlank()
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingMemory = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kişisel Bulut Kasası (Cloud Vault)", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Başlık / Not Adı") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("vault_title_input")
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("knowledge", "prompt_template", "preference", "code_snippet").forEach { cat ->
                            FilterChip(
                                selected = newCategory == cat,
                                onClick = { newCategory = cat },
                                label = { Text(cat) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = newContent,
                        onValueChange = { newContent = it },
                        label = { Text("İçerik") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("vault_content_input")
                    )
                    OutlinedTextField(
                        value = newTags,
                        onValueChange = { newTags = it },
                        label = { Text("Etiketler (virgülle ayır)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Stüdyo AI Bağlamına Sabitle", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = newPinned, onCheckedChange = { newPinned = it })
                    }
                    Button(
                        onClick = {
                            onAddCloudMemory(newTitle, newCategory, newContent, newTags, newPinned)
                            newTitle = ""
                            newContent = ""
                            newTags = ""
                        },
                        enabled = newTitle.isNotBlank() && newContent.isNotBlank(),
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("vault_save_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Kasaya Kaydet")
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    label = { Text("Bulut kasasında ara") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEach { cat ->
                        FilterChip(selected = filterCat == cat, onClick = { filterCat = cat }, label = { Text(cat) })
                    }
                }
            }
        }

        when (cloudMemoriesState) {
            is UiState.Loading -> item { CircularProgressIndicator() }
            is UiState.Error -> item { Text(cloudMemoriesState.message, color = RoseError) }
            is UiState.Success -> {
                val filtered = cloudMemoriesState.data.filter { item ->
                    val matchesCat = filterCat == "all" || item.category == filterCat
                    val q = searchText.trim().lowercase()
                    val matchesSearch = q.isEmpty() ||
                        item.title.lowercase().contains(q) ||
                        item.content.lowercase().contains(q) ||
                        item.tags.any { it.lowercase().contains(q) }
                    matchesCat && matchesSearch
                }
                items(filtered, key = { "cloud_mem_${it.id}" }) { item ->
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                        border = BorderStroke(
                            1.dp,
                            if (item.pinned) EmeraldVerified.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        TelemetryChip(label = item.category)
                                        if (item.pinned) TelemetryChip(label = "PINNED", accent = EmeraldVerified)
                                    }
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            editingMemory = item
                                            editTitle = item.title
                                            editCategory = item.category
                                            editContent = item.content
                                            editTags = item.tags.joinToString(", ")
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Edit,
                                            contentDescription = "Edit memory",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(onClick = { onToggleCloudMemoryPin(item) }) {
                                        Icon(
                                            imageVector = if (item.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                            contentDescription = "Pin",
                                            tint = if (item.pinned) EmeraldVerified else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { onDeleteCloudMemory(item.id) }) {
                                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete")
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(item.content, style = MaterialTheme.typography.bodySmall)
                            if (item.category == "prompt_template" || item.category == "code_snippet") {
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedButton(onClick = { onRunPromptTemplate(item.content) }) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Stüdyoda Çalıştır")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Local Offline Room Knowledge Indexer & Semantic Search
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Yerel Çevrimdışı Semantik İndeks (${knowledgeDocuments.size} Belge)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = localDocTitle,
                        onValueChange = { localDocTitle = it },
                        label = { Text("Yerel belge başlığı") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = localDocContent,
                        onValueChange = { localDocContent = it },
                        label = { Text("Çevrimdışı aranacak metin / kod notu") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            onAddKnowledgeDocument(localDocTitle, "user_local", localDocContent)
                            localDocTitle = ""
                            localDocContent = ""
                        },
                        enabled = localDocTitle.isNotBlank() && localDocContent.isNotBlank(),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Yerel İndekse Ekle")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = localSearchQuery,
                            onValueChange = { localSearchQuery = it },
                            label = { Text("Room indeksinde ara") },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("knowledge_search_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onSearchKnowledge(localSearchQuery) },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("knowledge_search_button")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = "Search")
                        }
                    }
                    labState.knowledgeSearchResults.forEach { hit: KnowledgeSearchHit ->
                        Text("• ${hit.document.title} (${(hit.similarityScore * 100).toInt()}%)", style = MaterialTheme.typography.bodySmall)
                    }
                    knowledgeDocuments.take(5).forEach { doc ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${doc.title} (${doc.languageCode})",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onDeleteKnowledgeDocument(doc.id) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete local doc", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
