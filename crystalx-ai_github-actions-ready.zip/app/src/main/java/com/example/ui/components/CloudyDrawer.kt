package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Contrast
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.genix.firebase.ConversationThread
import com.example.ui.GenixRoutes

/** ChatGPT-style side drawer: new chat, tools, conversation list and account footer. */
@Composable
fun CloudyDrawerContent(
    threads: List<ConversationThread>,
    activeConversationId: String?,
    currentRoute: String,
    userName: String,
    userEmail: String,
    planBadge: String,
    newChatLabel: String,
    historyLabel: String,
    modelsLabel: String,
    labLabel: String,
    settingsLabel: String,
    liveVoiceLabel: String,
    onNewChat: () -> Unit,
    onSelectConversation: (ConversationThread) -> Unit,
    onRenameConversation: (String, String) -> Unit,
    onTogglePin: (ConversationThread) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onCycleTheme: () -> Unit,
    onSignOut: () -> Unit
) {
    var renameTarget by remember { mutableStateOf<ConversationThread?>(null) }
    var renameDraft by remember { mutableStateOf("") }
    var accountMenuOpen by remember { mutableStateOf(false) }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Sohbeti yeniden adlandır") },
            text = {
                OutlinedTextField(
                    value = renameDraft,
                    onValueChange = { renameDraft = it },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameDraft.isNotBlank()) onRenameConversation(target.id, renameDraft.trim())
                        renameTarget = null
                    }
                ) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Vazgeç") } }
        )
    }

    ModalDrawerSheet(
        drawerContainerColor = MaterialTheme.colorScheme.background,
        drawerShape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CloudyAppLogo(size = 32.dp)
                Spacer(Modifier.width(12.dp))
                Text("Cloudy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            }

            DrawerRow(Icons.Outlined.AddComment, newChatLabel, selected = false, onClick = onNewChat, testTag = "drawer_new_chat")
            DrawerRow(Icons.Outlined.Image, modelsLabel, selected = currentRoute == GenixRoutes.ROUTE_MODELS, onClick = { onNavigate(GenixRoutes.ROUTE_MODELS) }, testTag = "nav_${GenixRoutes.ROUTE_MODELS}")
            DrawerRow(Icons.Outlined.GraphicEq, liveVoiceLabel, selected = currentRoute == GenixRoutes.ROUTE_LIVE, onClick = { onNavigate(GenixRoutes.ROUTE_LIVE) }, testTag = "nav_${GenixRoutes.ROUTE_LIVE}")
            DrawerRow(Icons.Outlined.Extension, labLabel, selected = currentRoute == GenixRoutes.ROUTE_LAB, onClick = { onNavigate(GenixRoutes.ROUTE_LAB) }, testTag = "nav_${GenixRoutes.ROUTE_LAB}")

            Spacer(Modifier.height(14.dp))
            Text(
                text = historyLabel,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )

            val sorted = remember(threads) { threads.sortedByDescending { it.pinned } }
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                if (sorted.isEmpty()) {
                    item {
                        Text(
                            text = "Henüz sohbet yok",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
                items(sorted, key = { it.id }) { thread ->
                    ThreadRow(
                        thread = thread,
                        selected = thread.id == activeConversationId && currentRoute == GenixRoutes.ROUTE_CORE,
                        onClick = { onSelectConversation(thread) },
                        onRename = {
                            renameDraft = thread.title
                            renameTarget = thread
                        },
                        onTogglePin = { onTogglePin(thread) },
                        onDelete = { onDeleteConversation(thread.id) }
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Box {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { accountMenuOpen = true }
                        .padding(horizontal = 8.dp, vertical = 12.dp)
                        .testTag("drawer_account"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.secondary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userName.firstOrNull()?.uppercase() ?: "C",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondary
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(userName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (userEmail.isNotBlank()) {
                            Text(
                                userEmail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                        Text(
                            planBadge,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                DropdownMenu(expanded = accountMenuOpen, onDismissRequest = { accountMenuOpen = false }) {
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
                        text = { Text(settingsLabel) },
                        onClick = { accountMenuOpen = false; onNavigate(GenixRoutes.ROUTE_SYSTEM) },
                        modifier = Modifier.testTag("nav_${GenixRoutes.ROUTE_SYSTEM}")
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Outlined.Contrast, contentDescription = null) },
                        text = { Text("Temayı değiştir") },
                        onClick = { accountMenuOpen = false; onCycleTheme() }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = null) },
                        text = { Text("Çıkış yap") },
                        onClick = { accountMenuOpen = false; onSignOut() },
                        modifier = Modifier.testTag("drawer_sign_out")
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerRow(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.background)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ThreadRow(
    thread: ConversationThread,
    selected: Boolean,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.background)
            .clickable(onClick = onClick)
            .padding(start = 12.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (thread.pinned) {
            Icon(Icons.Filled.PushPin, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = thread.title.ifBlank { "Yeni sohbet" },
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Box {
            IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Filled.MoreHoriz, contentDescription = "Sohbet seçenekleri", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Outlined.PushPin, contentDescription = null) },
                    text = { Text(if (thread.pinned) "Sabitlemeyi kaldır" else "Sabitle") },
                    onClick = { menuOpen = false; onTogglePin() }
                )
                DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                    text = { Text("Yeniden adlandır") },
                    onClick = { menuOpen = false; onRename() }
                )
                DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    text = { Text("Sil", color = MaterialTheme.colorScheme.error) },
                    onClick = { menuOpen = false; onDelete() }
                )
            }
        }
    }
}

/** Slim top bar for secondary pages (models, integrations, settings). */
@Composable
fun SecondaryPageTopBar(
    title: String,
    onOpenMenu: () -> Unit,
    onBackToChat: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.background) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onOpenMenu, modifier = Modifier.testTag("secondary_menu_button")) {
                Icon(Icons.Filled.Menu, contentDescription = "Menü")
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onBackToChat, modifier = Modifier.testTag("secondary_back_button")) {
                Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = "Sohbete dön")
            }
        }
    }
}
