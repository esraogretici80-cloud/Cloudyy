package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class AppThemeMode(
    val id: String,
    val tierLabel: String,
    val isPro: Boolean
) {
    SYSTEM(
        id = "SYSTEM",
        tierLabel = "AUTO",
        isPro = false
    ),
    LIGHT_WHITE(
        id = "LIGHT_WHITE",
        tierLabel = "FREE",
        isPro = false
    ),
    ICE_CRYSTAL_PRO(
        id = "ICE_CRYSTAL_PRO",
        tierLabel = "PRO",
        isPro = true
    ),
    DARK_OBSIDIAN(
        id = "DARK_OBSIDIAN",
        tierLabel = "FREE",
        isPro = false
    );

    companion object {
        fun fromId(raw: String?): AppThemeMode =
            entries.firstOrNull { it.id == raw || it.name == raw } ?: LIGHT_WHITE
    }
}

data class CloudyVisualStyle(
    val mode: AppThemeMode,
    val isDark: Boolean,
    val accentColor: Color,
    val backgroundBrush: Brush,
    val crystalAccentBrush: Brush,
    val borderBrush: Brush,
    val heroCardBrush: Brush,
    val glassAlpha: Float
)

val LocalCloudyStyle = staticCompositionLocalOf {
    CloudyVisualStyle(
        mode = AppThemeMode.LIGHT_WHITE,
        isDark = false,
        accentColor = CloudyAccentBlue,
        backgroundBrush = Brush.verticalGradient(listOf(WhiteBg, WhiteBg)),
        crystalAccentBrush = Brush.linearGradient(listOf(WhitePrimary, WhiteSecondary)),
        borderBrush = Brush.linearGradient(listOf(WhiteOutline, WhiteOutline)),
        heroCardBrush = Brush.verticalGradient(listOf(WhiteSurface, WhiteSurfaceVariant)),
        glassAlpha = 1f
    )
}

private val CloudyDarkColorScheme = darkColorScheme(
    primary = DarkMinimalPrimary,
    onPrimary = DarkMinimalOnPrimary,
    primaryContainer = DarkMinimalPrimaryContainer,
    onPrimaryContainer = DarkMinimalOnPrimaryContainer,
    secondary = DarkMinimalSecondary,
    onSecondary = DarkMinimalOnSecondary,
    secondaryContainer = DarkMinimalSecondaryContainer,
    onSecondaryContainer = DarkMinimalOnSecondaryContainer,
    tertiary = EmeraldVerified,
    onTertiary = EmeraldOnTertiary,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = EmeraldOnContainer,
    background = ObsidianBg,
    onBackground = SlateTextPrimary,
    surface = ObsidianSurface,
    onSurface = SlateTextPrimary,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = SlateTextSecondary,
    outline = ObsidianOutline,
    error = RoseError,
    onError = Color.White,
    errorContainer = RoseContainer,
    onErrorContainer = RoseOnContainer
)

private val CloudyWhiteColorScheme = lightColorScheme(
    primary = WhitePrimary,
    onPrimary = Color.White,
    primaryContainer = WhitePrimaryContainer,
    onPrimaryContainer = WhiteOnPrimaryContainer,
    secondary = WhiteSecondary,
    onSecondary = Color.White,
    secondaryContainer = WhiteSecondaryContainer,
    onSecondaryContainer = WhiteOnSecondaryContainer,
    tertiary = WhiteTertiary,
    onTertiary = Color.White,
    tertiaryContainer = WhiteTertiaryContainer,
    onTertiaryContainer = WhiteOnTertiaryContainer,
    background = WhiteBg,
    onBackground = WhiteTextPrimary,
    surface = WhiteSurface,
    onSurface = WhiteTextPrimary,
    surfaceVariant = WhiteSurfaceVariant,
    onSurfaceVariant = WhiteTextSecondary,
    outline = WhiteOutline,
    error = RoseError,
    onError = Color.White,
    errorContainer = RoseOnContainer,
    onErrorContainer = RoseContainer
)

private val CloudyIceCrystalColorScheme = lightColorScheme(
    primary = IcePrimary,
    onPrimary = Color.White,
    primaryContainer = IcePrimaryContainer,
    onPrimaryContainer = IceOnPrimaryContainer,
    secondary = IceSecondary,
    onSecondary = Color.White,
    secondaryContainer = IceSecondaryContainer,
    onSecondaryContainer = IceOnSecondaryContainer,
    tertiary = IceTertiary,
    onTertiary = Color.White,
    tertiaryContainer = IceTertiaryContainer,
    onTertiaryContainer = IceOnTertiaryContainer,
    background = IceCrystalBg,
    onBackground = IceTextPrimary,
    surface = IceCrystalSurface,
    onSurface = IceTextPrimary,
    surfaceVariant = IceCrystalSurfaceVariant,
    onSurfaceVariant = IceTextSecondary,
    outline = IceCrystalOutline,
    error = RoseError,
    onError = Color.White,
    errorContainer = RoseOnContainer,
    onErrorContainer = RoseContainer
)

val GenixShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun GenixTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val resolvedMode = when (themeMode) {
        AppThemeMode.SYSTEM -> if (systemDark) AppThemeMode.DARK_OBSIDIAN else AppThemeMode.LIGHT_WHITE
        AppThemeMode.DARK_OBSIDIAN -> if (darkTheme) AppThemeMode.DARK_OBSIDIAN else AppThemeMode.DARK_OBSIDIAN
        else -> themeMode
    }

    val colorScheme = when (resolvedMode) {
        AppThemeMode.LIGHT_WHITE -> CloudyWhiteColorScheme
        AppThemeMode.ICE_CRYSTAL_PRO -> CloudyIceCrystalColorScheme
        AppThemeMode.DARK_OBSIDIAN -> CloudyDarkColorScheme
        AppThemeMode.SYSTEM -> if (systemDark) CloudyDarkColorScheme else CloudyWhiteColorScheme
    }

    val visualStyle = when (resolvedMode) {
        AppThemeMode.ICE_CRYSTAL_PRO -> CloudyVisualStyle(
            mode = themeMode,
            isDark = false,
            accentColor = IcePrimary,
            backgroundBrush = Brush.verticalGradient(
                listOf(Color(0xFFEDF6FC), Color(0xFFE3F1FA), Color(0xFFD9ECFA))
            ),
            crystalAccentBrush = Brush.linearGradient(
                listOf(Color(0xFF0369A1), Color(0xFF0891B2), Color(0xFF38BDF8))
            ),
            borderBrush = Brush.linearGradient(
                listOf(Color(0xFFFFFFFF), Color(0xFFAADAF5), Color(0xFF7CCDF8))
            ),
            heroCardBrush = Brush.verticalGradient(
                listOf(Color(0xFFF8FCFF), Color(0xFFE7F4FC))
            ),
            glassAlpha = 0.92f
        )
        AppThemeMode.DARK_OBSIDIAN -> CloudyVisualStyle(
            mode = themeMode,
            isDark = true,
            accentColor = CloudyAccentBlueDark,
            backgroundBrush = Brush.verticalGradient(listOf(ObsidianBg, ObsidianBg)),
            crystalAccentBrush = Brush.linearGradient(listOf(CloudyAccentBlueDark, Color(0xFF7AA7FF))),
            borderBrush = Brush.linearGradient(listOf(ObsidianOutline, ObsidianOutline)),
            heroCardBrush = Brush.verticalGradient(listOf(ObsidianSurface, ObsidianSurface)),
            glassAlpha = 1f
        )
        else -> CloudyVisualStyle(
            mode = themeMode,
            isDark = false,
            accentColor = CloudyAccentBlue,
            backgroundBrush = Brush.verticalGradient(listOf(WhiteBg, WhiteBg)),
            crystalAccentBrush = Brush.linearGradient(listOf(CloudyAccentBlue, Color(0xFF5B8DEF))),
            borderBrush = Brush.linearGradient(listOf(WhiteOutline, WhiteOutline)),
            heroCardBrush = Brush.verticalGradient(listOf(WhiteSurface, WhiteSurface)),
            glassAlpha = 1f
        )
    }

    CompositionLocalProvider(LocalCloudyStyle provides visualStyle) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = GenixTypography,
            shapes = GenixShapes,
            content = content
        )
    }
}
