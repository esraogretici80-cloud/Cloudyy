package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.HorizontalDivider
import com.example.ui.builder.BuilderArtifacts
import com.example.ui.builder.BuilderPreviewDialog
import com.example.ui.builder.BuilderRunCard
import com.example.ui.components.CloudyAppLogo
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.genix.ai.core.CloudyAiModel
import com.example.genix.ai.core.ModelAvailabilityStatus
import com.example.genix.ai.multimodal.ExtractedDocumentPayload
import com.example.genix.core.GenixConfig
import com.example.genix.firebase.AppCheckDiagnostics
import com.example.genix.firebase.CloudMessage
import com.example.genix.firebase.CloudyIntegrationsEngine
import com.example.genix.firebase.ConversationThread
import com.example.genix.firebase.CrystalXModelId
import com.example.genix.intelligence.language.HomeUiStrings
import com.example.genix.intelligence.language.LocalizedUiStrings
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.genix.voice.CloudyVoicePersona
import com.example.genix.voice.VoicePlaybackState
import com.example.ui.UiState
import com.example.ui.components.CloudyMinimalCloudMark
import com.example.ui.components.HistoryDrawerSheet
import com.example.ui.components.ModelSelectorSheet
import com.example.ui.components.PulsingStatusDot
import com.example.ui.components.RichMarkdownText
import com.example.ui.components.TelemetryChip
import com.example.ui.components.VerificationBadge
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCloudyStyle
import com.example.ui.theme.RoseError
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CoreConsoleScreen(
    uiStrings: LocalizedUiStrings,
    homeStrings: HomeUiStrings,
    config: GenixConfig,
    selectedModel: CrystalXModelId,
    activePlatformModel: CloudyAiModel,
    platformModels: List<CloudyAiModel>,
    availabilityProvider: (CloudyAiModel) -> ModelAvailabilityStatus,
    conversationsState: UiState<List<ConversationThread>>,
    activeConversationId: String?,
    cloudMessagesState: UiState<List<CloudMessage>>,
    streamingText: String?,
    streamingModelLabel: String?,
    attachedIntegrationNotes: List<String>,
    attachedImages: List<Bitmap>,
    attachedDocument: ExtractedDocumentPayload?,
    webSearchEnabled: Boolean,
    codingModeEnabled: Boolean,
    hasAppCheckIssue: Boolean,
    appCheckDiagnostics: AppCheckDiagnostics,
    isProcessing: Boolean,
    voicePlaybackState: VoicePlaybackState,
    estimateTokens: (String) -> Int,
    onSelectModel: (CrystalXModelId) -> Unit,
    onSelectPlatformModel: (CloudyAiModel) -> Unit,
    onToggleAutoRoute: (Boolean) -> Unit,
    onSpeakMessage: (CloudMessage) -> Unit,
    onStopSpeaking: () -> Unit,
    onVerifyAppCheck: () -> Unit,
    onCycleTheme: () -> Unit,
    onSelectConversation: (ConversationThread) -> Unit,
    onCreateConversation: () -> Unit,
    onRenameConversation: (conversationId: String, newTitle: String) -> Unit,
    onToggleConversationPin: (ConversationThread) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onToggleMessageStar: (CloudMessage) -> Unit,
    onSendToWebhooks: (CloudMessage) -> Unit,
    onEditUserMessageAndResend: (CloudMessage, String) -> Unit,
    onRegenerateMessage: (CloudMessage) -> Unit,
    onContinueMessage: (CloudMessage) -> Unit,
    onStopGeneration: () -> Unit,
    onClearAttachedNotes: () -> Unit,
    onAttachImagesUris: (List<Uri>) -> Unit,
    onClearAttachedImages: () -> Unit,
    onAttachDocumentUri: (Uri) -> Unit,
    onClearAttachedDocument: () -> Unit,
    onToggleWebSearch: () -> Unit,
    onToggleCodingMode: () -> Unit,
    onOpenLiveVoice: () -> Unit,
    onOpenImageStudio: () -> Unit,
    onSendPrompt: (String) -> Unit,
    modifier: Modifier = Modifier,
    onOpenDrawer: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val cloudyStyle = LocalCloudyStyle.current

    var inputText by rememberSaveable { mutableStateOf("") }
    var showModelSelector by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var searchVisible by rememberSaveable { mutableStateOf(false) }
    var starredOnly by rememberSaveable { mutableStateOf(false) }
    var messageSearchQuery by rememberSaveable { mutableStateOf("") }
    var selectableMessageId by remember { mutableStateOf<String?>(null) }

    var messageToEdit by remember { mutableStateOf<CloudMessage?>(null) }
    var editDraft by remember { mutableStateOf("") }

    var isListeningMic by remember { mutableStateOf(false) }
    var micStatusNote by remember { mutableStateOf<String?>(null) }

    val listState = rememberLazyListState()
    val country = MultilingualLanguageSystem.countryForCode(config.countryCode)
    val activeVoicePersona = CloudyVoicePersona.fromId(config.voiceProfileId)

    // Zero-Permission Photo Picker (Multi-select up to 4 images)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 4)
    ) { uris ->
        if (uris.isNotEmpty()) {
            onAttachImagesUris(uris)
        }
    }

    // SAF Document Picker (PDF, DOCX, TXT, MD, CSV, JSON, Code)
    val docPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onAttachDocumentUri(uri)
        }
    }

    val launchDocumentPicker = {
        docPickerLauncher.launch(
            arrayOf(
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "text/*",
                "application/json"
            )
        )
    }

    val launchPhotoPicker = {
        photoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    // Inline STT Mic Dictation
    val speechRecognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            runCatching { SpeechRecognizer.createSpeechRecognizer(context) }.getOrNull()
        } else null
    }

    DisposableEffect(speechRecognizer) {
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningMic = true
                micStatusNote = "Listening..."
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListeningMic = false
            }
            override fun onError(error: Int) {
                isListeningMic = false
                micStatusNote = "Mic standby ($error)"
            }
            override fun onResults(results: Bundle?) {
                isListeningMic = false
                micStatusNote = null
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!partial.isNullOrBlank()) {
                    inputText = partial
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        onDispose { runCatching { speechRecognizer?.destroy() } }
    }

    val startVoiceDictation: () -> Unit = {
        if (speechRecognizer == null) {
            micStatusNote = "Speech recognition unavailable on device; use Live Voice or type."
        } else if (isListeningMic) {
            runCatching { speechRecognizer.stopListening() }
            isListeningMic = false
            micStatusNote = null
        } else {
            onStopSpeaking()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, country.localeTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            runCatching {
                speechRecognizer.startListening(intent)
                isListeningMic = true
                micStatusNote = "Listening..."
            }.onFailure {
                isListeningMic = false
                micStatusNote = "Could not start microphone."
            }
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceDictation() else micStatusNote = "Microphone permission denied."
    }

    val onMicTap: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) startVoiceDictation() else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val allMessages = (cloudMessagesState as? UiState.Success)?.data.orEmpty()
    val visibleMessages = remember(allMessages, starredOnly, messageSearchQuery) {
        val q = messageSearchQuery.trim().lowercase()
        allMessages.filter { msg ->
            (!starredOnly || msg.starred) &&
                (q.isEmpty() || msg.content.lowercase().contains(q) || msg.modelLabel.lowercase().contains(q))
        }
    }
    val threads = (conversationsState as? UiState.Success)?.data.orEmpty()
    val activeThread = threads.firstOrNull { it.id == activeConversationId }

    LaunchedEffect(visibleMessages.size, streamingText != null) {
        val total = visibleMessages.size + if (streamingText != null) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    // Modal Bottom Sheets
    if (showModelSelector) {
        ModelSelectorSheet(
            models = platformModels,
            selectedModelId = activePlatformModel.id,
            autoRouteEnabled = config.autoRouteEnabled,
            availabilityProvider = availabilityProvider,
            onToggleAutoRoute = onToggleAutoRoute,
            onSelectModel = onSelectPlatformModel,
            onDismiss = { showModelSelector = false }
        )
    }

    if (showHistorySheet) {
        HistoryDrawerSheet(
            threads = threads,
            activeConversationId = activeConversationId,
            homeStrings = homeStrings,
            onCreateNewConversation = onCreateConversation,
            onSelectConversation = onSelectConversation,
            onRenameConversation = onRenameConversation,
            onTogglePin = onToggleConversationPin,
            onDeleteConversation = onDeleteConversation,
            onDismiss = { showHistorySheet = false }
        )
    }

    // Edit User Message Dialog
    if (messageToEdit != null) {
        AlertDialog(
            onDismissRequest = { messageToEdit = null },
            title = { Text(homeStrings.editLabel) },
            text = {
                OutlinedTextField(
                    value = editDraft,
                    onValueChange = { editDraft = it },
                    minLines = 2,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth().testTag("edit_message_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        messageToEdit?.let { onEditUserMessageAndResend(it, editDraft) }
                        messageToEdit = null
                    },
                    enabled = editDraft.isNotBlank() && !isProcessing
                ) {
                    Text(uiStrings.sendLabel)
                }
            },
            dismissButton = {
                TextButton(onClick = { messageToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(cloudyStyle.backgroundBrush)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 840.dp)
                    .fillMaxSize()
            ) {
                Spacer(modifier = Modifier.height(6.dp))

                // ChatGPT-style top bar: menu • model pill • new chat
                ChatTopBar(
                    activeModelName = activePlatformModel.displayName,
                    autoRouteEnabled = config.autoRouteEnabled,
                    hasMessages = allMessages.isNotEmpty(),
                    searchVisible = searchVisible,
                    onOpenMenu = { if (onOpenDrawer != null) onOpenDrawer() else showHistorySheet = true },
                    onOpenModelSelector = { showModelSelector = true },
                    onToggleSearch = {
                        searchVisible = !searchVisible
                        if (!searchVisible) messageSearchQuery = ""
                    },
                    onNewChat = onCreateConversation
                )

                // Search & Thread Utility Bar when active
                AnimatedVisibility(visible = searchVisible) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = messageSearchQuery,
                            onValueChange = { messageSearchQuery = it },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            trailingIcon = {
                                if (messageSearchQuery.isNotEmpty()) {
                                    IconButton(onClick = { messageSearchQuery = "" }) {
                                        Icon(Icons.Filled.Close, contentDescription = "Clear search")
                                    }
                                }
                            },
                            placeholder = { Text(homeStrings.searchHistoryHint) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).testTag("thread_search_input")
                        )
                        FilterChip(
                            selected = starredOnly,
                            onClick = { starredOnly = !starredOnly },
                            leadingIcon = { Icon(Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(15.dp)) },
                            label = { Text("Starred") },
                            modifier = Modifier.testTag("filter_starred_chip")
                        )
                        if (allMessages.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    val transcript = buildString {
                                        append("# Cloudy — ${activeThread?.title ?: "Chat"}\n\n")
                                        allMessages.forEach { m ->
                                            append("## ${if (m.role == "user") "You" else m.modelLabel}\n")
                                            append(m.content).append("\n\n")
                                        }
                                    }
                                    CloudyIntegrationsEngine.shareTextViaAndroidSheet(
                                        context = context,
                                        title = activeThread?.title ?: "Cloudy Chat",
                                        content = transcript
                                    )
                                },
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("export_thread_button")
                            ) {
                                Icon(Icons.Filled.IosShare, contentDescription = "Export conversation")
                            }
                        }
                    }
                }

                // Integration Context Banner
                if (attachedIntegrationNotes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${attachedIntegrationNotes.size} live integration context attached",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = onClearAttachedNotes, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear context", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Main Content Canvas (Welcome Home OR Advanced Chat Stream)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (cloudMessagesState) {
                        is UiState.Loading -> {
                            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                        }
                        is UiState.Error -> {
                            Surface(
                                shape = MaterialTheme.shapes.large,
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier.align(Alignment.Center).padding(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Cloud Sync Notice", style = MaterialTheme.typography.titleMedium)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(cloudMessagesState.message, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        is UiState.Success -> {
                            if (visibleMessages.isEmpty() && streamingText == null) {
                                CloudyWelcome(
                                    greeting = homeStrings.greetingTitle,
                                    suggestions = listOf(
                                        WelcomeSuggestion(Icons.Outlined.Image, homeStrings.imageGenShortcut, "home_shortcut_image", onOpenImageStudio),
                                        WelcomeSuggestion(Icons.Outlined.GraphicEq, homeStrings.liveVoiceShortcut, "home_shortcut_live", onOpenLiveVoice),
                                        WelcomeSuggestion(Icons.Outlined.AddPhotoAlternate, homeStrings.attachPhotoShortcut, "home_shortcut_photo", launchPhotoPicker),
                                        WelcomeSuggestion(Icons.Outlined.Description, homeStrings.attachDocShortcut, "home_shortcut_doc", launchDocumentPicker)
                                    ),
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                LazyColumn(
                                    state = listState,
                                    verticalArrangement = Arrangement.spacedBy(22.dp),
                                    contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp, start = 4.dp, end = 4.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(visibleMessages, key = { it.id }) { msg ->
                                        val isSpeakingThis = voicePlaybackState.isSpeaking && voicePlaybackState.activeMessageId == msg.id
                                        val isSelectable = selectableMessageId == msg.id
                                        CloudMessageBubble(
                                            msg = msg,
                                            homeStrings = homeStrings,
                                            tokenCount = estimateTokens(msg.content),
                                            isCurrentlySpeaking = isSpeakingThis,
                                            activeVoiceName = activeVoicePersona.displayName,
                                            isSelectable = isSelectable,
                                            isProcessing = isProcessing,
                                            onEditUserMessage = {
                                                editDraft = msg.content
                                                messageToEdit = msg
                                            },
                                            onToggleSelectable = {
                                                selectableMessageId = if (isSelectable) null else msg.id
                                            },
                                            onSpeakOrStop = {
                                                if (isSpeakingThis) onStopSpeaking() else onSpeakMessage(msg)
                                            },
                                            onCopy = {
                                                CloudyIntegrationsEngine.copyToClipboard(context, "Cloudy", msg.content)
                                            },
                                            onRegenerate = { onRegenerateMessage(msg) },
                                            onContinue = { onContinueMessage(msg) },
                                            onToggleStar = { onToggleMessageStar(msg) },
                                            onShare = {
                                                CloudyIntegrationsEngine.shareTextViaAndroidSheet(
                                                    context = context,
                                                    title = "Cloudy AI",
                                                    content = msg.content
                                                )
                                            },
                                            onSendWebhook = { onSendToWebhooks(msg) },
                                            modifier = Modifier.animateItem()
                                        )
                                    }

                                    if (streamingText != null) {
                                        item(key = "streaming_bubble") {
                                            StreamingMessageCard(
                                                modelLabel = streamingModelLabel ?: activePlatformModel.displayName,
                                                content = streamingText
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Pending Multi-Image Attachment Strip
                if (attachedImages.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(attachedImages.size) { idx ->
                                    Image(
                                        bitmap = attachedImages[idx].asImageBitmap(),
                                        contentDescription = "Attached image ${idx + 1}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                                    )
                                }
                            }
                            Text(
                                text = "${attachedImages.size} img",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                            IconButton(onClick = onClearAttachedImages, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear images", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                // Pending Document Attachment Pill
                if (attachedDocument != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Description, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = attachedDocument.summaryNote,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = onClearAttachedDocument, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove document", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                // Active tool chips (only shown while a tool is on)
                if (webSearchEnabled || codingModeEnabled || !micStatusNote.isNullOrBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp, start = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (webSearchEnabled) {
                            ActiveToolChip(Icons.Filled.Public, homeStrings.webSearchLabel, onToggleWebSearch, "toggle_web_search_chip")
                        }
                        if (codingModeEnabled) {
                            ActiveToolChip(Icons.Filled.Code, homeStrings.codingModeLabel, onToggleCodingMode, "toggle_coding_mode_chip")
                        }
                        if (!micStatusNote.isNullOrBlank()) {
                            Text(
                                text = micStatusNote!!,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                val canSend = inputText.isNotBlank() || attachedImages.isNotEmpty() || attachedDocument != null
                val sendNow: () -> Unit = {
                    if (canSend && !isProcessing) {
                        onSendPrompt(inputText)
                        inputText = ""
                    }
                }

                // ChatGPT-style rounded composer
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = if (cloudyStyle.isDark) 0.dp else 8.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (cloudyStyle.isDark) 1f else 0.7f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Box {
                            IconButton(
                                onClick = { showAttachmentMenu = true },
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("composer_attach_menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Ekler ve araçlar",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            DropdownMenu(
                                expanded = showAttachmentMenu,
                                onDismissRequest = { showAttachmentMenu = false },
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.AddPhotoAlternate, contentDescription = null) },
                                    text = { Text(homeStrings.attachPhotoShortcut) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        launchPhotoPicker()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Filled.AttachFile, contentDescription = null) },
                                    text = { Text(homeStrings.attachDocShortcut) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        launchDocumentPicker()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.Image, contentDescription = null) },
                                    text = { Text(homeStrings.imageGenShortcut) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        onOpenImageStudio()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.GraphicEq, contentDescription = null) },
                                    text = { Text(homeStrings.liveVoiceShortcut) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        onOpenLiveVoice()
                                    }
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Filled.Public, contentDescription = null) },
                                    text = { Text(homeStrings.webSearchLabel) },
                                    trailingIcon = { if (webSearchEnabled) Icon(Icons.Filled.Check, contentDescription = null) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        onToggleWebSearch()
                                    }
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Filled.Code, contentDescription = null) },
                                    text = { Text(homeStrings.codingModeLabel) },
                                    trailingIcon = { if (codingModeEnabled) Icon(Icons.Filled.Check, contentDescription = null) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        onToggleCodingMode()
                                    }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    text = uiStrings.promptHint,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            textStyle = MaterialTheme.typography.bodyLarge,
                            minLines = 1,
                            maxLines = 6,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { sendNow() }),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.weight(1f).testTag("core_prompt_input")
                        )

                        IconButton(
                            onClick = onMicTap,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("voice_live_mic_button")
                        ) {
                            Icon(
                                imageVector = if (isListeningMic) Icons.Filled.MicOff else Icons.Outlined.Mic,
                                contentDescription = "Sesle yaz",
                                tint = if (isListeningMic) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        when {
                            isProcessing -> ComposerRoundButton(
                                icon = Icons.Filled.Stop,
                                contentDescription = homeStrings.stopGeneratingLabel,
                                container = MaterialTheme.colorScheme.onSurface,
                                content = MaterialTheme.colorScheme.surface,
                                onClick = onStopGeneration,
                                testTag = "stop_generating_button"
                            )
                            canSend -> ComposerRoundButton(
                                icon = Icons.Filled.ArrowUpward,
                                contentDescription = stringResource(R.string.cd_send_request),
                                container = MaterialTheme.colorScheme.onSurface,
                                content = MaterialTheme.colorScheme.surface,
                                onClick = sendNow,
                                testTag = "core_send_button"
                            )
                            else -> ComposerRoundButton(
                                icon = Icons.Filled.GraphicEq,
                                contentDescription = homeStrings.liveVoiceShortcut,
                                container = MaterialTheme.colorScheme.secondary,
                                content = MaterialTheme.colorScheme.onSecondary,
                                onClick = onOpenLiveVoice,
                                testTag = "composer_live_button"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CircleActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    testTag: String
) {
    val dark = LocalCloudyStyle.current.isDark
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = if (dark) 0.dp else 6.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (dark) 1f else 0.7f)),
        modifier = Modifier.size(48.dp).testTag(testTag)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = contentDescription, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun ChatTopBar(
    activeModelName: String,
    autoRouteEnabled: Boolean,
    hasMessages: Boolean,
    searchVisible: Boolean,
    onOpenMenu: () -> Unit,
    onOpenModelSelector: () -> Unit,
    onToggleSearch: () -> Unit,
    onNewChat: () -> Unit
) {
    val dark = LocalCloudyStyle.current.isDark
    val accent = MaterialTheme.colorScheme.secondary
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircleActionButton(Icons.Filled.Menu, "Menü", onOpenMenu, "history_drawer_button")
        Spacer(modifier = Modifier.width(10.dp))
        Box(modifier = Modifier.weight(1f)) {
            Surface(
                onClick = onOpenModelSelector,
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = if (dark) 0.dp else 6.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (dark) 1f else 0.7f)),
                modifier = Modifier.height(48.dp).testTag("model_selector_pill")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxHeight(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
                    Text(
                        text = if (autoRouteEnabled) "Auto · $activeModelName" else activeModelName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = accent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 190.dp)
                    )
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Model seç", tint = accent, modifier = Modifier.size(18.dp))
                }
            }
        }
        if (hasMessages) {
            IconButton(
                onClick = onToggleSearch,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("toggle_search_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Sohbette ara",
                    tint = if (searchVisible) accent else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        CircleActionButton(Icons.Outlined.AddComment, "Yeni sohbet", onNewChat, "new_thread_button")
    }
}

private data class WelcomeSuggestion(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val testTag: String,
    val onClick: () -> Unit
)

@Composable
private fun CloudyWelcome(
    greeting: String,
    suggestions: List<WelcomeSuggestion>,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CloudyAppLogo(size = 52.dp)
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = greeting,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        }
        suggestions.forEach { suggestion ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = suggestion.onClick)
                    .padding(horizontal = 14.dp, vertical = 14.dp)
                    .testTag(suggestion.testTag),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = suggestion.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(18.dp))
                Text(
                    text = suggestion.label,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
private fun ActiveToolChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onRemove: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onRemove,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        modifier = Modifier.testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(start = 10.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(15.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
            Icon(Icons.Filled.Close, contentDescription = "Kapat", modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun ComposerRoundButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    container: Color,
    content: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = container,
        contentColor = content,
        modifier = Modifier.padding(start = 2.dp, end = 2.dp, bottom = 2.dp).size(44.dp).testTag(testTag)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = contentDescription, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun MessageActionIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    IconButton(onClick = onClick, modifier = Modifier.size(36.dp)) {
        Icon(icon, contentDescription = contentDescription, tint = tint, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun CloudMessageBubble(
    msg: CloudMessage,
    homeStrings: HomeUiStrings,
    tokenCount: Int,
    isCurrentlySpeaking: Boolean,
    activeVoiceName: String,
    isSelectable: Boolean,
    isProcessing: Boolean,
    onEditUserMessage: () -> Unit,
    onToggleSelectable: () -> Unit,
    onSpeakOrStop: () -> Unit,
    onCopy: () -> Unit,
    onRegenerate: () -> Unit,
    onContinue: () -> Unit,
    onToggleStar: () -> Unit,
    onShare: () -> Unit,
    onSendWebhook: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = msg.role == "user"
    var moreMenuOpen by remember { mutableStateOf(false) }

    if (isUser) {
        Column(
            modifier = modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.padding(start = 56.dp).widthIn(max = 560.dp)
            ) {
                Text(
                    text = msg.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp)
                )
            }
            if (!isProcessing) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MessageActionIcon(Icons.Outlined.ContentCopy, homeStrings.copyLabel, onCopy)
                    MessageActionIcon(Icons.Outlined.Edit, homeStrings.editLabel, onEditUserMessage)
                }
            }
        }
        return
    }

    val runnableHtml = remember(msg.content) { BuilderArtifacts.extractRunnableHtml(msg.content) }
    var showBuilderPreview by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        RichMarkdownText(
            markdown = msg.content,
            textColor = MaterialTheme.colorScheme.onSurface,
            selectable = isSelectable
        )
        if (runnableHtml != null) {
            Spacer(modifier = Modifier.height(8.dp))
            BuilderRunCard(
                title = BuilderArtifacts.titleOf(runnableHtml),
                onRun = { showBuilderPreview = true }
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.offset(x = (-8).dp)
        ) {
            MessageActionIcon(Icons.Outlined.ContentCopy, homeStrings.copyLabel, onCopy)
            MessageActionIcon(
                icon = if (isCurrentlySpeaking) Icons.Filled.Stop else Icons.AutoMirrored.Outlined.VolumeUp,
                contentDescription = if (isCurrentlySpeaking) "Durdur" else "Sesli oku ($activeVoiceName)",
                onClick = onSpeakOrStop,
                tint = if (isCurrentlySpeaking) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!isProcessing) {
                MessageActionIcon(Icons.Filled.Refresh, homeStrings.regenerateLabel, onRegenerate)
            }
            MessageActionIcon(
                icon = if (msg.starred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                contentDescription = "Yer işareti",
                onClick = onToggleStar,
                tint = if (msg.starred) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            MessageActionIcon(Icons.Outlined.Share, "Paylaş", onShare)
            Box {
                MessageActionIcon(Icons.Filled.MoreHoriz, "Diğer", { moreMenuOpen = true })
                DropdownMenu(expanded = moreMenuOpen, onDismissRequest = { moreMenuOpen = false }) {
                    if (!isProcessing) {
                        DropdownMenuItem(
                            leadingIcon = { Icon(Icons.Filled.PlayArrow, contentDescription = null) },
                            text = { Text(homeStrings.continueLabel) },
                            onClick = { moreMenuOpen = false; onContinue() }
                        )
                    }
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Filled.SelectAll, contentDescription = null) },
                        text = { Text(if (isSelectable) "Seçimi kapat" else "Metni seç") },
                        onClick = { moreMenuOpen = false; onToggleSelectable() }
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Filled.Http, contentDescription = null) },
                        text = { Text("Webhook'a gönder") },
                        onClick = { moreMenuOpen = false; onSendWebhook() }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "${msg.modelLabel} · ~$tokenCount token",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        enabled = false,
                        onClick = {}
                    )
                }
            }
        }
    }

    if (showBuilderPreview && runnableHtml != null) {
        BuilderPreviewDialog(
            title = BuilderArtifacts.titleOf(runnableHtml),
            html = runnableHtml,
            onDismiss = { showBuilderPreview = false }
        )
    }
}

@Composable
private fun StreamingMessageCard(
    modelLabel: String,
    content: String
) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        if (content.isBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                PulsingStatusDot(color = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = modelLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            RichMarkdownText(
                markdown = content,
                textColor = MaterialTheme.colorScheme.onSurface,
                selectable = false
            )
        }
    }
}
