package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.automirrored.filled.AltRoute
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Token
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.genix.ai.core.AiModelCategory
import com.example.genix.ai.core.CloudyAiModel
import com.example.genix.ai.core.ModelAvailabilityStatus
import com.example.genix.ai.multimodal.CloudyImageModelOption
import com.example.genix.ai.multimodal.ExtractedDocumentPayload
import com.example.genix.ai.multimodal.ImageAspectOption
import com.example.genix.core.RoutingDecision
import com.example.genix.core.SubscriptionPlan
import com.example.genix.memory.DocumentArtifactEntity
import com.example.genix.memory.GeneratedImageEntity
import com.example.genix.models.ModelLoadState
import com.example.genix.models.RegisteredModel
import com.example.genix.training.ExperimentalTransformerSpec
import com.example.genix.training.TransformerArchitectureConfig
import com.example.ui.LabState
import com.example.ui.StudioImageGenState
import com.example.ui.components.EmptyPlaceholderCard
import com.example.ui.components.MetricProgressRow
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryChip
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCloudyStyle
import com.example.ui.theme.RoseError
import java.util.Locale

@Composable
fun ModelsRouterScreen(
    models: List<RegisteredModel>,
    loadedMemoryMb: Int,
    activePlatformModel: CloudyAiModel,
    platformModels: List<CloudyAiModel>,
    availabilityProvider: (CloudyAiModel) -> ModelAvailabilityStatus,
    currentPlan: SubscriptionPlan,
    routerPreview: RoutingDecision?,
    labState: LabState,
    studioImageState: StudioImageGenState,
    generatedImages: List<GeneratedImageEntity>,
    attachedDocument: ExtractedDocumentPayload?,
    documentArtifacts: List<DocumentArtifactEntity>,
    onActivatePlatformModel: (CloudyAiModel) -> Unit,
    onOpenPlanSettings: () -> Unit,
    onToggleLoad: (String) -> Unit,
    onHealthCheck: (String) -> Unit,
    onSimulateRoute: (String) -> Unit,
    onTokenizerInputChange: (String) -> Unit,
    onSelectTransformerPreset: (TransformerArchitectureConfig) -> Unit,
    onAnalyzeCode: (String) -> Unit,
    onGenerateStudioImage: (String, CloudyImageModelOption, ImageAspectOption, Bitmap?) -> Unit,
    onExportImageToGallery: (GeneratedImageEntity) -> Unit,
    onDeleteGeneratedImage: (Long) -> Unit,
    onAttachDocumentUri: (Uri) -> Unit,
    onDeleteDocumentArtifact: (Long) -> Unit,
    onAskAboutDocument: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val cloudyStyle = LocalCloudyStyle.current
    var selectedSegment by rememberSaveable { mutableIntStateOf(0) }
    val segments = listOf(
        "Image Studio",
        "Document Lab",
        "Models & Router",
        "Code & Tokenizer"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(cloudyStyle.backgroundBrush)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 840.dp).fillMaxSize()) {
                Spacer(modifier = Modifier.height(10.dp))
                SectionHeader(
                    title = "Cloudy Studio Hub",
                    subtitle = "Image Generation • Document Intelligence • Multi-Model Router • Code & Tokenizer"
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    items(segments.size) { index ->
                        FilterChip(
                            selected = selectedSegment == index,
                            onClick = { selectedSegment = index },
                            label = { Text(segments[index], style = MaterialTheme.typography.labelLarge) },
                            modifier = Modifier.testTag("models_tab_$index")
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                when (selectedSegment) {
                    0 -> ImageStudioTab(
                        currentPlan = currentPlan,
                        studioImageState = studioImageState,
                        generatedImages = generatedImages,
                        onGenerateStudioImage = onGenerateStudioImage,
                        onExportImageToGallery = onExportImageToGallery,
                        onDeleteGeneratedImage = onDeleteGeneratedImage,
                        onOpenPlanSettings = onOpenPlanSettings
                    )
                    1 -> DocumentLabTab(
                        attachedDocument = attachedDocument,
                        documentArtifacts = documentArtifacts,
                        onAttachDocumentUri = onAttachDocumentUri,
                        onDeleteDocumentArtifact = onDeleteDocumentArtifact,
                        onAskAboutDocument = onAskAboutDocument
                    )
                    2 -> ModelsCatalogList(
                        models = models,
                        loadedMemoryMb = loadedMemoryMb,
                        activePlatformModel = activePlatformModel,
                        platformModels = platformModels,
                        availabilityProvider = availabilityProvider,
                        currentPlan = currentPlan,
                        routerPreview = routerPreview,
                        onActivatePlatformModel = onActivatePlatformModel,
                        onOpenPlanSettings = onOpenPlanSettings,
                        onToggleLoad = onToggleLoad,
                        onHealthCheck = onHealthCheck,
                        onSimulateRoute = onSimulateRoute
                    )
                    else -> TokenizerAndCodeLabList(
                        labState = labState,
                        onTokenizerInputChange = onTokenizerInputChange,
                        onSelectTransformerPreset = onSelectTransformerPreset,
                        onAnalyzeCode = onAnalyzeCode
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ImageStudioTab(
    currentPlan: SubscriptionPlan,
    studioImageState: StudioImageGenState,
    generatedImages: List<GeneratedImageEntity>,
    onGenerateStudioImage: (String, CloudyImageModelOption, ImageAspectOption, Bitmap?) -> Unit,
    onExportImageToGallery: (GeneratedImageEntity) -> Unit,
    onDeleteGeneratedImage: (Long) -> Unit,
    onOpenPlanSettings: () -> Unit
) {
    val context = LocalContext.current
    val cloudyStyle = LocalCloudyStyle.current
    var prompt by rememberSaveable { mutableStateOf("") }
    var selectedModelOption by remember { mutableStateOf(CloudyImageModelOption.NANO_BANANA_2_1) }
    var selectedAspectOption by remember { mutableStateOf(ImageAspectOption.SQUARE) }
    var referenceBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val refPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()?.let { referenceBitmap = it }
        }
    }

    val isGenerating = studioImageState is StudioImageGenState.Generating

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cloudy Image Studio", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        TelemetryChip(label = "Firebase AI Logic", accent = EmeraldVerified)
                    }

                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("Describe the image you want to create or edit...") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth().testTag("image_studio_prompt_input")
                    )

                    Text("Model", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        CloudyImageModelOption.entries.forEach { option ->
                            val locked = option == CloudyImageModelOption.GEMINI_3_PRO_IMAGE && currentPlan == SubscriptionPlan.FREE
                            FilterChip(
                                selected = selectedModelOption == option,
                                onClick = { selectedModelOption = option },
                                leadingIcon = if (locked) {
                                    { Icon(Icons.Filled.Lock, contentDescription = "Pro required", modifier = Modifier.size(14.dp)) }
                                } else null,
                                label = { Text(option.displayName) },
                                modifier = Modifier.testTag("img_model_${option.name}")
                            )
                        }
                    }

                    Text("Aspect Ratio", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ImageAspectOption.entries) { aspect ->
                            FilterChip(
                                selected = selectedAspectOption == aspect,
                                onClick = { selectedAspectOption = aspect },
                                label = { Text(aspect.label) }
                            )
                        }
                    }

                    // Reference Image (optional for editing/remixing)
                    if (referenceBitmap != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Image(
                                bitmap = referenceBitmap!!.asImageBitmap(),
                                contentDescription = "Reference image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp))
                            )
                            Text("Reference photo attached for editing", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                            IconButton(onClick = { referenceBitmap = null }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove reference")
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                refPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            enabled = !isGenerating,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reference Photo")
                        }

                        Button(
                            onClick = {
                                onGenerateStudioImage(prompt, selectedModelOption, selectedAspectOption, referenceBitmap)
                            },
                            enabled = prompt.isNotBlank() && !isGenerating,
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("generate_image_button")
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Generating...")
                            } else {
                                Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generate")
                            }
                        }
                    }

                    if (selectedModelOption == CloudyImageModelOption.GEMINI_3_PRO_IMAGE && currentPlan == SubscriptionPlan.FREE) {
                        OutlinedButton(onClick = onOpenPlanSettings, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.WorkspacePremium, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gemini 3 Pro Image requires Pro or Ultra Plan — View Plans")
                        }
                    }
                }
            }
        }

        // Real Result / Error Card
        when (studioImageState) {
            is StudioImageGenState.Generating -> {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(26.dp))
                            Column {
                                Text("Rendering image with ${selectedModelOption.displayName}...", style = MaterialTheme.typography.titleSmall)
                                Text("Output will appear here once Firebase AI Logic finishes.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            is StudioImageGenState.Success -> {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.2.dp, EmeraldVerified.copy(alpha = 0.6f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TelemetryChip(label = "${studioImageState.modelId} • ${studioImageState.latencyMs}ms", accent = EmeraldVerified)
                                Text("Saved locally", style = MaterialTheme.typography.labelSmall, color = EmeraldVerified)
                            }
                            Image(
                                bitmap = studioImageState.bitmap.asImageBitmap(),
                                contentDescription = "Generated Studio Image",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                            )
                        }
                    }
                }
            }
            is StudioImageGenState.Error -> {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = RoseError.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, RoseError)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = RoseError)
                            Text(studioImageState.message, style = MaterialTheme.typography.bodySmall, color = RoseError)
                        }
                    }
                }
            }
            StudioImageGenState.Idle -> Unit
        }

        // Saved Generated Images History
        item {
            Text(
                text = "Generated Gallery (${generatedImages.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        if (generatedImages.isEmpty()) {
            item {
                EmptyPlaceholderCard(
                    title = "No Generated Images Yet",
                    body = "Enter a prompt above to create artwork, UI concepts, or edit a reference photo.",
                    icon = Icons.Filled.Image
                )
            }
        } else {
            items(generatedImages, key = { "gen_img_${it.id}" }) { item ->
                val bmp = remember(item.filePath) { BitmapFactory.decodeFile(item.filePath) }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = item.prompt,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(68.dp).clip(RoundedCornerShape(12.dp))
                            )
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(item.prompt, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            TelemetryChip(label = "${item.modelId} • ${item.aspectRatio}")
                        }
                        IconButton(onClick = { onExportImageToGallery(item) }) {
                            Icon(Icons.Filled.Download, contentDescription = "Save to device Gallery", tint = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { onDeleteGeneratedImage(item.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete image", tint = RoseError)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DocumentLabTab(
    attachedDocument: ExtractedDocumentPayload?,
    documentArtifacts: List<DocumentArtifactEntity>,
    onAttachDocumentUri: (Uri) -> Unit,
    onDeleteDocumentArtifact: (Long) -> Unit,
    onAskAboutDocument: (String) -> Unit
) {
    val cloudyStyle = LocalCloudyStyle.current
    val docPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onAttachDocumentUri(uri)
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Document & File Intelligence", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "Upload PDF (with visual page rendering), DOCX, TXT, Markdown, JSON, CSV, Kotlin, Python, or JS files for inspection and Q&A.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = {
                            docPicker.launch(
                                arrayOf(
                                    "application/pdf",
                                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    "text/*",
                                    "application/json"
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("upload_document_button")
                    ) {
                        Icon(Icons.Filled.UploadFile, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Select Document from Device")
                    }
                }
            }
        }

        if (attachedDocument != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.2.dp, EmeraldVerified.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(attachedDocument.fileName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        TelemetryChip(label = attachedDocument.summaryNote, accent = EmeraldVerified)

                        if (attachedDocument.pagePreviewBitmaps.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(attachedDocument.pagePreviewBitmaps.size) { idx ->
                                    Image(
                                        bitmap = attachedDocument.pagePreviewBitmaps[idx].asImageBitmap(),
                                        contentDescription = "PDF Page ${idx + 1}",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .height(120.dp)
                                            .aspectRatio(0.75f)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                }
                            }
                        }

                        Text(
                            text = attachedDocument.extractedText.take(650) + if (attachedDocument.extractedText.length > 650) "..." else "",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Button(
                            onClick = {
                                onAskAboutDocument("Analyze ${attachedDocument.fileName}: summarize the key points, structure, and critical details.")
                            },
                            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("ask_about_doc_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ask Cloudy about this Document")
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Recent Indexed Files (${documentArtifacts.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        if (documentArtifacts.isEmpty()) {
            item {
                EmptyPlaceholderCard(
                    title = "No Documents Uploaded Yet",
                    body = "Tap above to inspect PDFs, Word DOCX files, logs, or source code.",
                    icon = Icons.Filled.Description
                )
            }
        } else {
            items(documentArtifacts, key = { "doc_art_${it.id}" }) { doc ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(doc.fileName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${doc.mimeType} • ${doc.sizeBytes} chars • ${doc.pageCount} page(s)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onDeleteDocumentArtifact(doc.id) }) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete document artifact", tint = RoseError)
                            }
                        }
                        Text(
                            text = doc.extractedText.take(220),
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ModelsCatalogList(
    models: List<RegisteredModel>,
    loadedMemoryMb: Int,
    activePlatformModel: CloudyAiModel,
    platformModels: List<CloudyAiModel>,
    availabilityProvider: (CloudyAiModel) -> ModelAvailabilityStatus,
    currentPlan: SubscriptionPlan,
    routerPreview: RoutingDecision?,
    onActivatePlatformModel: (CloudyAiModel) -> Unit,
    onOpenPlanSettings: () -> Unit,
    onToggleLoad: (String) -> Unit,
    onHealthCheck: (String) -> Unit,
    onSimulateRoute: (String) -> Unit
) {
    val cloudyStyle = LocalCloudyStyle.current
    var probePrompt by rememberSaveable { mutableStateOf("24 * 12 + 8") }
    var selectedCategory by remember { mutableStateOf<AiModelCategory?>(null) }

    val filteredModels = remember(platformModels, selectedCategory) {
        if (selectedCategory == null) platformModels
        else platformModels.filter { it.category == selectedCategory || selectedCategory in it.secondaryCategories }
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Active Model • Plan: ${currentPlan.displayName}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${activePlatformModel.displayName} • Local RAM: $loadedMemoryMb MB",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenPlanSettings,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.WorkspacePremium, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(currentPlan.badge)
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = selectedCategory == null,
                                onClick = { selectedCategory = null },
                                label = { Text("All (${platformModels.size})") },
                                modifier = Modifier.testTag("scope_filter_ALL")
                            )
                        }
                        items(AiModelCategory.entries) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                                label = { Text(cat.displayName) },
                                modifier = Modifier.testTag("cat_filter_${cat.name}")
                            )
                        }
                    }
                }
            }
        }

        items(filteredModels, key = { "platform_${it.id}" }) { model ->
            val isActive = model.id == activePlatformModel.id
            val availability = availabilityProvider(model)

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(
                    width = if (isActive) 1.5.dp else 1.dp,
                    brush = if (isActive) cloudyStyle.crystalAccentBrush else cloudyStyle.borderBrush
                )
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = when (availability) {
                                        ModelAvailabilityStatus.PLAN_LOCKED -> Icons.Filled.Lock
                                        ModelAvailabilityStatus.KEY_REQUIRED -> Icons.Filled.Key
                                        else -> Icons.Filled.AutoAwesome
                                    },
                                    contentDescription = null,
                                    tint = if (availability == ModelAvailabilityStatus.READY) MaterialTheme.colorScheme.primary else AmberWarning,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = model.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                TelemetryChip(label = model.provider.displayName, accent = MaterialTheme.colorScheme.primary)
                                TelemetryChip(label = model.category.badge, accent = MaterialTheme.colorScheme.secondary)
                                TelemetryChip(label = model.accessScope.shortBadge)
                                model.contextWindowTokens?.let { ctx ->
                                    TelemetryChip(label = if (ctx >= 1_000_000) "1M ctx" else "${ctx / 1000}K ctx")
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = { onActivatePlatformModel(model) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when {
                                    availability != ModelAvailabilityStatus.READY -> AmberWarning
                                    isActive -> EmeraldVerified
                                    else -> MaterialTheme.colorScheme.primary
                                }
                            ),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("activate_${model.id}")
                        ) {
                            Text(
                                when {
                                    isActive -> "Active"
                                    availability == ModelAvailabilityStatus.PLAN_LOCKED -> "Unlock"
                                    availability == ModelAvailabilityStatus.KEY_REQUIRED -> "Add Key"
                                    else -> "Use"
                                }
                            )
                        }
                    }

                    Text(
                        text = model.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    MetricProgressRow(
                        label = "Speed Classification",
                        fraction = model.speedTier.score,
                        valueLabel = model.speedTier.label,
                        accent = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.AltRoute, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Model Router Policy Simulator", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = probePrompt,
                            onValueChange = { probePrompt = it },
                            label = { Text("Test routing prompt") },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("router_probe_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onSimulateRoute(probePrompt) },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("router_simulate_button")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Route")
                        }
                    }
                    if (routerPreview != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "${routerPreview.requestCategory} → ${routerPreview.selectedEngine} (${routerPreview.estimatedContextTokens} tok)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = routerPreview.policySummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        items(models, key = { it.metadata.id }) { item ->
            ModelRegistryCard(
                item = item,
                onToggleLoad = { onToggleLoad(item.metadata.id) },
                onHealthCheck = { onHealthCheck(item.metadata.id) }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TokenizerAndCodeLabList(
    labState: LabState,
    onTokenizerInputChange: (String) -> Unit,
    onSelectTransformerPreset: (TransformerArchitectureConfig) -> Unit,
    onAnalyzeCode: (String) -> Unit
) {
    val cloudyStyle = LocalCloudyStyle.current
    val tok = labState.tokenizationReport
    val est = labState.transformerEstimate
    var codeText by rememberSaveable { mutableStateOf(labState.codeInput) }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Token, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Phase A — Cloudy Unicode Tokenizer", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = labState.tokenizerInput,
                        onValueChange = onTokenizerInputChange,
                        label = { Text("Multilingual input") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("tokenizer_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        TelemetryChip(label = "${tok.tokenIds.size} tokens")
                        TelemetryChip(label = "${tok.utf8ByteCount} UTF-8 bytes")
                        TelemetryChip(
                            label = if (tok.roundTripExactMatch) "REVERSIBLE: PASS" else "MISMATCH",
                            accent = if (tok.roundTripExactMatch) EmeraldVerified else RoseError
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        tok.tokens.take(36).forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                            ) {
                                Text(
                                    text = "${item.tokenText} [${item.tokenId}]",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Phase B — Transformer Memory Estimator", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExperimentalTransformerSpec.presets.forEach { preset ->
                            FilterChip(
                                selected = labState.transformerConfig.name == preset.name,
                                onClick = { onSelectTransformerPreset(preset) },
                                label = { Text(preset.name) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Params: ${String.format(Locale.US, "%,d", est.totalParameters)} • FP16: ${String.format(Locale.US, "%.1f", est.fp16WeightsMb)} MB • INT8: ${String.format(Locale.US, "%.1f", est.int8WeightsMb)} MB",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = JetBrainsMonoFontFamily
                    )
                }
            }
        }

        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                border = BorderStroke(1.dp, cloudyStyle.borderBrush)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Static Code Sandbox Auditor", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = codeText,
                        onValueChange = { codeText = it },
                        label = { Text("Python / Kotlin / SQL / JS / C++") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("lab_code_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onAnalyzeCode(codeText) },
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("lab_analyze_code_button")
                    ) {
                        Text("Run Static Audit")
                    }
                    val rep = labState.codeReport
                    if (rep != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${rep.detectedLanguage} • Lines=${rep.lineCount} • Delimiters=${if (rep.delimitersBalanced) "OK" else "ERR"}",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = if (rep.delimitersBalanced) EmeraldVerified else RoseError
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelRegistryCard(
    item: RegisteredModel,
    onToggleLoad: () -> Unit,
    onHealthCheck: () -> Unit
) {
    val meta = item.metadata
    val isReady = item.loadState == ModelLoadState.READY
    val cloudyStyle = LocalCloudyStyle.current

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
        border = BorderStroke(1.dp, if (isReady) EmeraldVerified.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(meta.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("${meta.id} • v${meta.version}", style = MaterialTheme.typography.labelSmall, fontFamily = JetBrainsMonoFontFamily)
                }
                TelemetryChip(label = meta.category.name, accent = MaterialTheme.colorScheme.secondary)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(meta.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onToggleLoad,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            !meta.artifactVerified -> RoseError
                            meta.requiresRemoteCompute -> AmberWarning
                            isReady -> MaterialTheme.colorScheme.surfaceVariant
                            else -> MaterialTheme.colorScheme.primary
                        }
                    ),
                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("model_toggle_${meta.id}")
                ) {
                    Icon(if (!meta.artifactVerified) Icons.Filled.Lock else Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        when {
                            !meta.artifactVerified -> "Blocked"
                            meta.requiresRemoteCompute -> "Remote"
                            isReady -> "Unload"
                            else -> "Load"
                        }
                    )
                }
                OutlinedButton(
                    onClick = onHealthCheck,
                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("model_health_${meta.id}")
                ) {
                    Icon(Icons.Filled.HealthAndSafety, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Health")
                }
            }
        }
    }
}
