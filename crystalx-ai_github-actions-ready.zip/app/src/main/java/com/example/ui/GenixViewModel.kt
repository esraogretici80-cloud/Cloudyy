package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.genix.ai.core.AiModelCategory
import com.example.genix.ai.core.AiProviderKind
import com.example.genix.ai.core.CloudyAiModel
import com.example.genix.ai.core.ModelAvailabilityStatus
import com.example.genix.ai.core.NormalizedAiChunk
import com.example.genix.ai.core.NormalizedAiRequest
import com.example.genix.ai.core.WebCitationSource
import com.example.genix.ai.live.CloudyLiveEngine
import com.example.genix.ai.live.LiveSessionTelemetry
import com.example.genix.ai.multimodal.CloudyImageModelOption
import com.example.genix.ai.multimodal.DocumentIntelligenceEngine
import com.example.genix.ai.multimodal.ExtractedDocumentPayload
import com.example.genix.ai.multimodal.ImageAspectOption
import com.example.genix.ai.multimodal.ImageGenerationService
import com.example.genix.ai.multimodal.WebSearchService
import com.example.genix.ai.providers.ExternalHttpAiProvider
import com.example.genix.ai.registry.CloudyModelCatalog
import com.example.genix.ai.routing.IntelligentModelRouter
import com.example.genix.ai.security.ProviderAuthManager
import com.example.genix.ai.security.ProviderCredentialRecord
import com.example.genix.core.CoreEngine
import com.example.genix.core.EventSystem
import com.example.genix.core.ExecutionMode
import com.example.genix.core.GenixConfig
import com.example.genix.core.GenixConfigRepository
import com.example.genix.core.GenixEventLog
import com.example.genix.core.GenixRequest
import com.example.genix.core.HealthStatus
import com.example.genix.core.LogSeverity
import com.example.genix.core.PhaseRoadmapItem
import com.example.genix.core.ResponseStyle
import com.example.genix.core.RoutingDecision
import com.example.genix.core.SubscriptionPlan
import com.example.genix.core.VerificationStatus
import com.example.genix.firebase.AiStreamEvent
import com.example.genix.firebase.AppCheckCoordinator
import com.example.genix.firebase.AppCheckDiagnostics
import com.example.genix.firebase.CloudMemoryItem
import com.example.genix.firebase.CloudMessage
import com.example.genix.firebase.CloudyIntegrationsEngine
import com.example.genix.firebase.ConversationThread
import com.example.genix.firebase.CrystalXAiService
import com.example.genix.firebase.CrystalXCloudRepository
import com.example.genix.firebase.CrystalXModelId
import com.example.genix.firebase.UserIntegration
import com.example.genix.firebase.UserProfileSettings
import com.example.genix.intelligence.coding.CodeAnalysisReport
import com.example.genix.intelligence.coding.CodingEngine
import com.example.genix.intelligence.language.HomeUiStrings
import com.example.genix.intelligence.language.LiveUiStrings
import com.example.genix.intelligence.language.LocalizedUiStrings
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.genix.intelligence.planning.ExecutionPlan
import com.example.genix.intelligence.planning.PlanningEngine
import com.example.genix.intelligence.reasoning.ReasoningEngine
import com.example.genix.memory.DocumentArtifactEntity
import com.example.genix.memory.GenixDatabase
import com.example.genix.memory.GeneratedImageEntity
import com.example.genix.memory.KnowledgeDocumentEntity
import com.example.genix.memory.KnowledgeSearchHit
import com.example.genix.memory.LongTermMemoryEntity
import com.example.genix.memory.MemoryRepository
import com.example.genix.models.ModelRegistry
import com.example.genix.models.RegisteredModel
import com.example.genix.models.RemoteFastApiAdapter
import com.example.genix.models.RemoteProbeResult
import com.example.genix.router.ModelRouter
import com.example.genix.training.ExperimentalTransformerSpec
import com.example.genix.training.GenixTokenizer
import com.example.genix.training.TokenizationReport
import com.example.genix.training.TransformerArchitectureConfig
import com.example.genix.training.TransformerEstimate
import com.example.genix.voice.CloudyVoiceEngine
import com.example.genix.voice.CloudyVoicePersona
import com.example.genix.voice.VoiceApiProvider
import com.example.genix.voice.VoicePlaybackState
import com.example.ui.theme.AppThemeMode
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface StudioImageGenState {
    data object Idle : StudioImageGenState
    data object Generating : StudioImageGenState
    data class Success(val path: String, val bitmap: Bitmap, val modelId: String, val latencyMs: Long) : StudioImageGenState
    data class Error(val message: String) : StudioImageGenState
}

data class LabState(
    val tokenizerInput: String = "Merhaba Cloudy AI! FastAPI + PyTorch ile Türkçe & English tokenization testi.",
    val tokenizationReport: TokenizationReport,
    val transformerConfig: TransformerArchitectureConfig = ExperimentalTransformerSpec.presets[1],
    val transformerEstimate: TransformerEstimate = ExperimentalTransformerSpec.estimate(ExperimentalTransformerSpec.presets[1]),
    val codeInput: String = "def calculate_loss(logits, targets):\n    return sum(logits) / len(targets)\n",
    val codeReport: CodeAnalysisReport? = null,
    val knowledgeQuery: String = "",
    val knowledgeSearchResults: List<KnowledgeSearchHit> = emptyList()
)

class GenixViewModelFactory(
    private val application: Application,
    private val userId: String
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GenixViewModel::class.java)) {
            return GenixViewModel(application, userId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class GenixViewModel(
    application: Application,
    val userId: String = ""
) : AndroidViewModel(application) {

    private val database = GenixDatabase.getInstance(application)
    private val memoryRepository = MemoryRepository(database)
    private val configRepository = GenixConfigRepository(application)
    private val cloudRepository = CrystalXCloudRepository(application)
    private val aiService = CrystalXAiService()
    private val voiceEngine = CloudyVoiceEngine(application)
    private val liveEngine = CloudyLiveEngine(application)

    private val providerAuthManager = ProviderAuthManager(application)
    val modelCatalog = CloudyModelCatalog()
    private val intelligentRouter = IntelligentModelRouter(modelCatalog)
    private val imageGenerationService = ImageGenerationService(application)
    private val documentEngine = DocumentIntelligenceEngine(application)
    private val webSearchService = WebSearchService()

    private val externalProviders: Map<AiProviderKind, ExternalHttpAiProvider> = mapOf(
        AiProviderKind.OPENAI to ExternalHttpAiProvider(AiProviderKind.OPENAI, providerAuthManager),
        AiProviderKind.ANTHROPIC to ExternalHttpAiProvider(AiProviderKind.ANTHROPIC, providerAuthManager),
        AiProviderKind.DEEPSEEK to ExternalHttpAiProvider(AiProviderKind.DEEPSEEK, providerAuthManager),
        AiProviderKind.META_LLAMA to ExternalHttpAiProvider(AiProviderKind.META_LLAMA, providerAuthManager),
        AiProviderKind.QWEN to ExternalHttpAiProvider(AiProviderKind.QWEN, providerAuthManager),
        AiProviderKind.MISTRAL to ExternalHttpAiProvider(AiProviderKind.MISTRAL, providerAuthManager)
    )

    private val eventSystem: EventSystem
    private val reasoningEngine = ReasoningEngine()
    private val codingEngine = CodingEngine()
    private val planningEngine = PlanningEngine()
    private val tokenizer = GenixTokenizer()
    private val remoteFastApiAdapter = RemoteFastApiAdapter()

    private val modelRegistry: ModelRegistry
    private val modelRouter: ModelRouter
    private val coreEngine: CoreEngine

    private var hasBootstrappedDefaultThread = false
    private var hasBootstrappedDefaultMemory = false
    private var hasBootstrappedProfile = false
    private var hasBootstrappedIntegrations = false
    private var generationJob: Job? = null

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    private val _selectedModel = MutableStateFlow(CrystalXModelId.NEO_1_1)
    val selectedModel: StateFlow<CrystalXModelId> = _selectedModel.asStateFlow()

    private val _activePlatformModel = MutableStateFlow(modelCatalog.findById(CrystalXModelId.NEO_1_1.id))
    val activePlatformModel: StateFlow<CloudyAiModel> = _activePlatformModel.asStateFlow()

    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText.asStateFlow()

    private val _streamingModelLabel = MutableStateFlow<String?>(null)
    val streamingModelLabel: StateFlow<String?> = _streamingModelLabel.asStateFlow()

    private val _attachedIntegrationNotes = MutableStateFlow<List<String>>(emptyList())
    val attachedIntegrationNotes: StateFlow<List<String>> = _attachedIntegrationNotes.asStateFlow()

    private val _runningIntegrationId = MutableStateFlow<String?>(null)
    val runningIntegrationId: StateFlow<String?> = _runningIntegrationId.asStateFlow()

    private val _hasAppCheckIssue = MutableStateFlow(false)
    val hasAppCheckIssue: StateFlow<Boolean> = _hasAppCheckIssue.asStateFlow()

    private val _upgradePromptModel = MutableStateFlow<CrystalXModelId?>(null)
    val upgradePromptModel: StateFlow<CrystalXModelId?> = _upgradePromptModel.asStateFlow()

    private val _attachedImages = MutableStateFlow<List<Bitmap>>(emptyList())
    val attachedImages: StateFlow<List<Bitmap>> = _attachedImages.asStateFlow()

    val attachedImageBitmap: StateFlow<Bitmap?> = _attachedImages
        .map { it.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _attachedImageLabel = MutableStateFlow<String?>(null)
    val attachedImageLabel: StateFlow<String?> = _attachedImageLabel.asStateFlow()

    private val _attachedDocument = MutableStateFlow<ExtractedDocumentPayload?>(null)
    val attachedDocument: StateFlow<ExtractedDocumentPayload?> = _attachedDocument.asStateFlow()

    private val _webSearchEnabled = MutableStateFlow(false)
    val webSearchEnabled: StateFlow<Boolean> = _webSearchEnabled.asStateFlow()

    private val _codingModeEnabled = MutableStateFlow(false)
    val codingModeEnabled: StateFlow<Boolean> = _codingModeEnabled.asStateFlow()

    private val _latestWebCitations = MutableStateFlow<List<WebCitationSource>>(emptyList())
    val latestWebCitations: StateFlow<List<WebCitationSource>> = _latestWebCitations.asStateFlow()

    private val _studioImageState = MutableStateFlow<StudioImageGenState>(StudioImageGenState.Idle)
    val studioImageState: StateFlow<StudioImageGenState> = _studioImageState.asStateFlow()

    private val _preferOpenAiRealtime = MutableStateFlow(false)
    val preferOpenAiRealtime: StateFlow<Boolean> = _preferOpenAiRealtime.asStateFlow()

    val appCheckDiagnostics: StateFlow<AppCheckDiagnostics> = AppCheckCoordinator.diagnostics
    val voicePlaybackState: StateFlow<VoicePlaybackState> = voiceEngine.state
    val liveTelemetry: StateFlow<LiveSessionTelemetry> = liveEngine.telemetry
    val platformModels: StateFlow<List<CloudyAiModel>> = modelCatalog.models

    val providerCredentials: StateFlow<Map<AiProviderKind, ProviderCredentialRecord>> =
        providerAuthManager.credentialsFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val generatedImages: StateFlow<List<GeneratedImageEntity>> = memoryRepository
        .observeGeneratedImages(userId.ifBlank { "local" })
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val documentArtifacts: StateFlow<List<DocumentArtifactEntity>> = memoryRepository
        .observeDocumentArtifacts(userId.ifBlank { "local" })
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        eventSystem = EventSystem(
            onPersistEvent = { log -> memoryRepository.persistAuditLog(log) }
        )
        modelRegistry = ModelRegistry(eventSystem)
        modelRouter = ModelRouter(reasoningEngine, codingEngine, planningEngine, tokenizer)
        coreEngine = CoreEngine(
            eventSystem = eventSystem,
            modelRegistry = modelRegistry,
            modelRouter = modelRouter,
            reasoningEngine = reasoningEngine,
            codingEngine = codingEngine,
            planningEngine = planningEngine,
            tokenizer = tokenizer,
            memoryRepository = memoryRepository,
            remoteFastApiAdapter = remoteFastApiAdapter
        )

        viewModelScope.launch {
            memoryRepository.seedInitialFoundationDataIfEmpty()
            memoryRepository.purgeExpiredLongTerm()
            eventSystem.log(
                component = "CloudyCore",
                severity = LogSeverity.INFO,
                message = "Cloudy v2.0 platform initialized for user $userId."
            )
        }
    }

    val localConfig: StateFlow<GenixConfig> = configRepository.configFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GenixConfig())

    val userProfile: StateFlow<UserProfileSettings?> = cloudRepository
        .observeUserProfile()
        .onEach { profile ->
            if (profile == null && !hasBootstrappedProfile) {
                hasBootstrappedProfile = true
                viewModelScope.launch {
                    val validCountry = MultilingualLanguageSystem.resolveDefaultCountryCode()
                    cloudRepository.saveUserProfile(
                        themeMode = AppThemeMode.SYSTEM,
                        proUnlocked = false,
                        preferredLanguageCode = "system",
                        countryCode = validCountry,
                        defaultModelId = CrystalXModelId.NEO_1_1.id,
                        voiceProfileId = CloudyVoicePersona.AOEDE.id,
                        subscriptionTier = SubscriptionPlan.FREE.id,
                        autoRouteEnabled = localConfig.value.autoRouteEnabled,
                        responseStyle = localConfig.value.responseStyle.id,
                        customInstructions = localConfig.value.customInstructions
                    )
                }
            }
        }
        .catch { e ->
            val fsErr = generateSequence(e) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsErr == null && e is CancellationException) throw e
            emit(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val config: StateFlow<GenixConfig> = combine(localConfig, userProfile) { local, cloud ->
        if (cloud == null) {
            local
        } else {
            val cloudPlan = SubscriptionPlan.fromId(cloud.subscriptionTier).let { parsed ->
                if (parsed == SubscriptionPlan.FREE && cloud.proUnlocked) SubscriptionPlan.PRO else parsed
            }
            local.copy(
                themeMode = AppThemeMode.fromId(cloud.themeMode),
                proCrystalUnlocked = cloud.proUnlocked || cloudPlan.rank >= SubscriptionPlan.PRO.rank,
                subscriptionPlan = cloudPlan,
                preferredLanguageCode = cloud.preferredLanguageCode,
                countryCode = cloud.countryCode,
                voiceProfileId = cloud.voiceProfileId.ifBlank { local.voiceProfileId },
                autoRouteEnabled = cloud.autoRouteEnabled,
                responseStyle = ResponseStyle.fromId(cloud.responseStyle),
                customInstructions = cloud.customInstructions.ifBlank { local.customInstructions }
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GenixConfig())

    val integrationsState: StateFlow<UiState<List<UserIntegration>>> = cloudRepository
        .observeIntegrations()
        .onEach { list ->
            if (list.isEmpty() && !hasBootstrappedIntegrations) {
                hasBootstrappedIntegrations = true
                viewModelScope.launch {
                    cloudRepository.addIntegration(
                        type = "cloud_vault",
                        name = "Cloud Vault Auto-Context",
                        targetUrl = "users/$userId/memories",
                        notes = "Automatically injects pinned vault notes into Cloudy AI prompts.",
                        enabled = true,
                        lastStatus = "Synced & Ready"
                    )
                    cloudRepository.addIntegration(
                        type = "github_repo",
                        name = "GitHub Repo Inspector",
                        targetUrl = "google/generative-ai-android",
                        notes = "Fetches live repository metadata & open issue telemetry.",
                        enabled = true,
                        lastStatus = "Ready to fetch"
                    )
                }
            }
        }
        .map<List<UserIntegration>, UiState<List<UserIntegration>>> { UiState.Success(it) }
        .catch { e ->
            val fsErr = generateSequence(e) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            if (fsErr == null && e is CancellationException) throw e
            emit(UiState.Error((fsErr ?: e).localizedMessage ?: "Failed to load integrations"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val conversations: StateFlow<UiState<List<ConversationThread>>> = cloudRepository
        .observeConversations()
        .onEach { threads ->
            if (threads.isEmpty() && !hasBootstrappedDefaultThread) {
                hasBootstrappedDefaultThread = true
                viewModelScope.launch {
                    val created = cloudRepository.createConversation(
                        title = "Cloudy Studio",
                        activeModelId = _activePlatformModel.value.id,
                        pinned = true
                    )
                    created.onSuccess { newId -> _activeConversationId.value = newId }
                }
            } else if (threads.isNotEmpty()) {
                val currentId = _activeConversationId.value
                val active = threads.firstOrNull { it.id == currentId }
                if (active == null) {
                    val preferred = threads.firstOrNull { it.pinned } ?: threads.first()
                    _activeConversationId.value = preferred.id
                    syncSelectedModelIds(preferred.activeModelId)
                }
            }
        }
        .map<List<ConversationThread>, UiState<List<ConversationThread>>> { threads ->
            val sorted = threads.sortedWith(
                compareByDescending<ConversationThread> { it.pinned }
                    .thenByDescending { it.updatedAt?.seconds ?: 0L }
            )
            UiState.Success(sorted)
        }
        .catch { e ->
            val fsErr = generateSequence(e) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            if (fsErr == null && e is CancellationException) throw e
            emit(UiState.Error((fsErr ?: e).localizedMessage ?: "Failed to load Cloud conversations"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val cloudMessages: StateFlow<UiState<List<CloudMessage>>> = _activeConversationId
        .flatMapLatest { convId ->
            if (convId.isNullOrBlank()) flowOf(UiState.Success(emptyList()))
            else cloudRepository.observeMessages(convId)
                .map<List<CloudMessage>, UiState<List<CloudMessage>>> { UiState.Success(it) }
                .catch { e ->
                    val fsErr = generateSequence(e) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsErr == null && e is CancellationException) throw e
                    emit(UiState.Error((fsErr ?: e).localizedMessage ?: "Failed to load messages"))
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val cloudMemories: StateFlow<UiState<List<CloudMemoryItem>>> = cloudRepository
        .observeMemories()
        .onEach { items ->
            if (items.isEmpty() && !hasBootstrappedDefaultMemory) {
                hasBootstrappedDefaultMemory = true
                viewModelScope.launch {
                    cloudRepository.addMemoryItem(
                        title = "Cloudy Architecture Prompt",
                        category = "prompt_template",
                        content = "Provide clean Kotlin/Python architecture with edge-case safeguards and concise explanations.",
                        languageCode = "en",
                        tags = listOf("architecture", "cloudy"),
                        pinned = false
                    )
                }
            }
        }
        .map<List<CloudMemoryItem>, UiState<List<CloudMemoryItem>>> { list ->
            val sorted = list.sortedWith(
                compareByDescending<CloudMemoryItem> { it.pinned }
                    .thenByDescending { it.updatedAt?.seconds ?: 0L }
            )
            UiState.Success(sorted)
        }
        .catch { e ->
            val fsErr = generateSequence(e) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            if (fsErr == null && e is CancellationException) throw e
            emit(UiState.Error((fsErr ?: e).localizedMessage ?: "Failed to load Cloud Memory Vault"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val longTermMemories: StateFlow<List<LongTermMemoryEntity>> = memoryRepository
        .observeLongTermMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val knowledgeDocuments: StateFlow<List<KnowledgeDocumentEntity>> = memoryRepository
        .observeKnowledgeDocuments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<GenixEventLog>> = memoryRepository
        .observeAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val registeredModels: StateFlow<List<RegisteredModel>> = modelRegistry.models
    val latestPlan: StateFlow<ExecutionPlan?> = coreEngine.latestPlan

    private val _activeConversationLang = MutableStateFlow(MultilingualLanguageSystem.resolveSystemLanguageCode())
    val activeConversationLang: StateFlow<String> = _activeConversationLang.asStateFlow()

    val effectiveLanguageCode: StateFlow<String> = combine(config, _activeConversationLang) { cfg, conv ->
        MultilingualLanguageSystem.resolveEffectiveLanguage(cfg.preferredLanguageCode, conv)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MultilingualLanguageSystem.resolveSystemLanguageCode())

    val uiStrings: StateFlow<LocalizedUiStrings> = effectiveLanguageCode.map {
        MultilingualLanguageSystem.uiStrings(it)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MultilingualLanguageSystem.uiStrings(MultilingualLanguageSystem.resolveSystemLanguageCode())
    )

    val homeStrings: StateFlow<HomeUiStrings> = effectiveLanguageCode.map {
        MultilingualLanguageSystem.homeStrings(it)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MultilingualLanguageSystem.homeStrings(MultilingualLanguageSystem.resolveSystemLanguageCode())
    )

    val liveStrings: StateFlow<LiveUiStrings> = effectiveLanguageCode.map {
        MultilingualLanguageSystem.liveStrings(it)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MultilingualLanguageSystem.liveStrings(MultilingualLanguageSystem.resolveSystemLanguageCode())
    )

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _routerPreview = MutableStateFlow<RoutingDecision?>(null)
    val routerPreview: StateFlow<RoutingDecision?> = _routerPreview.asStateFlow()

    private val _remoteProbe = MutableStateFlow<RemoteProbeResult?>(null)
    val remoteProbe: StateFlow<RemoteProbeResult?> = _remoteProbe.asStateFlow()

    private val _isProbingRemote = MutableStateFlow(false)
    val isProbingRemote: StateFlow<Boolean> = _isProbingRemote.asStateFlow()

    private val initialTokInput = "Merhaba Cloudy AI! FastAPI + PyTorch ile Türkçe & English tokenization testi."
    private val _labState = MutableStateFlow(
        LabState(
            tokenizerInput = initialTokInput,
            tokenizationReport = tokenizer.analyze(initialTokInput),
            codeReport = codingEngine.analyzeCode("def calculate_loss(logits, targets):\n    return sum(logits) / len(targets)\n", "en")
        )
    )
    val labState: StateFlow<LabState> = _labState.asStateFlow()

    fun getHealthSnapshot(): HealthStatus = coreEngine.getHealthStatus(config.value, effectiveLanguageCode.value)
    fun loadedMemoryMb(): Int = modelRegistry.loadedMemoryMb()

    private fun syncSelectedModelIds(modelId: String) {
        val found = modelCatalog.findById(modelId)
        _activePlatformModel.value = found
        _selectedModel.value = found.legacyCrystalId ?: CrystalXModelId.fromId(modelId)
    }

    fun availabilityFor(model: CloudyAiModel): ModelAvailabilityStatus = modelCatalog.availabilityFor(
        model = model,
        plan = config.value.subscriptionPlan,
        credentials = providerCredentials.value,
        fastApiUrl = config.value.controlPlaneUrl
    )

    fun selectModel(modelId: CrystalXModelId): Boolean {
        val platformModel = modelCatalog.findById(modelId.id)
        return selectPlatformModel(platformModel)
    }

    fun selectPlatformModel(model: CloudyAiModel): Boolean {
        val currentPlan = config.value.subscriptionPlan
        val legacy = model.legacyCrystalId
        if (model.provider == AiProviderKind.CLOUDY_FIREBASE && legacy != null && !currentPlan.canAccess(legacy)) {
            _upgradePromptModel.value = legacy
            return false
        }
        val status = availabilityFor(model)
        if (status == ModelAvailabilityStatus.KEY_REQUIRED) {
            _statusMessage.value = "${model.provider.displayName} API key required — add in Settings → AI Providers."
            return false
        }

        _activePlatformModel.value = model
        if (legacy != null) _selectedModel.value = legacy
        _hasAppCheckIssue.value = false

        val convId = _activeConversationId.value
        if (!convId.isNullOrBlank()) {
            viewModelScope.launch {
                cloudRepository.updateConversationModel(convId, model.id)
            }
        }
        viewModelScope.launch {
            configRepository.updateActivePlatformModelId(model.id)
        }
        persistCurrentProfileToCloud(defaultModelId = model.id)
        return true
    }

    fun dismissUpgradePrompt() {
        _upgradePromptModel.value = null
    }

    fun activatePlanAndSelectModel(plan: SubscriptionPlan, targetModel: CrystalXModelId? = null) {
        _upgradePromptModel.value = null
        selectSubscriptionPlan(plan, autoSelectModel = targetModel)
    }

    fun selectSubscriptionPlan(plan: SubscriptionPlan, autoSelectModel: CrystalXModelId? = null) {
        viewModelScope.launch {
            configRepository.updateSubscriptionPlan(plan)
            var nextTheme = config.value.themeMode
            if (plan.rank >= SubscriptionPlan.PRO.rank && nextTheme == AppThemeMode.LIGHT_WHITE && autoSelectModel == null) {
                nextTheme = AppThemeMode.ICE_CRYSTAL_PRO
                configRepository.updateThemeMode(nextTheme)
            } else if (!plan.canAccessTheme(nextTheme)) {
                nextTheme = AppThemeMode.LIGHT_WHITE
                configRepository.updateThemeMode(nextTheme)
            }

            var nextModel = autoSelectModel ?: _selectedModel.value
            if (!plan.canAccess(nextModel)) nextModel = CrystalXModelId.NEO_1_1
            syncSelectedModelIds(nextModel.id)

            persistProfileValues(
                themeMode = nextTheme,
                proUnlocked = plan.rank >= SubscriptionPlan.PRO.rank,
                plan = plan,
                defaultModelId = nextModel.id
            )
            _statusMessage.value = "${plan.displayName} aktif! (${plan.priceLabel})"
        }
    }

    fun selectThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            configRepository.updateThemeMode(mode)
            val currentPlan = config.value.subscriptionPlan
            val effectivePlan = if (mode == AppThemeMode.ICE_CRYSTAL_PRO && currentPlan == SubscriptionPlan.FREE) {
                configRepository.updateSubscriptionPlan(SubscriptionPlan.PRO)
                SubscriptionPlan.PRO
            } else currentPlan
            val unlocked = config.value.proCrystalUnlocked || mode.isPro || effectivePlan.rank >= SubscriptionPlan.PRO.rank
            persistProfileValues(
                themeMode = mode,
                proUnlocked = unlocked,
                plan = effectivePlan,
                defaultModelId = _activePlatformModel.value.id
            )
            _statusMessage.value = when (mode) {
                AppThemeMode.SYSTEM -> "System Auto Theme active"
                AppThemeMode.LIGHT_WHITE -> "Minimalist Light Theme active"
                AppThemeMode.ICE_CRYSTAL_PRO -> "Ice Crystal Pro Theme active"
                AppThemeMode.DARK_OBSIDIAN -> "Minimalist Dark Theme active"
            }
        }
    }

    fun selectCountry(countryCode: String, alsoAlignLanguage: Boolean = true) {
        val country = MultilingualLanguageSystem.countryForCode(countryCode)
        viewModelScope.launch {
            configRepository.updateCountryCode(country.countryCode)
            val newLang = if (alsoAlignLanguage && config.value.preferredLanguageCode !in listOf("system", "auto")) {
                country.defaultLanguageCode
            } else config.value.preferredLanguageCode
            if (newLang != config.value.preferredLanguageCode) {
                configRepository.updatePreferredLanguage(newLang)
            }
            persistProfileValues(countryCode = country.countryCode, preferredLang = newLang)
            _statusMessage.value = "${country.flagEmoji} ${country.countryName} (${country.currencyCode})"
        }
    }

    fun selectVoicePersona(persona: CloudyVoicePersona) {
        viewModelScope.launch {
            configRepository.updateVoiceProfile(persona.id)
            persistProfileValues(voiceProfileId = persona.id)
            _statusMessage.value = "Voice Profile: ${persona.displayName}"
        }
    }

    fun updateVoiceTuning(speed: Float, pitch: Float, autoSpeak: Boolean) {
        viewModelScope.launch { configRepository.updateVoiceTuning(speed, pitch, autoSpeak) }
    }

    fun updateCustomVoiceApi(providerId: String, url: String, apiKey: String, voiceId: String) {
        viewModelScope.launch {
            configRepository.updateCustomVoiceApi(providerId, url, apiKey, voiceId)
            _statusMessage.value = "Voice API settings saved locally on device."
        }
    }

    fun updatePersonalization(
        autoRouteEnabled: Boolean = config.value.autoRouteEnabled,
        responseStyle: ResponseStyle = config.value.responseStyle,
        customInstructions: String = config.value.customInstructions,
        hapticsEnabled: Boolean = config.value.hapticsEnabled,
        streamAnimationEnabled: Boolean = config.value.streamAnimationEnabled
    ) {
        viewModelScope.launch {
            configRepository.updatePersonalization(
                autoRouteEnabled = autoRouteEnabled,
                responseStyle = responseStyle,
                customInstructions = customInstructions,
                hapticsEnabled = hapticsEnabled,
                streamAnimationEnabled = streamAnimationEnabled
            )
            persistProfileValues(
                autoRouteEnabled = autoRouteEnabled,
                responseStyle = responseStyle.id,
                customInstructions = customInstructions
            )
        }
    }

    fun saveProviderKey(provider: AiProviderKind, apiKey: String, baseUrl: String) {
        viewModelScope.launch {
            providerAuthManager.saveCredential(provider, apiKey, baseUrl)
            _statusMessage.value = "${provider.displayName} credentials saved locally (never uploaded to cloud)."
        }
    }

    fun clearProviderKey(provider: AiProviderKind) {
        viewModelScope.launch {
            providerAuthManager.clearCredential(provider)
            _statusMessage.value = "${provider.displayName} key removed from device."
        }
    }

    fun fetchProviderModels(provider: AiProviderKind) {
        val ext = externalProviders[provider] ?: return
        viewModelScope.launch {
            _statusMessage.value = "Fetching models from ${provider.displayName}..."
            ext.fetchAvailableModels()
                .onSuccess { list ->
                    modelCatalog.registerFetchedModels(provider, list)
                    _statusMessage.value = "Loaded ${list.size} live models from ${provider.displayName}."
                }
                .onFailure { err ->
                    _statusMessage.value = err.message ?: "Failed to fetch models"
                }
        }
    }

    // ---- Real-Time Cloudy Live Voice Control ----
    fun togglePreferOpenAiRealtime(enabled: Boolean) {
        _preferOpenAiRealtime.value = enabled
    }

    fun startLiveVoiceSession() {
        val cfg = config.value
        val persona = CloudyVoicePersona.fromId(cfg.voiceProfileId)
        val openAiKey = providerCredentials.value[AiProviderKind.OPENAI]?.apiKey.orEmpty()
        liveEngine.startSession(
            languageCode = effectiveLanguageCode.value,
            persona = persona,
            openAiApiKey = openAiKey,
            preferOpenAiRealtime = _preferOpenAiRealtime.value && openAiKey.isNotBlank(),
            customInstructions = cfg.customInstructions
        )
    }

    fun toggleLiveMute() = liveEngine.toggleMute()
    fun interruptLiveVoice() = liveEngine.interruptAssistant()
    fun reconnectLiveVoice() = liveEngine.reconnect()
    fun endLiveVoiceSession() = liveEngine.endSession()

    fun speakText(text: String, messageId: String? = null) {
        val cfg = config.value
        val persona = CloudyVoicePersona.fromId(cfg.voiceProfileId)
        voiceEngine.speak(
            text = text,
            messageId = messageId,
            persona = persona,
            languageCode = effectiveLanguageCode.value,
            speedMultiplier = cfg.voiceSpeed,
            pitchMultiplier = cfg.voicePitch,
            apiProvider = VoiceApiProvider.fromId(cfg.customVoiceApiProvider),
            apiUrl = cfg.customVoiceApiUrl,
            apiKey = cfg.customVoiceApiKey,
            customVoiceId = cfg.customVoiceId
        )
    }

    fun stopSpeaking() = voiceEngine.stopSpeaking()

    fun testActiveVoice() {
        val lang = effectiveLanguageCode.value
        val sample = if (lang == "tr") {
            "Merhaba! Ben Cloudy Live. Doğal ve akıcı stüdyo sesimle seninle konuşmaya hazırım."
        } else {
            "Hello! This is Cloudy Live speaking with a clear, natural studio voice."
        }
        speakText(sample, messageId = "voice_test")
    }

    fun verifyAppCheckNow() {
        _hasAppCheckIssue.value = false
        AppCheckCoordinator.probeAppCheckExchange(getApplication(), forceRefresh = true)
        _statusMessage.value = "App Check token verification triggered."
    }

    fun applyManualAppCheckToken(secret: String) {
        if (secret.isBlank()) return
        _hasAppCheckIssue.value = false
        AppCheckCoordinator.applyManualDebugToken(getApplication(), secret)
        _statusMessage.value = "App Check debug secret applied."
    }

    private fun persistCurrentProfileToCloud(defaultModelId: String = _activePlatformModel.value.id) {
        viewModelScope.launch { persistProfileValues(defaultModelId = defaultModelId) }
    }

    private suspend fun persistProfileValues(
        themeMode: AppThemeMode = config.value.themeMode,
        proUnlocked: Boolean = config.value.proCrystalUnlocked,
        preferredLang: String = config.value.preferredLanguageCode,
        countryCode: String = config.value.countryCode,
        defaultModelId: String = _activePlatformModel.value.id,
        voiceProfileId: String = config.value.voiceProfileId,
        plan: SubscriptionPlan = config.value.subscriptionPlan,
        autoRouteEnabled: Boolean = config.value.autoRouteEnabled,
        responseStyle: String = config.value.responseStyle.id,
        customInstructions: String = config.value.customInstructions
    ) {
        cloudRepository.saveUserProfile(
            themeMode = themeMode,
            proUnlocked = proUnlocked,
            preferredLanguageCode = preferredLang,
            countryCode = countryCode,
            defaultModelId = defaultModelId,
            voiceProfileId = voiceProfileId,
            subscriptionTier = plan.id,
            autoRouteEnabled = autoRouteEnabled,
            responseStyle = responseStyle,
            customInstructions = customInstructions
        )
    }

    // ---- Multi-Image & Document Attachments ----
    fun attachImageFromUri(uri: Uri) = attachImagesFromUris(listOf(uri))

    fun attachImagesFromUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val decoded = withContext(Dispatchers.IO) {
                uris.take(4).mapNotNull { uri -> decodeSampledBitmap(uri) }
            }
            if (decoded.isNotEmpty()) {
                val merged = (_attachedImages.value + decoded).take(4)
                _attachedImages.value = merged
                _attachedImageLabel.value = "${merged.size} image(s) • ${merged.first().width}x${merged.first().height}px"
                _statusMessage.value = "Attached ${decoded.size} image(s) for multimodal analysis."
            } else {
                _statusMessage.value = "Could not decode selected image."
            }
        }
    }

    private fun decodeSampledBitmap(uri: Uri): Bitmap? = runCatching {
        val resolver = getApplication<Application>().contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val maxDim = max(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
        var sampleSize = 1
        while (maxDim / sampleSize > 1024) sampleSize *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }.getOrNull()

    fun clearAttachedImage() {
        _attachedImages.value = emptyList()
        _attachedImageLabel.value = null
    }

    fun attachDocumentUri(uri: Uri) {
        viewModelScope.launch {
            _statusMessage.value = "Reading document..."
            documentEngine.extractFromUri(uri)
                .onSuccess { payload ->
                    _attachedDocument.value = payload
                    if (payload.pagePreviewBitmaps.isNotEmpty() && _attachedImages.value.isEmpty()) {
                        _attachedImages.value = payload.pagePreviewBitmaps.take(3)
                        _attachedImageLabel.value = "${payload.fileName} (${payload.pagePreviewBitmaps.size} page visuals)"
                    }
                    memoryRepository.saveDocumentArtifact(
                        DocumentArtifactEntity(
                            userId = userId.ifBlank { "local" },
                            fileName = payload.fileName,
                            mimeType = payload.mimeType,
                            sizeBytes = payload.charCount.toLong(),
                            pageCount = payload.pagePreviewBitmaps.size.coerceAtLeast(1),
                            extractedText = payload.extractedText.take(8000)
                        )
                    )
                    _statusMessage.value = "Document ready: ${payload.summaryNote}"
                }
                .onFailure { err ->
                    _statusMessage.value = err.message ?: "Failed to read document"
                }
        }
    }

    fun clearAttachedDocument() {
        _attachedDocument.value = null
    }

    fun toggleWebSearchMode() {
        _webSearchEnabled.value = !_webSearchEnabled.value
    }

    fun toggleCodingMode() {
        _codingModeEnabled.value = !_codingModeEnabled.value
    }

    // ---- Real Image Generation Studio ----
    fun generateStudioImage(
        prompt: String,
        modelOption: CloudyImageModelOption,
        aspectOption: ImageAspectOption,
        referenceBitmap: Bitmap? = null
    ) {
        if (modelOption == CloudyImageModelOption.GEMINI_3_PRO_IMAGE &&
            config.value.subscriptionPlan == SubscriptionPlan.FREE
        ) {
            _upgradePromptModel.value = CrystalXModelId.PRO_1_0
            return
        }
        viewModelScope.launch {
            _studioImageState.value = StudioImageGenState.Generating
            imageGenerationService.generateOrEdit(
                prompt = prompt,
                modelOption = modelOption,
                aspectOption = aspectOption,
                referenceBitmap = referenceBitmap
            ).onSuccess { output ->
                memoryRepository.saveGeneratedImage(
                    GeneratedImageEntity(
                        userId = userId.ifBlank { "local" },
                        prompt = prompt.trim(),
                        modelId = output.modelId,
                        aspectRatio = output.aspectRatioLabel,
                        filePath = output.localFilePath
                    )
                )
                _studioImageState.value = StudioImageGenState.Success(
                    path = output.localFilePath,
                    bitmap = output.bitmap,
                    modelId = output.modelId,
                    latencyMs = output.latencyMs
                )
                _statusMessage.value = "Image generated in ${output.latencyMs}ms"
            }.onFailure { err ->
                _studioImageState.value = StudioImageGenState.Error(err.message ?: "Image generation failed")
            }
        }
    }

    fun exportGeneratedImageToGallery(entity: GeneratedImageEntity) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(entity.filePath) }
            if (bmp == null) {
                _statusMessage.value = "Image file not found on device."
                return@launch
            }
            imageGenerationService.exportToDeviceGallery(bmp, entity.prompt)
                .onSuccess { msg -> _statusMessage.value = msg }
                .onFailure { err -> _statusMessage.value = err.message ?: "Export failed" }
        }
    }

    fun deleteGeneratedImage(id: Long) {
        viewModelScope.launch { memoryRepository.deleteGeneratedImage(id) }
    }

    fun deleteDocumentArtifact(id: Long) {
        viewModelScope.launch { memoryRepository.deleteDocumentArtifact(id) }
    }

    // ---- Chat Execution, Stop, Edit, Regenerate, Continue ----
    fun stopGeneration() {
        generationJob?.cancel()
        generationJob = null
        _streamingText.value = null
        _streamingModelLabel.value = null
        _isProcessing.value = false
        _statusMessage.value = "Generation stopped."
    }

    fun editUserMessageAndResend(message: CloudMessage, newContent: String) {
        val convId = _activeConversationId.value ?: return
        val clean = newContent.trim()
        if (clean.isBlank() || _isProcessing.value) return
        viewModelScope.launch {
            cloudRepository.updateCloudMessage(convId, message.id, clean)
            submitPrompt(clean, skipAppendingUserBubble = true)
        }
    }

    fun regenerateAssistantMessage(assistantMessage: CloudMessage) {
        if (_isProcessing.value) return
        val messages = (cloudMessages.value as? UiState.Success)?.data.orEmpty()
        val idx = messages.indexOfFirst { it.id == assistantMessage.id }
        val precedingUser = if (idx > 0) {
            messages.subList(0, idx).lastOrNull { it.role == "user" }
        } else {
            messages.lastOrNull { it.role == "user" }
        } ?: return

        val convId = _activeConversationId.value ?: return
        viewModelScope.launch {
            cloudRepository.deleteCloudMessage(convId, assistantMessage.id)
            submitPrompt(precedingUser.content, skipAppendingUserBubble = true)
        }
    }

    fun continueGeneratingFrom(assistantMessage: CloudMessage) {
        if (_isProcessing.value) return
        val lang = effectiveLanguageCode.value
        val prompt = if (lang == "tr") {
            "Kaldığın yerden devam et ve önceki cevabı eksiksiz tamamla:\n\nSon bölüm: ${assistantMessage.content.takeLast(500)}"
        } else {
            "Continue seamlessly from where your previous response stopped:\n\nLast section: ${assistantMessage.content.takeLast(500)}"
        }
        submitPrompt(prompt, skipAppendingUserBubble = false)
    }

    fun submitPrompt(prompt: String, skipAppendingUserBubble: Boolean = false) {
        val pendingImages = _attachedImages.value
        val pendingDoc = _attachedDocument.value
        if ((prompt.isBlank() && pendingImages.isEmpty() && pendingDoc == null) || _isProcessing.value) return

        val effectivePrompt = prompt.trim().ifBlank {
            when {
                pendingDoc != null && effectiveLanguageCode.value == "tr" ->
                    "Eklenen belgeyi (${pendingDoc.fileName}) incele, ana başlıkları özetle ve önemli bulguları çıkar."
                pendingDoc != null ->
                    "Analyze the attached document (${pendingDoc.fileName}), summarize key findings and structure."
                effectiveLanguageCode.value == "tr" ->
                    "Eklenen görseli ayrıntılı analiz et, içindeki metin/kod/arayüz detaylarını özetle."
                else ->
                    "Analyze the attached image(s) in detail and extract key insights."
            }
        }

        val currentCfg = config.value
        val routeDecision = intelligentRouter.resolveModelForTurn(
            prompt = effectivePrompt,
            selectedModel = _activePlatformModel.value,
            autoRouteEnabled = currentCfg.autoRouteEnabled,
            hasImages = pendingImages.isNotEmpty(),
            hasDocument = pendingDoc != null,
            codingMode = _codingModeEnabled.value,
            plan = currentCfg.subscriptionPlan,
            credentials = providerCredentials.value,
            fastApiUrl = currentCfg.controlPlaneUrl
        )
        val chosenModel = routeDecision.selectedModel
        val legacyEnum = chosenModel.legacyCrystalId ?: CrystalXModelId.NEO_1_1

        if (chosenModel.provider == AiProviderKind.CLOUDY_FIREBASE && !currentCfg.subscriptionPlan.canAccess(legacyEnum)) {
            _upgradePromptModel.value = legacyEnum
            return
        }

        _attachedImages.value = emptyList()
        _attachedImageLabel.value = null
        _attachedDocument.value = null

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            _isProcessing.value = true
            _hasAppCheckIssue.value = false
            try {
                val convId = _activeConversationId.value ?: run {
                    val created = cloudRepository.createConversation(
                        title = effectivePrompt.take(36),
                        activeModelId = chosenModel.id,
                        pinned = false
                    )
                    created.getOrElse { err ->
                        _statusMessage.value = err.localizedMessage ?: "Failed to create thread"
                        return@launch
                    }.also { _activeConversationId.value = it }
                }

                val detected = MultilingualLanguageSystem.detectLanguage(
                    input = effectivePrompt,
                    fallbackLanguageCode = effectiveLanguageCode.value
                )
                val targetLang = detected.explicitSwitchTarget ?: when (currentCfg.preferredLanguageCode) {
                    "system" -> MultilingualLanguageSystem.resolveSystemLanguageCode()
                    "auto" -> detected.primaryCode
                    else -> currentCfg.preferredLanguageCode
                }
                _activeConversationLang.value = targetLang
                val country = MultilingualLanguageSystem.countryForCode(currentCfg.countryCode)

                if (!skipAppendingUserBubble) {
                    val userAttachmentTag = buildString {
                        if (pendingImages.isNotEmpty()) append("[${pendingImages.size} Image(s)] ")
                        if (pendingDoc != null) append("[File: ${pendingDoc.fileName}] ")
                    }
                    cloudRepository.appendCloudMessage(
                        conversationId = convId,
                        role = "user",
                        content = "$userAttachmentTag$effectivePrompt",
                        modelLabel = "user",
                        languageCode = targetLang,
                        verificationStatus = "USER_INPUT",
                        latencyMs = 0L
                    )
                }

                val citations = if (_webSearchEnabled.value) {
                    webSearchService.search(effectivePrompt, targetLang)
                } else emptyList()
                _latestWebCitations.value = citations

                val mathCheck = reasoningEngine.evaluate(effectivePrompt, targetLang)
                val localCodeCheck = if (
                    chosenModel.id == CrystalXModelId.VISION_CODE.id ||
                    _codingModeEnabled.value ||
                    effectivePrompt.contains("def ") ||
                    effectivePrompt.contains("fun ")
                ) {
                    codingEngine.analyzeCode(effectivePrompt, targetLang)
                } else null

                val localVerifiedNote = when {
                    mathCheck.verificationStatus == VerificationStatus.VERIFIED_COMPUTATION ->
                        "Verified exact math result: ${mathCheck.answer}"
                    localCodeCheck != null ->
                        "Static code AST check (${localCodeCheck.detectedLanguage}): balanced=${localCodeCheck.delimitersBalanced}, warnings=${localCodeCheck.securityFindings.size}"
                    else -> null
                }

                val vaultAutoEnabled = (integrationsState.value as? UiState.Success)?.data
                    ?.firstOrNull { it.type == "cloud_vault" }?.enabled ?: true
                val pinnedNotes = if (vaultAutoEnabled) {
                    (cloudMemories.value as? UiState.Success)?.data
                        ?.filter { it.pinned }
                        ?.map { "[${it.category}] ${it.title}: ${it.content}" }
                        .orEmpty()
                } else emptyList()

                val integrationNotes = _attachedIntegrationNotes.value
                val historyTurns = (cloudMessages.value as? UiState.Success)?.data
                    ?.takeLast(10)
                    ?.map { it.role to it.content }
                    .orEmpty()

                val citationFooter = if (citations.isNotEmpty()) {
                    "\n\n---\n**Sources**\n" + citations.joinToString("\n") { "- [${it.title}](${it.url})" }
                } else ""

                // Branch 1: External BYOK HTTP Provider (OpenAI, Claude, DeepSeek, Meta Llama, Qwen, Mistral)
                val extProvider = externalProviders[chosenModel.provider]
                if (extProvider != null) {
                    _streamingModelLabel.value = chosenModel.displayName
                    _streamingText.value = ""
                    val normReq = NormalizedAiRequest(
                        model = chosenModel,
                        prompt = effectivePrompt,
                        attachedImages = pendingImages,
                        documentContext = pendingDoc?.extractedText,
                        webCitations = citations,
                        historyTurns = historyTurns,
                        pinnedContextNotes = pinnedNotes,
                        integrationNotes = integrationNotes,
                        responseLanguageCode = targetLang,
                        country = country,
                        responseStyle = currentCfg.responseStyle,
                        customInstructions = currentCfg.customInstructions,
                        codingMode = _codingModeEnabled.value,
                        localVerifiedNote = localVerifiedNote
                    )
                    extProvider.streamGenerate(normReq).collect { chunk ->
                        when (chunk) {
                            is NormalizedAiChunk.Delta -> {
                                _streamingText.value = chunk.accumulatedText
                                _streamingModelLabel.value = chunk.modelLabel
                            }
                            is NormalizedAiChunk.Completed -> {
                                _streamingText.value = null
                                _streamingModelLabel.value = null
                                cloudRepository.appendCloudMessage(
                                    conversationId = convId,
                                    role = "assistant",
                                    content = chunk.finalText + citationFooter,
                                    modelLabel = chunk.modelLabel,
                                    languageCode = targetLang,
                                    verificationStatus = VerificationStatus.REMOTE_MODEL_UNVERIFIED.name,
                                    latencyMs = chunk.latencyMs
                                )
                            }
                            is NormalizedAiChunk.Failure -> {
                                _streamingText.value = null
                                _streamingModelLabel.value = null
                                _statusMessage.value = chunk.message
                            }
                        }
                    }
                    return@launch
                }

                // Branch 2: Cloudy Local CPU
                if (chosenModel.id == CrystalXModelId.LOCAL_CPU.id) {
                    val req = GenixRequest(
                        prompt = effectivePrompt,
                        preferredLanguageCode = targetLang,
                        activeConversationLanguage = _activeConversationLang.value
                    )
                    coreEngine.processRequest(req, currentCfg).onSuccess { resp ->
                        _activeConversationLang.value = resp.responseLanguageCode
                        _routerPreview.value = resp.routingDecision
                        cloudRepository.appendCloudMessage(
                            conversationId = convId,
                            role = "assistant",
                            content = resp.content,
                            modelLabel = chosenModel.displayName,
                            languageCode = resp.responseLanguageCode,
                            verificationStatus = resp.verificationStatus.name,
                            latencyMs = resp.latencyMs
                        )
                    }.onFailure { err ->
                        _statusMessage.value = err.message ?: "Local CPU Engine failed"
                    }
                    return@launch
                }

                // Branch 3: Cloudy Multi-AI Ensemble
                if (chosenModel.id == CrystalXModelId.MULTI_AI.id) {
                    _streamingModelLabel.value = "Cloudy Multi-AI (2.0 Breeze + 1.1 Neo + 1.0 Pro)"
                    _streamingText.value = "Synthesizing Multi-AI Consensus..."
                    when (val res = aiService.generateMultiAiComparison(
                        prompt = effectivePrompt,
                        attachedImages = pendingImages,
                        historyTurns = historyTurns,
                        pinnedContextNotes = pinnedNotes,
                        integrationNotes = integrationNotes,
                        responseLanguageCode = targetLang,
                        country = country,
                        localVerifiedNote = localVerifiedNote,
                        documentContext = pendingDoc?.extractedText,
                        webCitations = citations,
                        responseStyle = currentCfg.responseStyle,
                        customInstructions = currentCfg.customInstructions,
                        codingMode = _codingModeEnabled.value
                    )) {
                        is AiStreamEvent.Completed -> {
                            _streamingText.value = null
                            _streamingModelLabel.value = null
                            cloudRepository.appendCloudMessage(
                                conversationId = convId,
                                role = "assistant",
                                content = res.finalText + citationFooter,
                                modelLabel = res.modelLabel,
                                languageCode = targetLang,
                                verificationStatus = if (localVerifiedNote != null) VerificationStatus.VERIFIED_COMPUTATION.name else VerificationStatus.REMOTE_MODEL_UNVERIFIED.name,
                                latencyMs = res.latencyMs
                            )
                        }
                        is AiStreamEvent.Error -> {
                            _hasAppCheckIssue.value = res.isAppCheckError
                            _statusMessage.value = res.message
                        }
                        is AiStreamEvent.Chunk -> Unit
                    }
                    return@launch
                }

                // Branch 4: Cloudy DeepThink Ultra
                if (chosenModel.id == CrystalXModelId.DEEPTHINK_ULTRA.id) {
                    _streamingModelLabel.value = chosenModel.displayName
                    _streamingText.value = ""
                    aiService.streamDeepThinkUltra(
                        prompt = effectivePrompt,
                        attachedImages = pendingImages,
                        historyTurns = historyTurns,
                        pinnedContextNotes = pinnedNotes,
                        integrationNotes = integrationNotes,
                        responseLanguageCode = targetLang,
                        country = country,
                        localVerifiedNote = localVerifiedNote,
                        documentContext = pendingDoc?.extractedText,
                        webCitations = citations,
                        responseStyle = currentCfg.responseStyle,
                        customInstructions = currentCfg.customInstructions,
                        codingMode = _codingModeEnabled.value
                    ).collect { event ->
                        when (event) {
                            is AiStreamEvent.Chunk -> {
                                _streamingText.value = event.accumulatedText
                                _streamingModelLabel.value = event.modelLabel
                            }
                            is AiStreamEvent.Completed -> {
                                _streamingText.value = null
                                _streamingModelLabel.value = null
                                cloudRepository.appendCloudMessage(
                                    conversationId = convId,
                                    role = "assistant",
                                    content = event.finalText + citationFooter,
                                    modelLabel = event.modelLabel,
                                    languageCode = targetLang,
                                    verificationStatus = VerificationStatus.VERIFIED_COMPUTATION.name,
                                    latencyMs = event.latencyMs
                                )
                            }
                            is AiStreamEvent.Error -> {
                                _hasAppCheckIssue.value = event.isAppCheckError
                                _statusMessage.value = event.message
                            }
                        }
                    }
                    return@launch
                }

                // Branch 5: Standard Cloudy Firebase Model (2.0 Breeze / 1.1 Neo / 1.0 Pro / Vision & Code / Voice Live)
                val targetCrystalId = if (pendingImages.isNotEmpty() && !legacyEnum.supportsVision) {
                    if (currentCfg.subscriptionPlan.canAccess(CrystalXModelId.VISION_CODE)) CrystalXModelId.VISION_CODE else CrystalXModelId.NEO_1_1
                } else legacyEnum

                _streamingModelLabel.value = targetCrystalId.displayName
                _streamingText.value = ""
                aiService.streamSingleModel(
                    modelId = targetCrystalId,
                    prompt = effectivePrompt,
                    attachedImages = pendingImages,
                    historyTurns = historyTurns,
                    pinnedContextNotes = pinnedNotes,
                    integrationNotes = integrationNotes,
                    responseLanguageCode = targetLang,
                    country = country,
                    localVerifiedNote = localVerifiedNote,
                    documentContext = pendingDoc?.extractedText,
                    webCitations = citations,
                    responseStyle = currentCfg.responseStyle,
                    customInstructions = currentCfg.customInstructions,
                    codingMode = _codingModeEnabled.value
                ).collect { event ->
                    when (event) {
                        is AiStreamEvent.Chunk -> {
                            _streamingText.value = event.accumulatedText
                            _streamingModelLabel.value = event.modelLabel
                        }
                        is AiStreamEvent.Completed -> {
                            _streamingText.value = null
                            _streamingModelLabel.value = null
                            cloudRepository.appendCloudMessage(
                                conversationId = convId,
                                role = "assistant",
                                content = event.finalText + citationFooter,
                                modelLabel = event.modelLabel,
                                languageCode = targetLang,
                                verificationStatus = if (localVerifiedNote != null) VerificationStatus.VERIFIED_COMPUTATION.name else VerificationStatus.REMOTE_MODEL_UNVERIFIED.name,
                                latencyMs = event.latencyMs
                            )
                            if (targetCrystalId == CrystalXModelId.VOICE_LIVE && currentCfg.autoSpeakLiveReplies) {
                                speakText(event.finalText, messageId = "live_latest")
                            }
                        }
                        is AiStreamEvent.Error -> {
                            _hasAppCheckIssue.value = event.isAppCheckError
                            _statusMessage.value = event.message
                        }
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } finally {
                _streamingText.value = null
                _streamingModelLabel.value = null
                _isProcessing.value = false
            }
        }
    }

    // ---- Integrations, Vault, Conversations, Settings & Data Export ----
    fun addIntegration(type: String, name: String, targetUrl: String, notes: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            cloudRepository.addIntegration(type, name, targetUrl, notes, enabled = true)
                .onSuccess { _statusMessage.value = "Integration '$name' saved." }
                .onFailure { err -> _statusMessage.value = err.localizedMessage ?: "Failed to save integration" }
        }
    }

    fun toggleIntegration(item: UserIntegration) {
        viewModelScope.launch { cloudRepository.toggleIntegrationEnabled(item) }
    }

    fun deleteIntegration(id: String) {
        viewModelScope.launch { cloudRepository.deleteIntegration(id) }
    }

    fun runIntegrationAction(item: UserIntegration, customTestText: String = "Cloudy AI Integration Sync Test") {
        viewModelScope.launch {
            _runningIntegrationId.value = item.id
            try {
                when (item.type) {
                    "github_repo" -> CloudyIntegrationsEngine.fetchGitHubRepoSummary(item.targetUrl)
                        .onSuccess {
                            attachIntegrationNote(it)
                            cloudRepository.updateIntegrationTargetAndStatus(item.id, lastStatus = "Fetched & attached")
                            _statusMessage.value = "GitHub repo context attached!"
                        }
                        .onFailure { _statusMessage.value = it.message ?: "GitHub fetch failed" }
                    "web_feed" -> CloudyIntegrationsEngine.fetchWebOrRssSnippet(item.targetUrl)
                        .onSuccess {
                            attachIntegrationNote(it)
                            cloudRepository.updateIntegrationTargetAndStatus(item.id, lastStatus = "Fetched live content")
                            _statusMessage.value = "Web/RSS snippet attached!"
                        }
                        .onFailure { _statusMessage.value = it.message ?: "Web fetch failed" }
                    "webhook" -> CloudyIntegrationsEngine.dispatchWebhook(item.targetUrl, item.name, customTestText, _activePlatformModel.value.displayName)
                        .onSuccess {
                            cloudRepository.updateIntegrationTargetAndStatus(item.id, lastStatus = it)
                            _statusMessage.value = it
                        }
                        .onFailure { _statusMessage.value = it.message ?: "Webhook failed" }
                    "fastapi_node" -> {
                        val probe = remoteFastApiAdapter.probeHealth(item.targetUrl)
                        cloudRepository.updateIntegrationTargetAndStatus(item.id, lastStatus = "${probe.statusText} (${probe.latencyMs}ms)")
                        _statusMessage.value = "${probe.statusText}: ${probe.details}"
                    }
                    else -> _statusMessage.value = "${item.name}: Active"
                }
            } finally {
                _runningIntegrationId.value = null
            }
        }
    }

    fun attachIntegrationNote(note: String) {
        if (note.isBlank()) return
        val current = _attachedIntegrationNotes.value.toMutableList()
        current.add(0, note.take(1800))
        _attachedIntegrationNotes.value = current.take(3)
    }

    fun clearAttachedIntegrationNotes() {
        _attachedIntegrationNotes.value = emptyList()
    }

    fun sendMessageToActiveWebhooks(msg: CloudMessage) {
        val hooks = (integrationsState.value as? UiState.Success)?.data
            ?.filter { it.type == "webhook" && it.enabled && it.targetUrl.isNotBlank() }.orEmpty()
        if (hooks.isEmpty()) {
            _statusMessage.value = "No active Webhook integration configured."
            return
        }
        viewModelScope.launch {
            var delivered = 0
            hooks.forEach { hook ->
                CloudyIntegrationsEngine.dispatchWebhook(hook.targetUrl, "Cloudy AI Reply", msg.content, msg.modelLabel)
                    .onSuccess { delivered++ }
            }
            _statusMessage.value = "Sent reply to $delivered/${hooks.size} active webhooks."
        }
    }

    fun selectConversation(thread: ConversationThread) {
        _activeConversationId.value = thread.id
        syncSelectedModelIds(thread.activeModelId)
    }

    fun createNewConversation(title: String = "") {
        viewModelScope.launch {
            val cleanTitle = title.trim().ifBlank {
                val count = (conversations.value as? UiState.Success)?.data?.size ?: 0
                "Cloudy #${count + 1}"
            }
            cloudRepository.createConversation(cleanTitle, _activePlatformModel.value.id, pinned = false)
                .onSuccess { newId ->
                    _activeConversationId.value = newId
                    _statusMessage.value = "Started $cleanTitle"
                }
        }
    }

    fun toggleConversationPin(thread: ConversationThread) {
        viewModelScope.launch { cloudRepository.toggleConversationPin(thread.id, thread.pinned) }
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch { cloudRepository.renameConversation(conversationId, newTitle) }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            cloudRepository.deleteConversation(conversationId).onSuccess {
                if (_activeConversationId.value == conversationId) _activeConversationId.value = null
                _statusMessage.value = "Conversation deleted."
            }
        }
    }

    fun deleteAllUserConversations() {
        viewModelScope.launch {
            cloudRepository.deleteAllConversations()
                .onSuccess { count ->
                    _activeConversationId.value = null
                    _statusMessage.value = "Deleted $count conversations."
                }
        }
    }

    fun clearAllGeneratedImages() {
        viewModelScope.launch {
            memoryRepository.clearGeneratedImages(userId.ifBlank { "local" })
            _statusMessage.value = "Cleared generated image history."
        }
    }

    fun resetLocalPreferencesAndKeys() {
        viewModelScope.launch {
            providerAuthManager.clearAllKeys()
            configRepository.updatePersonalization(false, ResponseStyle.BALANCED, "", true, true)
            _statusMessage.value = "Local BYOK keys and preferences reset."
        }
    }

    fun exportAllWorkspaceData() {
        val threads = (conversations.value as? UiState.Success)?.data.orEmpty()
        val memories = (cloudMemories.value as? UiState.Success)?.data.orEmpty()
        val payload = JSONObject().apply {
            put("app", "Cloudy AI v2.0")
            put("userId", userId)
            put("plan", config.value.subscriptionPlan.id)
            put("threads", JSONArray().apply {
                threads.forEach { t -> put(JSONObject().put("title", t.title).put("model", t.activeModelId)) }
            })
            put("memories", JSONArray().apply {
                memories.forEach { m -> put(JSONObject().put("title", m.title).put("category", m.category).put("content", m.content)) }
            })
        }.toString(2)
        CloudyIntegrationsEngine.shareTextViaAndroidSheet(getApplication(), "Cloudy Workspace Export", payload)
    }

    fun toggleMessageStar(message: CloudMessage) {
        val convId = _activeConversationId.value ?: return
        if (message.id.isBlank()) return
        viewModelScope.launch { cloudRepository.toggleMessageStar(convId, message.id, message.starred) }
    }

    fun addCloudMemory(title: String, category: String, content: String, tagsRaw: String, pinned: Boolean) {
        if (title.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            val detectedLang = MultilingualLanguageSystem.detectLanguage(content).primaryCode
            val tags = tagsRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            cloudRepository.addMemoryItem(title, category, content, detectedLang, tags, pinned)
                .onSuccess { _statusMessage.value = "Saved to Cloud Vault" }
        }
    }

    fun updateCloudMemory(memoryId: String, title: String, category: String, content: String, tagsRaw: String) {
        if (title.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            val tags = tagsRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            cloudRepository.updateMemoryItem(memoryId, title, category, content, tags)
                .onSuccess { _statusMessage.value = "Memory updated" }
        }
    }

    fun toggleCloudMemoryPin(item: CloudMemoryItem) {
        viewModelScope.launch { cloudRepository.toggleMemoryPin(item) }
    }

    fun deleteCloudMemory(memoryId: String) {
        viewModelScope.launch { cloudRepository.deleteMemoryItem(memoryId) }
    }

    fun clearSession() {
        val currentId = _activeConversationId.value
        viewModelScope.launch {
            if (!currentId.isNullOrBlank()) {
                cloudRepository.deleteConversation(currentId)
                _activeConversationId.value = null
            }
            cloudRepository.createConversation("Cloudy Studio", _activePlatformModel.value.id, pinned = false)
                .onSuccess { newId -> _activeConversationId.value = newId }
            memoryRepository.clearConversation("default-session")
        }
    }

    fun toggleModelLoad(modelId: String) {
        viewModelScope.launch {
            val res = modelRegistry.toggleModelLoad(modelId)
            _statusMessage.value = res.fold(onSuccess = { it }, onFailure = { it.message ?: "Action blocked" })
        }
    }

    fun runModelHealthCheck(modelId: String) {
        viewModelScope.launch {
            val check = modelRegistry.runHealthCheck(modelId)
            _statusMessage.value = "${check.modelId}: ${check.details}"
        }
    }

    fun simulateRouter(prompt: String) {
        if (prompt.isBlank()) return
        val detected = MultilingualLanguageSystem.detectLanguage(prompt, effectiveLanguageCode.value)
        _routerPreview.value = modelRouter.route(
            prompt = prompt,
            languageCode = detected.primaryCode,
            availableModels = registeredModels.value,
            executionMode = config.value.executionMode,
            maxContextBudget = config.value.maxContextTokens
        )
    }

    fun updateTokenizerInput(text: String) {
        _labState.value = _labState.value.copy(tokenizerInput = text, tokenizationReport = tokenizer.analyze(text))
    }

    fun selectTransformerPreset(preset: TransformerArchitectureConfig) {
        _labState.value = _labState.value.copy(
            transformerConfig = preset,
            transformerEstimate = ExperimentalTransformerSpec.estimate(preset)
        )
    }

    fun analyzeLabCode(code: String) {
        _labState.value = _labState.value.copy(
            codeInput = code,
            codeReport = codingEngine.analyzeCode(code, effectiveLanguageCode.value)
        )
    }

    fun addKnowledgeDocument(title: String, source: String, content: String) {
        if (title.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            val lang = MultilingualLanguageSystem.detectLanguage(content).primaryCode
            memoryRepository.indexKnowledgeDocument(title, source, content, lang)
            if (_labState.value.knowledgeQuery.isNotBlank()) searchKnowledge(_labState.value.knowledgeQuery)
        }
    }

    fun deleteKnowledgeDocument(id: Long) {
        viewModelScope.launch {
            memoryRepository.deleteKnowledgeDocument(id)
            if (_labState.value.knowledgeQuery.isNotBlank()) searchKnowledge(_labState.value.knowledgeQuery)
        }
    }

    fun searchKnowledge(query: String) {
        viewModelScope.launch {
            val hits = if (query.isBlank()) emptyList() else memoryRepository.searchKnowledge(query)
            _labState.value = _labState.value.copy(knowledgeQuery = query, knowledgeSearchResults = hits)
        }
    }

    fun updatePreferredLanguage(code: String) {
        viewModelScope.launch {
            configRepository.updatePreferredLanguage(code)
            if (code == "system") _activeConversationLang.value = MultilingualLanguageSystem.resolveSystemLanguageCode()
            else if (code != "auto") _activeConversationLang.value = code
            persistProfileValues(preferredLang = code)
        }
    }

    fun updateExecutionMode(mode: ExecutionMode) {
        viewModelScope.launch { configRepository.updateExecutionMode(mode) }
    }

    fun probeRemoteControlPlane(url: String) {
        viewModelScope.launch {
            _isProbingRemote.value = true
            configRepository.updateControlPlaneUrl(url)
            _remoteProbe.value = remoteFastApiAdapter.probeHealth(url)
            _isProbingRemote.value = false
        }
    }

    fun clearAuditLogs() {
        viewModelScope.launch { memoryRepository.clearAuditLogs() }
    }

    fun estimateTokenCount(text: String): Int = tokenizer.analyze(text).tokenIds.size
    fun consumeStatusMessage() { _statusMessage.value = null }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.release()
        liveEngine.release()
    }
}
