package com.example.ui.screens

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.genix.ai.core.AiProviderKind
import com.example.genix.ai.security.ProviderCredentialRecord
import com.example.genix.core.ExecutionMode
import com.example.genix.core.GenixConfig
import com.example.genix.core.GenixEventLog
import com.example.genix.core.LogSeverity
import com.example.genix.core.ResponseStyle
import com.example.genix.core.SubscriptionPlan
import com.example.genix.firebase.AppCheckDiagnostics
import com.example.genix.firebase.AuthHelper
import com.example.genix.firebase.CloudyIntegrationsEngine
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.genix.models.RemoteProbeResult
import com.example.genix.voice.CloudyVoicePersona
import com.example.genix.voice.VoiceApiProvider
import com.example.genix.voice.VoicePlaybackState
import com.example.ui.components.CloudyMinimalCloudMark
import com.example.ui.components.MetricProgressRow
import com.example.ui.components.PulsingStatusDot
import com.example.ui.components.SectionHeader
import com.example.ui.components.TelemetryChip
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.EmeraldVerified
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalCloudyStyle
import com.example.ui.theme.RoseError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ControlPlaneScreen(
    config: GenixConfig,
    threadCount: Int,
    vaultCount: Int,
    estimatedUsedTokens: Int,
    providerCredentials: Map<AiProviderKind, ProviderCredentialRecord>,
    appCheckDiagnostics: AppCheckDiagnostics,
    voicePlaybackState: VoicePlaybackState,
    remoteProbe: RemoteProbeResult?,
    isProbingRemote: Boolean,
    auditLogs: List<GenixEventLog>,
    onSelectSubscriptionPlan: (SubscriptionPlan) -> Unit,
    onSelectThemeMode: (AppThemeMode) -> Unit,
    onSelectVoicePersona: (CloudyVoicePersona) -> Unit,
    onUpdateVoiceTuning: (speed: Float, pitch: Float, autoSpeak: Boolean) -> Unit,
    onUpdateCustomVoiceApi: (providerId: String, url: String, apiKey: String, voiceId: String) -> Unit,
    onTestVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onVerifyAppCheck: () -> Unit,
    onApplyManualAppCheckToken: (String) -> Unit,
    onSelectCountry: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectExecutionMode: (ExecutionMode) -> Unit,
    onProbeRemote: (String) -> Unit,
    onSaveProviderKey: (AiProviderKind, String, String) -> Unit,
    onClearProviderKey: (AiProviderKind) -> Unit,
    onFetchProviderModels: (AiProviderKind) -> Unit,
    onUpdatePersonalization: (
        autoRouteEnabled: Boolean,
        responseStyle: ResponseStyle,
        customInstructions: String,
        hapticsEnabled: Boolean,
        streamAnimationEnabled: Boolean
    ) -> Unit,
    onExportWorkspaceData: () -> Unit,
    onDeleteAllConversations: () -> Unit,
    onClearGeneratedImages: () -> Unit,
    onResetLocalKeysAndPrefs: () -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentUser = Firebase.auth.currentUser
    val cloudyStyle = LocalCloudyStyle.current

    var serverUrl by rememberSaveable(config.controlPlaneUrl) { mutableStateOf(config.controlPlaneUrl) }
    var voiceApiUrl by rememberSaveable(config.customVoiceApiUrl) { mutableStateOf(config.customVoiceApiUrl) }
    var voiceApiKey by rememberSaveable(config.customVoiceApiKey) { mutableStateOf(config.customVoiceApiKey) }
    var customVoiceId by rememberSaveable(config.customVoiceId) { mutableStateOf(config.customVoiceId) }
    var customInstructionsDraft by rememberSaveable(config.customInstructions) { mutableStateOf(config.customInstructions) }
    var manualAppCheckToken by rememberSaveable { mutableStateOf("") }
    var showManualTokenEntry by rememberSaveable { mutableStateOf(false) }

    var confirmDeleteThreads by remember { mutableStateOf(false) }
    var confirmResetKeys by remember { mutableStateOf(false) }
    var selectedByokProvider by remember { mutableStateOf(AiProviderKind.OPENAI) }
    var byokKeyInput by remember { mutableStateOf("") }
    var byokUrlInput by remember(selectedByokProvider, providerCredentials) {
        mutableStateOf(
            providerCredentials[selectedByokProvider]?.baseUrl ?: selectedByokProvider.defaultBaseUrl
        )
    }

    val timeFormatter = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    if (confirmDeleteThreads) {
        AlertDialog(
            onDismissRequest = { confirmDeleteThreads = false },
            title = { Text("Clear all conversations?") },
            text = { Text("All $threadCount conversations and messages in your private Firestore workspace will be permanently deleted.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAllConversations()
                        confirmDeleteThreads = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseError)
                ) {
                    Text("Delete All")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteThreads = false }) { Text("Cancel") }
            }
        )
    }

    if (confirmResetKeys) {
        AlertDialog(
            onDismissRequest = { confirmResetKeys = false },
            title = { Text("Reset local BYOK keys?") },
            text = { Text("All external AI provider API keys stored locally on this device will be wiped.") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetLocalKeysAndPrefs()
                        confirmResetKeys = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseError)
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmResetKeys = false }) { Text("Cancel") }
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(cloudyStyle.backgroundBrush)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(modifier = Modifier.widthIn(max = 840.dp)) {
                    SectionHeader(
                        title = "Cloudy Settings",
                        subtitle = "Plans • Appearance • Providers (BYOK) • Voice • Personalization • Privacy"
                    )
                }
            }

            // SECTION 1: Account & Subscription Plans
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.2.dp, cloudyStyle.crystalAccentBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = currentUser?.displayName?.takeIf { it.isNotBlank() } ?: "Cloudy User",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = currentUser?.email ?: (currentUser?.uid ?: "Signed in"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            TelemetryChip(label = config.subscriptionPlan.badge, accent = EmeraldVerified)
                        }

                        val quota = config.subscriptionPlan.monthlyTokenQuota.coerceAtLeast(1)
                        val tokenProgress = (estimatedUsedTokens.toFloat() / quota.toFloat()).coerceIn(0f, 1f)
                        val vaultQuota = config.subscriptionPlan.maxVaultSlots.coerceAtLeast(1)
                        val vaultProgress = (vaultCount.toFloat() / vaultQuota.toFloat()).coerceIn(0f, 1f)

                        MetricProgressRow(
                            label = "Monthly Token Usage",
                            fraction = tokenProgress,
                            valueLabel = "$estimatedUsedTokens / ${quota / 1000}K",
                            accent = MaterialTheme.colorScheme.primary
                        )
                        MetricProgressRow(
                            label = "Cloud Vault Slots",
                            fraction = vaultProgress,
                            valueLabel = "$vaultCount / $vaultQuota",
                            accent = EmeraldVerified
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Subscription Plans", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }

                        SubscriptionPlan.entries.forEach { plan ->
                            val isActive = config.subscriptionPlan == plan
                            Surface(
                                onClick = { onSelectSubscriptionPlan(plan) },
                                shape = RoundedCornerShape(16.dp),
                                color = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = BorderStroke(if (isActive) 2.dp else 1.dp, if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("plan_card_${plan.id}")
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(plan.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                            TelemetryChip(label = plan.badge)
                                        }
                                        Text(plan.priceLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                    }
                                    Text(plan.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    plan.highlights.forEach { line -> Text("• $line", style = MaterialTheme.typography.labelSmall) }
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = { AuthHelper.signOut(credentialManager, scope) },
                            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = RoseError)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sign Out / Switch Account", color = RoseError)
                        }
                    }
                }
            }

            // SECTION 2: Appearance (System Auto, Minimal Light, Ice Crystal Pro, Dark Obsidian)
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("2. Appearance & Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                        ThemeOptionCard(
                            title = "System Default (Auto)",
                            tier = "AUTO",
                            subtitle = "Automatically matches Android system dark or light appearance.",
                            previewColors = listOf(Color(0xFFFAFAFB), Color(0xFF17171B), Color(0xFF2563EB)),
                            icon = Icons.Filled.AutoMode,
                            selected = config.themeMode == AppThemeMode.SYSTEM,
                            isCrystalPro = false,
                            onClick = { onSelectThemeMode(AppThemeMode.SYSTEM) },
                            testTag = "theme_system"
                        )
                        ThemeOptionCard(
                            title = "Minimalist Light",
                            tier = "FREE",
                            subtitle = "Clean off-white canvas with crisp ink typography and subtle borders.",
                            previewColors = listOf(Color(0xFFFAFAFB), Color(0xFFFFFFFF), Color(0xFF18181B)),
                            icon = Icons.Filled.LightMode,
                            selected = config.themeMode == AppThemeMode.LIGHT_WHITE,
                            isCrystalPro = false,
                            onClick = { onSelectThemeMode(AppThemeMode.LIGHT_WHITE) },
                            testTag = "theme_light_white"
                        )
                        ThemeOptionCard(
                            title = "Ice Crystal",
                            tier = "PRO",
                            subtitle = "Cool Nordic sapphire tint with translucent surface layering.",
                            previewColors = listOf(Color(0xFFEDF6FC), Color(0xFFF8FCFF), Color(0xFF0369A1)),
                            icon = Icons.Filled.AcUnit,
                            selected = config.themeMode == AppThemeMode.ICE_CRYSTAL_PRO,
                            isCrystalPro = true,
                            onClick = { onSelectThemeMode(AppThemeMode.ICE_CRYSTAL_PRO) },
                            testTag = "theme_ice_crystal_pro"
                        )
                        ThemeOptionCard(
                            title = "Dark Obsidian",
                            tier = "FREE",
                            subtitle = "Deep charcoal surfaces with soft white ink for low-glare reading.",
                            previewColors = listOf(Color(0xFF0D0D0F), Color(0xFF17171B), Color(0xFFF4F4F5)),
                            icon = Icons.Filled.DarkMode,
                            selected = config.themeMode == AppThemeMode.DARK_OBSIDIAN,
                            isCrystalPro = false,
                            onClick = { onSelectThemeMode(AppThemeMode.DARK_OBSIDIAN) },
                            testTag = "theme_dark_obsidian"
                        )
                    }
                }
            }

            // SECTION 3: Language & Region
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("3. Language & Region", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            MultilingualLanguageSystem.supportedLanguages.forEach { lang ->
                                FilterChip(
                                    selected = config.preferredLanguageCode == lang.code,
                                    onClick = { onSelectLanguage(lang.code) },
                                    label = { Text(lang.nativeName) },
                                    modifier = Modifier.testTag("lang_chip_${lang.code}")
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Region (${MultilingualLanguageSystem.supportedCountries.size})", style = MaterialTheme.typography.titleSmall)
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            MultilingualLanguageSystem.supportedCountries.forEach { c ->
                                FilterChip(
                                    selected = config.countryCode == c.countryCode,
                                    onClick = { onSelectCountry(c.countryCode) },
                                    label = { Text("${c.flagEmoji} ${c.countryName} (${c.currencyCode})") },
                                    modifier = Modifier.testTag("country_chip_${c.countryCode}")
                                )
                            }
                        }
                    }
                }
            }

            // SECTION 4: AI Providers & BYOK Keys + Self-Hosted FastAPI
            item {
                val byokProviders = remember {
                    AiProviderKind.entries.filter { it.requiresByokKey }
                }
                val activeRecord = providerCredentials[selectedByokProvider]

                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Key, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("4. AI Providers (Device-Local BYOK)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            TelemetryChip(label = "LOCAL ONLY", accent = EmeraldVerified)
                        }
                        Text(
                            text = "Add optional API keys for OpenAI, Claude, DeepSeek, Meta Llama, Qwen, or Mistral. Keys stay encrypted/private inside device DataStore and are never synced to the cloud.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            byokProviders.forEach { provider ->
                                val hasKey = providerCredentials[provider]?.hasKey == true
                                FilterChip(
                                    selected = selectedByokProvider == provider,
                                    onClick = {
                                        selectedByokProvider = provider
                                        byokKeyInput = ""
                                    },
                                    leadingIcon = if (hasKey) {
                                        { Icon(Icons.Filled.CheckCircle, contentDescription = "Configured", tint = EmeraldVerified, modifier = Modifier.size(15.dp)) }
                                    } else null,
                                    label = { Text(provider.displayName) }
                                )
                            }
                        }

                        Text(
                            text = "${selectedByokProvider.docsHint} • Status: ${if (activeRecord?.hasKey == true) "Configured (${activeRecord.maskedKey()})" else "Not set"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (activeRecord?.hasKey == true) EmeraldVerified else MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = byokKeyInput,
                            onValueChange = { byokKeyInput = it },
                            label = { Text("${selectedByokProvider.displayName} API Key") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("byok_key_input")
                        )

                        OutlinedTextField(
                            value = byokUrlInput,
                            onValueChange = { byokUrlInput = it },
                            label = { Text("Base URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = {
                                    onSaveProviderKey(selectedByokProvider, byokKeyInput, byokUrlInput)
                                    byokKeyInput = ""
                                },
                                enabled = byokKeyInput.isNotBlank() || byokUrlInput != activeRecord?.baseUrl,
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("save_byok_button")
                            ) {
                                Text("Save Key Locally")
                            }
                            if (activeRecord?.hasKey == true) {
                                OutlinedButton(
                                    onClick = { onFetchProviderModels(selectedByokProvider) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Fetch Models")
                                }
                                OutlinedButton(
                                    onClick = { onClearProviderKey(selectedByokProvider) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Remove", color = RoseError)
                                }
                            }
                        }

                        // Self-Hosted FastAPI Node
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Dns, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Self-Hosted FastAPI / vLLM Endpoint", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = config.executionMode == ExecutionMode.LOCAL_CPU_FOUNDATION,
                                onClick = { onSelectExecutionMode(ExecutionMode.LOCAL_CPU_FOUNDATION) },
                                label = { Text("Cloudy + Local CPU") }
                            )
                            FilterChip(
                                selected = config.executionMode == ExecutionMode.REMOTE_FASTAPI_CONTROL_PLANE,
                                onClick = { onSelectExecutionMode(ExecutionMode.REMOTE_FASTAPI_CONTROL_PLANE) },
                                label = { Text("Remote FastAPI") }
                            )
                        }
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = { serverUrl = it },
                            label = { Text("FastAPI Base URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("fastapi_url_input")
                        )
                        Button(
                            onClick = { onProbeRemote(serverUrl) },
                            enabled = !isProbingRemote,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("probe_fastapi_button")
                        ) {
                            Icon(Icons.Filled.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isProbingRemote) "Probing..." else "Test /api/v1/health")
                        }
                        if (remoteProbe != null) {
                            TelemetryChip(
                                label = "${remoteProbe.statusText} • ${remoteProbe.latencyMs}ms",
                                accent = if (remoteProbe.reachable) EmeraldVerified else RoseError
                            )
                        }
                    }
                }
            }

            // SECTION 5: Voice Settings
            item {
                val activePersona = CloudyVoicePersona.fromId(config.voiceProfileId)
                val activeProvider = VoiceApiProvider.fromId(config.customVoiceApiProvider)
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("5. Universal Natural Voice", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            TelemetryChip(label = activePersona.badge, accent = EmeraldVerified)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth().height(24.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            voicePlaybackState.waveformBars.forEach { level ->
                                val barH by animateDpAsState(targetValue = (5f + level * 18f).dp, label = "ctrl_bar")
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(barH)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (voicePlaybackState.isSpeaking) EmeraldVerified else MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                                )
                            }
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            CloudyVoicePersona.entries.forEach { persona ->
                                FilterChip(
                                    selected = persona == activePersona,
                                    onClick = { onSelectVoicePersona(persona) },
                                    label = { Text("${persona.displayName} • ${persona.badge}") },
                                    modifier = Modifier.testTag("settings_voice_${persona.id}")
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Auto-Speak Live Replies", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = config.autoSpeakLiveReplies,
                                onCheckedChange = { onUpdateVoiceTuning(config.voiceSpeed, config.voicePitch, it) }
                            )
                        }

                        Text("Speed: ${String.format(Locale.US, "%.2fx", config.voiceSpeed)}", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = config.voiceSpeed,
                            onValueChange = { onUpdateVoiceTuning(it, config.voicePitch, config.autoSpeakLiveReplies) },
                            valueRange = 0.7f..1.5f
                        )
                        Text("Pitch: ${String.format(Locale.US, "%.2fx", config.voicePitch)}", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = config.voicePitch,
                            onValueChange = { onUpdateVoiceTuning(config.voiceSpeed, it, config.autoSpeakLiveReplies) },
                            valueRange = 0.8f..1.4f
                        )

                        Button(
                            onClick = if (voicePlaybackState.isSpeaking || voicePlaybackState.isSynthesizing) onStopVoice else onTestVoice,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("test_voice_button")
                        ) {
                            Icon(
                                imageVector = if (voicePlaybackState.isSpeaking || voicePlaybackState.isSynthesizing) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (voicePlaybackState.isSpeaking || voicePlaybackState.isSynthesizing) "Stop Voice" else "Test Studio Voice")
                        }

                        if (activePersona == CloudyVoicePersona.CUSTOM_API) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                VoiceApiProvider.entries.forEach { provider ->
                                    FilterChip(
                                        selected = provider == activeProvider,
                                        onClick = { onUpdateCustomVoiceApi(provider.id, voiceApiUrl, voiceApiKey, customVoiceId) },
                                        label = { Text(provider.label) }
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = voiceApiUrl,
                                onValueChange = { voiceApiUrl = it },
                                label = { Text("TTS Endpoint URL") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = customVoiceId,
                                onValueChange = { customVoiceId = it },
                                label = { Text("Voice ID") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = voiceApiKey,
                                onValueChange = { voiceApiKey = it },
                                label = { Text("TTS API Key") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = { onUpdateCustomVoiceApi(activeProvider.id, voiceApiUrl, voiceApiKey, customVoiceId) }
                            ) {
                                Text("Save Custom Voice API")
                            }
                        }
                    }
                }
            }

            // SECTION 6: Personalization & Memory
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Psychology, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("6. Personalization & Intelligence", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Intelligent Auto-Router", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text("Routes coding, deep reasoning, and vision turns automatically", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = config.autoRouteEnabled,
                                onCheckedChange = {
                                    onUpdatePersonalization(it, config.responseStyle, customInstructionsDraft, config.hapticsEnabled, config.streamAnimationEnabled)
                                }
                            )
                        }

                        Text("Response Style", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ResponseStyle.entries.forEach { style ->
                                FilterChip(
                                    selected = config.responseStyle == style,
                                    onClick = {
                                        onUpdatePersonalization(config.autoRouteEnabled, style, customInstructionsDraft, config.hapticsEnabled, config.streamAnimationEnabled)
                                    },
                                    label = { Text(style.labelEn) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = customInstructionsDraft,
                            onValueChange = { customInstructionsDraft = it },
                            label = { Text("Custom Instructions (applied to Cloudy & BYOK chats)") },
                            minLines = 2,
                            maxLines = 5,
                            modifier = Modifier.fillMaxWidth().testTag("custom_instructions_input")
                        )
                        Button(
                            onClick = {
                                onUpdatePersonalization(
                                    config.autoRouteEnabled,
                                    config.responseStyle,
                                    customInstructionsDraft,
                                    config.hapticsEnabled,
                                    config.streamAnimationEnabled
                                )
                            },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Save Personalization")
                        }
                    }
                }
            }

            // SECTION 7: Privacy, App Check & Security Logs
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (appCheckDiagnostics.tokenVerified) Icons.Filled.VerifiedUser else Icons.Filled.WarningAmber,
                                    contentDescription = null,
                                    tint = if (appCheckDiagnostics.tokenVerified) EmeraldVerified else AmberWarning
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("7. Privacy & App Check (${appCheckDiagnostics.mode})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                PulsingStatusDot(color = if (appCheckDiagnostics.tokenVerified) EmeraldVerified else AmberWarning)
                                TelemetryChip(label = "UID ISOLATED", accent = EmeraldVerified)
                            }
                        }

                        Text(appCheckDiagnostics.statusNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        if (appCheckDiagnostics.debugTokenPreview.isNotBlank()) {
                            Text(
                                text = "Debug Token: ${appCheckDiagnostics.debugTokenPreview}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = onVerifyAppCheck,
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("verify_appcheck_button")
                            ) {
                                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Verify App Check")
                            }
                            if (appCheckDiagnostics.fullDebugSecret.isNotBlank()) {
                                OutlinedButton(
                                    onClick = {
                                        CloudyIntegrationsEngine.copyToClipboard(context, "App Check Secret", appCheckDiagnostics.fullDebugSecret)
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("copy_debug_secret_button")
                                ) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy Secret")
                                }
                            }
                            OutlinedButton(
                                onClick = { showManualTokenEntry = !showManualTokenEntry },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text(if (showManualTokenEntry) "Hide" else "Manual Debug Token")
                            }
                        }

                        if (showManualTokenEntry) {
                            OutlinedTextField(
                                value = manualAppCheckToken,
                                onValueChange = { manualAppCheckToken = it },
                                label = { Text("Firebase Console Debug Secret (UUID)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("manual_appcheck_token_input")
                            )
                            Button(
                                onClick = {
                                    onApplyManualAppCheckToken(manualAppCheckToken)
                                    showManualTokenEntry = false
                                },
                                enabled = manualAppCheckToken.isNotBlank(),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Apply Token")
                            }
                        }
                    }
                }
            }

            // SECTION 8: Data Management
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("8. Data Management", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onExportWorkspaceData,
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("export_workspace_button")
                            ) {
                                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export Workspace JSON")
                            }
                            OutlinedButton(
                                onClick = onClearGeneratedImages,
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear Studio Gallery")
                            }
                            OutlinedButton(
                                onClick = { confirmDeleteThreads = true },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = RoseError, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear Conversations", color = RoseError)
                            }
                            OutlinedButton(
                                onClick = { confirmResetKeys = true },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.Key, contentDescription = null, tint = RoseError, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Reset Local BYOK Keys", color = RoseError)
                            }
                        }
                    }
                }
            }

            // SECTION 9: Haptics & Streaming
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("9. Interaction & Streaming", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Haptic Feedback", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = config.hapticsEnabled,
                                onCheckedChange = {
                                    onUpdatePersonalization(config.autoRouteEnabled, config.responseStyle, customInstructionsDraft, it, config.streamAnimationEnabled)
                                }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Smooth Streaming Reveal", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = config.streamAnimationEnabled,
                                onCheckedChange = {
                                    onUpdatePersonalization(config.autoRouteEnabled, config.responseStyle, customInstructionsDraft, config.hapticsEnabled, it)
                                }
                            )
                        }
                    }
                }
            }

            // SECTION 10: About Cloudy & Security Audit Logs
            item {
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = cloudyStyle.glassAlpha),
                    border = BorderStroke(1.dp, cloudyStyle.borderBrush)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CloudyMinimalCloudMark(
                                strokeColor = MaterialTheme.colorScheme.onSurface,
                                containerColor = MaterialTheme.colorScheme.surface,
                                strokeWidthDp = 2.4f,
                                modifier = Modifier.size(40.dp)
                            )
                            Column {
                                Text("10. About Cloudy v2.0", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Multimodal AI Platform • Real-Time Bidirectional Voice • Multi-Provider Router • Zero-Key Firebase AI Logic + Local BYOK",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Audit Logs
            item {
                Row(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Audit Logs (${auditLogs.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    }
                    OutlinedButton(onClick = onClearLogs, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear")
                    }
                }
            }

            items(auditLogs.take(20), key = { "log_${it.id}_${it.timestampMs}" }) { log ->
                Surface(
                    modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth(),
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = "[${log.severity}] ${log.component}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = if (log.severity == LogSeverity.ERROR) RoseError else MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = timeFormatter.format(Date(log.timestampMs)),
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily
                            )
                        }
                        Text(log.message, style = MaterialTheme.typography.bodySmall, fontFamily = JetBrainsMonoFontFamily)
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeOptionCard(
    title: String,
    tier: String,
    subtitle: String,
    previewColors: List<Color>,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    isCrystalPro: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val bgSwatch = previewColors.getOrElse(0) { Color(0xFFF6F9FC) }
    val surfaceSwatch = previewColors.getOrElse(1) { Color.White }
    val accentSwatch = previewColors.getOrElse(2) { Color(0xFF0284C7) }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = bgSwatch,
                    border = BorderStroke(1.dp, accentSwatch.copy(alpha = 0.5f)),
                    modifier = Modifier.size(width = 50.dp, height = 42.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(5.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(3.dp)).background(accentSwatch))
                        Box(modifier = Modifier.fillMaxWidth(0.75f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(surfaceSwatch))
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(accentSwatch))
                            Box(modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(surfaceSwatch.copy(alpha = 0.8f)))
                        }
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isCrystalPro) Color(0xFF0369A1) else EmeraldVerified.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = tier,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isCrystalPro) Color.White else EmeraldVerified,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (selected) {
                Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = EmeraldVerified, modifier = Modifier.size(22.dp))
            }
        }
    }
}
