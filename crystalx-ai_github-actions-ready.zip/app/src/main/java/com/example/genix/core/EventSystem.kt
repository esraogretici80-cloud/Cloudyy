package com.example.genix.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class EventSystem(
    private val maxInMemoryEvents: Int = 200,
    private val onPersistEvent: (suspend (GenixEventLog) -> Unit)? = null
) {
    private val _events = MutableStateFlow<List<GenixEventLog>>(emptyList())
    val events: StateFlow<List<GenixEventLog>> = _events.asStateFlow()

    suspend fun log(
        component: String,
        severity: LogSeverity,
        message: String,
        metadataJson: String = "{}"
    ) {
        val entry = GenixEventLog(
            component = component,
            severity = severity,
            message = message,
            metadataJson = metadataJson
        )
        _events.update { current ->
            (listOf(entry) + current).take(maxInMemoryEvents)
        }
        onPersistEvent?.invoke(entry)
    }

    fun logSync(
        component: String,
        severity: LogSeverity,
        message: String,
        metadataJson: String = "{}"
    ) {
        val entry = GenixEventLog(
            component = component,
            severity = severity,
            message = message,
            metadataJson = metadataJson
        )
        _events.update { current ->
            (listOf(entry) + current).take(maxInMemoryEvents)
        }
    }

    fun seedLogs(initialLogs: List<GenixEventLog>) {
        if (_events.value.isEmpty() && initialLogs.isNotEmpty()) {
            _events.value = initialLogs.take(maxInMemoryEvents)
        }
    }

    fun clearInMemory() {
        _events.value = emptyList()
    }
}
