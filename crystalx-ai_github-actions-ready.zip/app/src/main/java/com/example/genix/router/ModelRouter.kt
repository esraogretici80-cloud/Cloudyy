package com.example.genix.router

import com.example.genix.core.EngineCategory
import com.example.genix.core.ExecutionMode
import com.example.genix.core.RequestCategory
import com.example.genix.core.RoutingCandidateScore
import com.example.genix.core.RoutingDecision
import com.example.genix.intelligence.coding.CodingEngine
import com.example.genix.intelligence.planning.PlanningEngine
import com.example.genix.intelligence.reasoning.ReasoningEngine
import com.example.genix.models.ModelLoadState
import com.example.genix.models.RegisteredModel
import com.example.genix.training.GenixTokenizer
import java.util.Locale

/**
 * GENIX Model Router (Section 7):
 * Evaluates request category, required capabilities, context window, loaded state,
 * memory footprint, and benchmark scores instead of blindly selecting the largest model.
 */
class ModelRouter(
    private val reasoningEngine: ReasoningEngine,
    private val codingEngine: CodingEngine,
    private val planningEngine: PlanningEngine,
    private val tokenizer: GenixTokenizer
) {

    fun classifyRequest(prompt: String): RequestCategory {
        val lower = prompt.lowercase(Locale.ROOT)
        return when {
            Regex("\\b(search memory|knowledge|recall|ara|bellek|belge|döküman)\\b").containsMatchIn(lower) ->
                RequestCategory.EMBEDDING_SEARCH
            codingEngine.isCodingRequest(prompt) ->
                RequestCategory.CODING
            reasoningEngine.isMathematicalOrLogical(prompt) ->
                RequestCategory.REASONING_MATH
            planningEngine.isPlanningRequest(prompt) ->
                RequestCategory.PLANNING
            else ->
                RequestCategory.CONVERSATION
        }
    }

    fun route(
        prompt: String,
        languageCode: String,
        availableModels: List<RegisteredModel>,
        executionMode: ExecutionMode,
        maxContextBudget: Int = 4096
    ): RoutingDecision {
        val category = classifyRequest(prompt)
        val estimatedTokens = tokenizer.encode(prompt).size

        val targetEngine = when (category) {
            RequestCategory.CONVERSATION -> EngineCategory.LANGUAGE
            RequestCategory.REASONING_MATH -> EngineCategory.REASONING
            RequestCategory.CODING -> EngineCategory.CODING
            RequestCategory.PLANNING -> EngineCategory.PLANNING
            RequestCategory.EMBEDDING_SEARCH -> EngineCategory.EMBEDDING
            RequestCategory.UNSUPPORTED -> EngineCategory.LANGUAGE
        }

        val candidates = availableModels.map { reg ->
            val meta = reg.metadata
            var score = 0.0
            val reasons = mutableListOf<String>()

            // 1. Category alignment
            val desiredCategory = if (targetEngine == EngineCategory.PLANNING) EngineCategory.LANGUAGE else targetEngine
            if (meta.category == desiredCategory) {
                score += 40.0
                reasons.add("category-match")
            } else {
                score += 5.0
            }

            // 2. Language support
            if (meta.supportedLanguages.contains(languageCode) ||
                meta.supportedLanguages.contains("unicode") ||
                meta.supportedLanguages.contains("math")
            ) {
                score += 15.0
                reasons.add("lang-ok")
            }

            // 3. Context fit
            if (estimatedTokens <= meta.contextLimit && estimatedTokens <= maxContextBudget) {
                score += 10.0
            } else {
                score -= 50.0
                reasons.add("context-overflow")
            }

            // 4. Hardware / Availability penalty or boost
            if (!meta.artifactVerified) {
                score -= 100.0
                reasons.add("unverified-blocked")
            } else if (meta.requiresRemoteCompute && executionMode == ExecutionMode.LOCAL_CPU_FOUNDATION) {
                score -= 60.0
                reasons.add("remote-gpu-unavailable-in-cpu-mode")
            } else if (reg.loadState == ModelLoadState.READY) {
                score += 20.0
                reasons.add("loaded")
            } else {
                score -= 15.0
                reasons.add("unloaded")
            }

            // 5. Execution locality & efficiency bonus: in LOCAL_CPU_FOUNDATION mode, prefer deterministic local genix-* engines over cloud models
            if (executionMode == ExecutionMode.LOCAL_CPU_FOUNDATION) {
                if (meta.id.startsWith("genix-")) {
                    score += 8.0
                    reasons.add("cpu-native")
                } else if (meta.id.startsWith("cloudy-")) {
                    score -= 8.0
                    reasons.add("requires-cloud-ai")
                }
            }
            val memoryEfficiencyBonus = (10.0 - (meta.estimatedMemoryMb / 1000.0)).coerceIn(0.0, 10.0)
            score += memoryEfficiencyBonus + (meta.benchmarkScore * 15.0)
            if (meta.estimatedMemoryMb < 200) reasons.add("low-mem")

            RoutingCandidateScore(
                modelId = meta.id,
                modelName = meta.displayName,
                score = String.format(Locale.US, "%.1f", score).toDouble(),
                reason = reasons.joinToString(", "),
                selected = false
            )
        }.sortedByDescending { it.score }

        val best = candidates.firstOrNull()
        val finalCandidates = candidates.mapIndexed { idx, c -> c.copy(selected = idx == 0) }

        val isOpenEndedConversation = category == RequestCategory.CONVERSATION &&
            !isGreetingOrCapabilityQuestion(prompt) &&
            executionMode == ExecutionMode.LOCAL_CPU_FOUNDATION

        val policySummary = if (executionMode == ExecutionMode.LOCAL_CPU_FOUNDATION) {
            "Cost/VRAM-aware policy selected '${best?.modelId}' (${best?.score} pts) on CPU-only foundation."
        } else {
            "Hybrid Control Plane routing selected '${best?.modelId}' (${best?.score} pts)."
        }

        return RoutingDecision(
            requestCategory = category,
            selectedEngine = targetEngine,
            selectedModelId = best?.modelId ?: "genix-core-lang-cpu-v1",
            selectedModelName = best?.modelName ?: "GENIX Foundation Language Core",
            estimatedContextTokens = estimatedTokens,
            policySummary = policySummary,
            candidates = finalCandidates,
            capabilitySupported = !isOpenEndedConversation,
            limitationReason = if (isOpenEndedConversation) {
                "Open-ended generative LLM inference is not active on CPU-only Phase 1; switch to Remote FastAPI Compute Plane or use verified math, static code audit, planning, or knowledge search."
            } else null
        )
    }

    fun isGreetingOrCapabilityQuestion(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        val greetingPatterns = listOf(
            "merhaba", "selam", "nasılsın", "nasilsin", "kimsin", "ne yapabilirsin",
            "hello", "hi", "hey", "how are you", "who are you", "what can you do",
            "hallo", "wie geht", "bonjour", "salut", "comment", "hola", "como estas", "cómo estás",
            "مرحبا", "こんにちは", "你好"
        )
        return greetingPatterns.any { lower.contains(it) } || lower.length <= 24 && !lower.contains("?")
    }
}
