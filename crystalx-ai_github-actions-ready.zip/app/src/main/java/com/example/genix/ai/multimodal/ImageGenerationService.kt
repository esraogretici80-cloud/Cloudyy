package com.example.genix.ai.multimodal

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.example.genix.firebase.AppCheckCoordinator
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.AspectRatio
import com.google.firebase.ai.type.ImageConfig
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ImageSize
import com.google.firebase.ai.type.InlineDataPart
import com.google.firebase.ai.type.QuotaExceededException
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.FileOutputStream

private const val TAG = "ImageGenService"

enum class CloudyImageModelOption(
    val modelId: String,
    val displayName: String,
    val description: String
) {
    NANO_BANANA_2_1(
        modelId = "gemini-nano-banana-2.1",
        displayName = "Nano Banana 2.1 (Fast)",
        description = "High-efficiency default image generator & editor."
    ),
    GEMINI_3_PRO_IMAGE(
        modelId = "gemini-3-pro-image",
        displayName = "Gemini 3 Pro Image (Studio)",
        description = "High-detail editorial, typography & product visuals."
    )
}

enum class ImageAspectOption(
    val id: String,
    val label: String,
    val aspectRatio: AspectRatio
) {
    SQUARE("1:1", "1:1", AspectRatio.SQUARE_1x1),
    LANDSCAPE("16:9", "16:9", AspectRatio.LANDSCAPE_16x9),
    PORTRAIT("9:16", "9:16", AspectRatio.PORTRAIT_9x16),
    FOUR_THREE("4:3", "4:3", AspectRatio.LANDSCAPE_4x3),
    THREE_FOUR("3:4", "3:4", AspectRatio.PORTRAIT_3x4)
}

data class GeneratedImageOutput(
    val bitmap: Bitmap,
    val localFilePath: String,
    val modelId: String,
    val aspectRatioLabel: String,
    val captionText: String,
    val latencyMs: Long
)

/**
 * Real Image Generation & Editing Service using Firebase AI Logic (`gemini-nano-banana-2.1` & `gemini-3-pro-image`).
 * No mock Canvas fallback is ever produced on error — failures surface cleanly to the UI.
 */
class ImageGenerationService(private val context: Context) {

    suspend fun generateOrEdit(
        prompt: String,
        modelOption: CloudyImageModelOption = CloudyImageModelOption.NANO_BANANA_2_1,
        aspectOption: ImageAspectOption = ImageAspectOption.SQUARE,
        referenceBitmap: Bitmap? = null
    ): Result<GeneratedImageOutput> = withContext(Dispatchers.IO) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Enter a prompt to generate an image."))
        }
        val startMs = System.currentTimeMillis()
        try {
            val config = generationConfig {
                responseModalities = listOf(ResponseModality.IMAGE, ResponseModality.TEXT)
                imageConfig = ImageConfig.builder()
                    .setAspectRatio(aspectOption.aspectRatio)
                    .setImageSize(ImageSize.SIZE_1K)
                    .build()
            }

            val model = Firebase.ai.generativeModel(
                modelName = modelOption.modelId,
                generationConfig = config
            )

            val response = withTimeout(60_000L) {
                if (referenceBitmap != null) {
                    model.generateContent(
                        content("user") {
                            image(referenceBitmap)
                            text(cleanPrompt)
                        }
                    )
                } else {
                    model.generateContent(cleanPrompt)
                }
            }

            val firstCandidate = response.candidates.firstOrNull()
            val imagePart = firstCandidate?.content?.parts?.filterIsInstance<ImagePart>()?.firstOrNull()
            val decodedBitmap = imagePart?.image ?: run {
                val inline = firstCandidate?.content?.parts?.filterIsInstance<InlineDataPart>()
                    ?.firstOrNull { it.mimeType.startsWith("image/") }
                inline?.inlineData?.let { bytes ->
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
            }

            if (decodedBitmap == null) {
                val modelMsg = response.text?.take(160)?.takeIf { it.isNotBlank() }
                    ?: "No image was returned by ${modelOption.displayName}."
                return@withContext Result.failure(IllegalStateException(modelMsg))
            }

            val savedPath = persistBitmapToFilesDir(decodedBitmap)
            val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            Result.success(
                GeneratedImageOutput(
                    bitmap = decodedBitmap,
                    localFilePath = savedPath,
                    modelId = modelOption.modelId,
                    aspectRatioLabel = aspectOption.label,
                    captionText = response.text.orEmpty().trim(),
                    latencyMs = elapsed
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Image generation timed out", e)
            Result.failure(IllegalStateException("Image generation timed out after 60 seconds."))
        } catch (e: QuotaExceededException) {
            Log.e(TAG, "Image generation quota exceeded", e)
            Result.failure(IllegalStateException("Rate limit or Blaze quota exceeded. Please try again shortly."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image generation failed", e)
            val msg = e.localizedMessage ?: "Image generation failed."
            if (msg.contains("403") || msg.lowercase().contains("app check")) {
                AppCheckCoordinator.recordAttestationFailure("Image Studio App Check error (403)")
            }
            Result.failure(IllegalStateException(msg))
        }
    }

    suspend fun exportToDeviceGallery(bitmap: Bitmap, title: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val safeName = "Cloudy_${System.currentTimeMillis()}_${title.take(18).replace(Regex("[^A-Za-z0-9]"), "_")}.png"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Cloudy")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create MediaStore entry")

            resolver.openOutputStream(uri)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            } ?: error("Could not open gallery output stream")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            "Saved to Pictures/Cloudy/$safeName"
        }
    }

    private fun persistBitmapToFilesDir(bitmap: Bitmap): String {
        val dir = File(context.filesDir, "generated_images").apply { if (!exists()) mkdirs() }
        val file = File(dir, "cloudy_img_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        return file.absolutePath
    }
}
