package com.example.genix.intelligence.coding

import com.example.genix.core.VerificationStatus
import java.util.Locale

data class CodeAnalysisReport(
    val detectedLanguage: String,
    val lineCount: Int,
    val functionCount: Int,
    val classCount: Int,
    val delimitersBalanced: Boolean,
    val delimiterIssue: String?,
    val securityFindings: List<String>,
    val suggestions: List<String>,
    val verificationStatus: VerificationStatus
)

/**
 * GENIX Coding Engine:
 * Supports static analysis across Python, Kotlin, Java, C, C++, C#, JavaScript, TypeScript,
 * HTML, CSS, and SQL. Never executes untrusted code on the API/host process.
 */
class CodingEngine {

    val supportedLanguages = listOf(
        "Python", "Kotlin", "Java", "C", "C++", "C#",
        "JavaScript", "TypeScript", "HTML", "CSS", "SQL"
    )

    fun isCodingRequest(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT)
        if (prompt.contains("```")) return true
        val codeKeywords = listOf(
            "def ", "fun ", "class ", "import ", "select ", "from ", "where ",
            "function ", "const ", "let ", "public static", "#include", "<html",
            "refactor", "debug", "code review", "kod analiz", "kod incele", "hata ayıkla"
        )
        return codeKeywords.any { lower.contains(it) }
    }

    fun analyzeCode(codeOrPrompt: String, langCode: String): CodeAnalysisReport {
        val code = extractCodeBlock(codeOrPrompt)
        val progLang = detectProgrammingLanguage(code)
        val lines = code.lines()
        val functionCount = Regex("\\b(def|fun|function|fn|void|int|public|private)\\s+[A-Za-z_][A-Za-z0-9_]*\\s*\\(")
            .findAll(code).count()
        val classCount = Regex("\\b(class|interface|struct|object|enum)\\s+[A-Za-z_][A-Za-z0-9_]*")
            .findAll(code).count()

        val delimiterError = checkDelimiterBalance(code)
        val securityFindings = findSecurityRisks(code)
        val suggestions = buildSuggestions(code, progLang, delimiterError, securityFindings, langCode)

        return CodeAnalysisReport(
            detectedLanguage = progLang,
            lineCount = lines.size,
            functionCount = functionCount,
            classCount = classCount,
            delimitersBalanced = delimiterError == null,
            delimiterIssue = delimiterError,
            securityFindings = securityFindings,
            suggestions = suggestions,
            verificationStatus = VerificationStatus.STATIC_ANALYSIS_VERIFIED
        )
    }

    fun formatReportForConsole(report: CodeAnalysisReport, langCode: String): String {
        val header = when (langCode) {
            "tr" -> "Statik Kod Analizi Raporu (${report.detectedLanguage})"
            "de" -> "Statischer Code-Analysebericht (${report.detectedLanguage})"
            "fr" -> "Rapport d'analyse statique (${report.detectedLanguage})"
            "es" -> "Informe de análisis estático (${report.detectedLanguage})"
            else -> "Static Code Analysis Report (${report.detectedLanguage})"
        }
        val metrics = when (langCode) {
            "tr" -> "Satır: ${report.lineCount} | Fonksiyon: ${report.functionCount} | Sınıf/Yapı: ${report.classCount} | Parantez Dengesi: ${if (report.delimitersBalanced) "GEÇTİ" else "HATA"}"
            else -> "Lines: ${report.lineCount} | Functions: ${report.functionCount} | Classes/Types: ${report.classCount} | Delimiters: ${if (report.delimitersBalanced) "BALANCED" else "MISMATCH"}"
        }
        val delimiterLine = report.delimiterIssue?.let { "\n• Delimiter Issue: $it" } ?: ""
        val secBlock = if (report.securityFindings.isEmpty()) {
            if (langCode == "tr") "\n• Güvenlik Taraması: Bilinen tehlikeli çağrı tespit edilmedi."
            else "\n• Security Audit: No high-risk dynamic execution patterns detected."
        } else {
            "\n• Security Findings:\n  - " + report.securityFindings.joinToString("\n  - ")
        }
        val recBlock = if (report.suggestions.isNotEmpty()) {
            "\n• Recommendations:\n  - " + report.suggestions.joinToString("\n  - ")
        } else ""
        val sandboxNote = if (langCode == "tr") {
            "\n\n[Korumalı Alan Politikası] Üretilen veya gönderilen kod asla API sunucusu/ana süreç içinde doğrudan çalıştırılmaz."
        } else {
            "\n\n[Sandbox Policy] Arbitrary code is never executed inside the host process; execution requires an isolated container sandbox."
        }
        return "$header\n$metrics$delimiterLine$secBlock$recBlock$sandboxNote"
    }

    private fun extractCodeBlock(input: String): String {
        val fenced = Regex("```[a-zA-Z0-9+#]*\\n([\\s\\S]*?)```").find(input)
        return fenced?.groupValues?.getOrNull(1)?.trim() ?: input.trim()
    }

    fun detectProgrammingLanguage(code: String): String {
        val lower = code.lowercase(Locale.ROOT)
        return when {
            lower.contains("fun ") && (lower.contains("val ") || lower.contains("var ") || lower.contains("data class")) -> "Kotlin"
            lower.contains("def ") && (lower.contains(":") || lower.contains("import ")) -> "Python"
            lower.contains("select ") && lower.contains("from ") -> "SQL"
            lower.contains("#include") && (lower.contains("std::") || lower.contains("iostream")) -> "C++"
            lower.contains("#include") -> "C"
            lower.contains("public static void main") || lower.contains("system.out.println") -> "Java"
            lower.contains("namespace ") && lower.contains("using system") -> "C#"
            lower.contains("interface ") && (lower.contains(": string") || lower.contains(": number")) -> "TypeScript"
            lower.contains("function ") || lower.contains("const ") || lower.contains("=>") -> "JavaScript"
            lower.contains("<html") || lower.contains("<div") -> "HTML"
            lower.contains("{") && (lower.contains("color:") || lower.contains("display:")) -> "CSS"
            else -> "General / Multi-language"
        }
    }

    private fun checkDelimiterBalance(code: String): String? {
        val stack = ArrayDeque<Pair<Char, Int>>()
        var inSingleQuote = false
        var inDoubleQuote = false
        var escaped = false
        var line = 1

        for (ch in code) {
            if (ch == '\n') line++
            if (escaped) {
                escaped = false
                continue
            }
            if (ch == '\\') {
                escaped = true
                continue
            }
            if (ch == '\'' && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote
                continue
            }
            if (ch == '"' && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote
                continue
            }
            if (inSingleQuote || inDoubleQuote) continue

            when (ch) {
                '(', '[', '{' -> stack.addLast(ch to line)
                ')', ']', '}' -> {
                    if (stack.isEmpty()) return "Unexpected closing '$ch' at line $line"
                    val (open, openLine) = stack.removeLast()
                    val matches = (open == '(' && ch == ')') ||
                        (open == '[' && ch == ']') ||
                        (open == '{' && ch == '}')
                    if (!matches) return "Mismatched '$open' (line $openLine) with '$ch' (line $line)"
                }
            }
        }
        if (inSingleQuote || inDoubleQuote) return "Unterminated string literal"
        if (stack.isNotEmpty()) {
            val (open, openLine) = stack.last()
            return "Unclosed '$open' opened at line $openLine"
        }
        return null
    }

    private fun findSecurityRisks(code: String): List<String> {
        val findings = mutableListOf<String>()
        if (Regex("\\b(eval|exec)\\s*\\(").containsMatchIn(code)) {
            findings.add("Dynamic code execution call (`eval`/`exec`) detected — prohibit on untrusted input.")
        }
        if (Regex("\\b(os\\.system|subprocess\\.(Popen|run|call))\\b").containsMatchIn(code) &&
            code.contains("shell=True")
        ) {
            findings.add("Subprocess with `shell=True` detected — vulnerable to command injection.")
        }
        if (Regex("(SELECT|INSERT|UPDATE|DELETE).*\\+.*|f[\"']SELECT ", RegexOption.IGNORE_CASE).containsMatchIn(code)) {
            findings.add("Possible raw SQL string interpolation detected — use parameterized queries.")
        }
        if (Regex("(api_key|secret|password)\\s*=\\s*[\"'][^\"']{6,}[\"']", RegexOption.IGNORE_CASE).containsMatchIn(code)) {
            findings.add("Potential hardcoded credential/secret literal detected — move to environment secrets.")
        }
        return findings
    }

    private fun buildSuggestions(
        code: String,
        progLang: String,
        delimiterError: String?,
        securityFindings: List<String>,
        langCode: String
    ): List<String> {
        val list = mutableListOf<String>()
        if (delimiterError != null) {
            list.add(if (langCode == "tr") "Parantez/tırnak uyumsuzluğunu giderin: $delimiterError" else "Fix syntax delimiter balance: $delimiterError")
        }
        if (securityFindings.isNotEmpty()) {
            list.add(if (langCode == "tr") "Güvenlik bulgularını yalıtılmış test ortamından önce düzeltin." else "Resolve flagged security patterns before sandboxed execution.")
        }
        if (code.lines().size > 40 && !code.contains("fun ") && !code.contains("def ")) {
            list.add(if (langCode == "tr") "Uzun kod bloğunu modüler fonksiyonlara bölün." else "Refactor monolithic block into smaller testable functions.")
        }
        if (list.isEmpty()) {
            list.add(
                if (langCode == "tr") "$progLang sözdizimi dengeli görünüyor; birim testleriyle doğrulama önerilir."
                else "$progLang delimiter structure is valid; add unit tests for boundary cases."
            )
        }
        return list
    }
}
