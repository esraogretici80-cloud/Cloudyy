package com.example.genix.intelligence.language

import com.example.genix.core.LanguageDetectionResult
import java.util.Locale

data class SupportedLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String
)

data class CountrySupport(
    val countryCode: String,
    val countryName: String,
    val flagEmoji: String,
    val defaultLanguageCode: String,
    val currencyCode: String,
    val localeTag: String
)

data class LocalizedUiStrings(
    val appTitle: String,
    val subtitle: String,
    val navCore: String,
    val navModels: String,
    val navLab: String,
    val navSystem: String,
    val promptHint: String,
    val sendLabel: String,
    val statusHealthy: String,
    val cpuFoundationLabel: String,
    val remotePlaneLabel: String,
    val emptyConsoleTitle: String,
    val emptyConsoleBody: String,
    val activeLangLabel: String,
    val clearSessionLabel: String
)

data class AuthUiStrings(
    val heroSubtitle: String,
    val workspaceTitle: String,
    val workspaceDescription: String,
    val googleButton: String,
    val googleConnecting: String,
    val orProviders: String,
    val isolationActive: String,
    val oauthConfigNote: String,
    val languageLabel: String
)

data class HomeUiStrings(
    val greetingTitle: String,
    val greetingSubtitle: String,
    val newChatLabel: String,
    val historyLabel: String,
    val searchHistoryHint: String,
    val selectModelLabel: String,
    val liveVoiceShortcut: String,
    val imageGenShortcut: String,
    val attachDocShortcut: String,
    val attachPhotoShortcut: String,
    val webSearchLabel: String,
    val codingModeLabel: String,
    val stopGeneratingLabel: String,
    val regenerateLabel: String,
    val continueLabel: String,
    val editLabel: String,
    val copyLabel: String,
    val autoRouteLabel: String
)

data class LiveUiStrings(
    val title: String,
    val idleHint: String,
    val connectingLabel: String,
    val listeningLabel: String,
    val processingLabel: String,
    val speakingLabel: String,
    val interruptedLabel: String,
    val reconnectingLabel: String,
    val errorLabel: String,
    val muteLabel: String,
    val unmuteLabel: String,
    val interruptLabel: String,
    val endCallLabel: String,
    val startCallLabel: String,
    val transcriptTitle: String,
    val noTranscriptHint: String,
    val permissionRequired: String,
    val grantMicButton: String
)

/**
 * Cloudy AI Multilingual, Country & Device System Locale Engine.
 * Supports "system" (OS Locale), "auto" (Input detection), and 18+ countries & languages.
 */
object MultilingualLanguageSystem {

    val supportedLanguages = listOf(
        SupportedLanguage("system", "System OS / Sistem Dili", "Device System Language"),
        SupportedLanguage("auto", "Auto-Detect", "Automatic Input Detection"),
        SupportedLanguage("en", "English", "English"),
        SupportedLanguage("tr", "Türkçe", "Turkish"),
        SupportedLanguage("de", "Deutsch", "German"),
        SupportedLanguage("fr", "Français", "French"),
        SupportedLanguage("es", "Español", "Spanish"),
        SupportedLanguage("it", "Italiano", "Italian"),
        SupportedLanguage("pt", "Português", "Portuguese"),
        SupportedLanguage("nl", "Nederlands", "Dutch"),
        SupportedLanguage("pl", "Polski", "Polish"),
        SupportedLanguage("az", "Azərbaycan", "Azerbaijani"),
        SupportedLanguage("ru", "Русский", "Russian"),
        SupportedLanguage("ar", "العربية", "Arabic"),
        SupportedLanguage("hi", "हिन्दी", "Hindi"),
        SupportedLanguage("ja", "日本語", "Japanese"),
        SupportedLanguage("ko", "한국어", "Korean"),
        SupportedLanguage("zh", "中文", "Chinese"),
        SupportedLanguage("id", "Bahasa Indonesia", "Indonesian")
    )

    val supportedCountries = listOf(
        CountrySupport("US", "United States", "🇺🇸", "en", "USD", "en-US"),
        CountrySupport("GB", "United Kingdom", "🇬🇧", "en", "GBP", "en-GB"),
        CountrySupport("TR", "Türkiye", "🇹🇷", "tr", "TRY", "tr-TR"),
        CountrySupport("DE", "Deutschland", "🇩🇪", "de", "EUR", "de-DE"),
        CountrySupport("FR", "France", "🇫🇷", "fr", "EUR", "fr-FR"),
        CountrySupport("ES", "España", "🇪🇸", "es", "EUR", "es-ES"),
        CountrySupport("IT", "Italia", "🇮🇹", "it", "EUR", "it-IT"),
        CountrySupport("BR", "Brasil", "🇧🇷", "pt", "BRL", "pt-BR"),
        CountrySupport("NL", "Nederland", "🇳🇱", "nl", "EUR", "nl-NL"),
        CountrySupport("PL", "Polska", "🇵🇱", "pl", "PLN", "pl-PL"),
        CountrySupport("AZ", "Azərbaycan", "🇦🇿", "az", "AZN", "az-AZ"),
        CountrySupport("RU", "Россия", "🇷🇺", "ru", "RUB", "ru-RU"),
        CountrySupport("SA", "السعودية", "🇸🇦", "ar", "SAR", "ar-SA"),
        CountrySupport("AE", "UAE", "🇦🇪", "ar", "AED", "ar-AE"),
        CountrySupport("IN", "India", "🇮🇳", "hi", "INR", "hi-IN"),
        CountrySupport("JP", "日本", "🇯🇵", "ja", "JPY", "ja-JP"),
        CountrySupport("KR", "대한민국", "🇰🇷", "ko", "KRW", "ko-KR"),
        CountrySupport("CN", "中国", "🇨🇳", "zh", "CNY", "zh-CN"),
        CountrySupport("ID", "Indonesia", "🇮🇩", "id", "IDR", "id-ID")
    )

    fun resolveSystemLanguageCode(): String {
        val sysLang = Locale.getDefault().language.lowercase(Locale.ROOT)
        return if (supportedLanguages.any { it.code == sysLang && it.code !in setOf("auto", "system") }) {
            sysLang
        } else {
            "en"
        }
    }

    fun resolveDefaultCountryCode(): String {
        val sysCountry = Locale.getDefault().country.uppercase(Locale.ROOT)
        val matched = supportedCountries.firstOrNull { it.countryCode.equals(sysCountry, ignoreCase = true) }
        if (matched != null) return matched.countryCode
        return when (resolveSystemLanguageCode()) {
            "tr" -> "TR"
            "de" -> "DE"
            "fr" -> "FR"
            "es" -> "ES"
            "it" -> "IT"
            "pt" -> "BR"
            "ja" -> "JP"
            "ko" -> "KR"
            "zh" -> "CN"
            "ru" -> "RU"
            "ar" -> "SA"
            else -> "US"
        }
    }

    fun countryForCode(countryCode: String): CountrySupport =
        supportedCountries.firstOrNull { it.countryCode.equals(countryCode, ignoreCase = true) }
            ?: supportedCountries.first()

    fun resolveEffectiveLanguage(preferredCode: String, conversationLang: String): String =
        when (preferredCode) {
            "system" -> resolveSystemLanguageCode()
            "auto" -> conversationLang
            else -> preferredCode
        }

    private val technicalTerms = setOf(
        "fastapi", "pytorch", "kotlin", "compose", "docker", "pgvector", "postgresql",
        "redis", "transformers", "safetensors", "tokenizer", "bpe", "unigram", "lora",
        "vllm", "cuda", "gpu", "cpu", "json", "rest", "api", "http", "https", "oauth",
        "jwt", "sql", "python", "java", "typescript", "javascript", "html", "css",
        "cloudy", "genix", "router", "adapter", "embedding", "transformer", "github", "webhook"
    )

    private val turkishUniqueChars = setOf('ğ', 'Ğ', 'ş', 'Ş', 'ı', 'İ')
    private val turkishSharedChars = setOf('ç', 'Ç', 'ö', 'Ö', 'ü', 'Ü')
    private val azeriChars = setOf('ə', 'Ə')
    private val germanChars = setOf('ä', 'Ä', 'ö', 'Ö', 'ü', 'Ü', 'ß')
    private val spanishChars = setOf('ñ', 'Ñ', '¿', '¡', 'á', 'é', 'í', 'ó', 'ú')
    private val frenchChars = setOf('à', 'â', 'é', 'è', 'ê', 'ë', 'î', 'ï', 'ô', 'ù', 'û', 'ç', 'œ')
    private val polishChars = setOf('ą', 'ć', 'ę', 'ł', 'ń', 'ś', 'ź', 'ż')

    private val turkishWords = setOf(
        "merhaba", "selam", "nasılsın", "nasilsin", "nedir", "nasıl", "nasil", "ve", "bir",
        "bu", "için", "icin", "ile", "olarak", "ama", "fakat", "çünkü", "cunku", "evet",
        "hayır", "hayir", "lütfen", "lutfen", "teşekkür", "tesekkur", "yardım", "yardim",
        "türkçe", "turkce", "cevap", "ver", "neden", "kadar", "çok", "cok",
        "güzel", "guzel", "kod", "hesapla", "plan", "oluştur", "olustur", "analiz", "et",
        "mısın", "misin", "musun", "ben", "sen", "biz", "onlar", "var", "yok", "yap"
    )

    private val englishWords = setOf(
        "hello", "hi", "hey", "how", "are", "you", "what", "why", "when", "where",
        "the", "and", "is", "for", "with", "this", "that", "please", "help",
        "can", "could", "would", "create", "build", "analyze", "calculate", "explain",
        "code", "plan", "system", "model", "memory", "language", "response", "english"
    )

    private val germanWords = setOf(
        "hallo", "wie", "geht", "es", "dir", "ihnen", "guten", "tag", "morgen", "und",
        "der", "die", "das", "ein", "eine", "ist", "sind", "für", "fur", "mit", "bitte",
        "hilfe", "warum", "was", "kannst", "du", "deutsch", "erklären", "berechnen", "oder"
    )

    private val frenchWords = setOf(
        "bonjour", "salut", "comment", "allez", "vous", "vas", "tu", "merci", "oui", "non",
        "le", "la", "les", "un", "une", "des", "et", "est", "pour", "avec", "dans", "que",
        "qui", "quoi", "pourquoi", "français", "francais", "pouvez", "aide", "calculer"
    )

    private val spanishWords = setOf(
        "hola", "como", "cómo", "estas", "estás", "buenos", "dias", "días", "gracias",
        "por", "favor", "el", "la", "los", "las", "un", "una", "y", "es", "para", "con",
        "que", "qué", "porque", "español", "espanol", "ayuda", "explicar", "calcular"
    )

    private val italianWords = setOf(
        "ciao", "buongiorno", "come", "stai", "grazie", "per", "favore", "italiano", "sono", "una"
    )

    private val portugueseWords = setOf(
        "olá", "ola", "tudo", "bem", "obrigado", "obrigada", "como", "voce", "você", "português"
    )

    fun detectLanguage(
        input: String,
        fallbackLanguageCode: String = resolveSystemLanguageCode()
    ): LanguageDetectionResult {
        val trimmed = input.trim()
        val resolvedFallback = if (fallbackLanguageCode in setOf("auto", "system")) {
            resolveSystemLanguageCode()
        } else {
            fallbackLanguageCode
        }
        if (trimmed.isEmpty()) {
            return LanguageDetectionResult(
                primaryCode = resolvedFallback,
                primaryDisplayName = displayNameFor(resolvedFallback),
                confidence = 0.5f
            )
        }

        val explicitSwitch = detectExplicitSwitchCommand(trimmed)
        val preservedTerms = extractTechnicalTerms(trimmed)

        var arabicCount = 0
        var kanaCount = 0
        var hangulCount = 0
        var cyrillicCount = 0
        var devanagariCount = 0
        var cjkCount = 0
        var latinCount = 0

        for (ch in trimmed) {
            val code = ch.code
            when {
                code in 0x0600..0x06FF || code in 0x0750..0x077F -> arabicCount++
                code in 0x3040..0x309F || code in 0x30A0..0x30FF -> kanaCount++
                code in 0xAC00..0xD7A3 -> hangulCount++
                code in 0x0400..0x04FF -> cyrillicCount++
                code in 0x0900..0x097F -> devanagariCount++
                code in 0x4E00..0x9FFF || code in 0x3400..0x4DBF -> cjkCount++
                ch.isLetter() -> latinCount++
            }
        }

        if (arabicCount >= 2 && arabicCount >= latinCount / 2) {
            return LanguageDetectionResult("ar", displayNameFor("ar"), 0.96f, latinCount > 3, if (latinCount > 3) "en" else null, preservedTerms, explicitSwitch)
        }
        if (hangulCount >= 2) {
            return LanguageDetectionResult("ko", displayNameFor("ko"), 0.97f, latinCount > 3, if (latinCount > 3) "en" else null, preservedTerms, explicitSwitch)
        }
        if (kanaCount >= 1) {
            return LanguageDetectionResult("ja", displayNameFor("ja"), 0.97f, latinCount > 3, if (latinCount > 3) "en" else null, preservedTerms, explicitSwitch)
        }
        if (cyrillicCount >= 2) {
            return LanguageDetectionResult("ru", displayNameFor("ru"), 0.96f, latinCount > 3, if (latinCount > 3) "en" else null, preservedTerms, explicitSwitch)
        }
        if (devanagariCount >= 2) {
            return LanguageDetectionResult("hi", displayNameFor("hi"), 0.96f, latinCount > 3, if (latinCount > 3) "en" else null, preservedTerms, explicitSwitch)
        }
        if (cjkCount >= 2 && kanaCount == 0) {
            return LanguageDetectionResult("zh", displayNameFor("zh"), 0.94f, latinCount > 3, if (latinCount > 3) "en" else null, preservedTerms, explicitSwitch)
        }

        val tokens = trimmed.lowercase(Locale.ROOT)
            .split(Regex("[^\\p{L}0-9]+"))
            .filter { it.isNotBlank() }

        val nonTechTokens = tokens.filterNot { it in technicalTerms }

        val scores = mutableMapOf(
            "tr" to 0.0,
            "en" to 0.0,
            "de" to 0.0,
            "fr" to 0.0,
            "es" to 0.0,
            "it" to 0.0,
            "pt" to 0.0,
            "az" to 0.0,
            "pl" to 0.0
        )

        for (ch in trimmed) {
            if (ch in turkishUniqueChars) scores["tr"] = scores.getValue("tr") + 4.0
            if (ch in turkishSharedChars) scores["tr"] = scores.getValue("tr") + 1.2
            if (ch in azeriChars) scores["az"] = scores.getValue("az") + 5.0
            if (ch in germanChars) scores["de"] = scores.getValue("de") + 1.5
            if (ch == 'ß') scores["de"] = scores.getValue("de") + 4.5
            if (ch in frenchChars) scores["fr"] = scores.getValue("fr") + 1.3
            if (ch in spanishChars) scores["es"] = scores.getValue("es") + 2.0
            if (ch in polishChars) scores["pl"] = scores.getValue("pl") + 3.0
        }

        for (tok in nonTechTokens) {
            if (tok in turkishWords) scores["tr"] = scores.getValue("tr") + 2.5
            if (tok in englishWords) scores["en"] = scores.getValue("en") + 2.3
            if (tok in germanWords) scores["de"] = scores.getValue("de") + 2.5
            if (tok in frenchWords) scores["fr"] = scores.getValue("fr") + 2.5
            if (tok in spanishWords) scores["es"] = scores.getValue("es") + 2.5
            if (tok in italianWords) scores["it"] = scores.getValue("it") + 2.5
            if (tok in portugueseWords) scores["pt"] = scores.getValue("pt") + 2.5
        }

        if (nonTechTokens.any {
                it.endsWith("yorum") || it.endsWith("bilir") || it.endsWith("dır") ||
                    it.endsWith("dir") || it.endsWith("ler") || it.endsWith("lar") ||
                    it.endsWith("mısın") || it.endsWith("musun")
            }
        ) {
            scores["tr"] = scores.getValue("tr") + 1.8
        }

        val sorted = scores.entries.sortedByDescending { it.value }
        val top = sorted[0]
        val second = sorted[1]

        if (top.value <= 0.1) {
            return LanguageDetectionResult(
                primaryCode = resolvedFallback,
                primaryDisplayName = displayNameFor(resolvedFallback),
                confidence = 0.65f,
                preservedTechnicalTerms = preservedTerms,
                explicitSwitchTarget = explicitSwitch
            )
        }

        val totalPositive = sorted.sumOf { it.value }.coerceAtLeast(1.0)
        val confidence = (top.value / totalPositive).toFloat().coerceIn(0.52f, 0.99f)
        val isMixed = second.value >= 2.2 && (second.value / top.value) >= 0.45

        return LanguageDetectionResult(
            primaryCode = top.key,
            primaryDisplayName = displayNameFor(top.key),
            confidence = confidence,
            isMixedLanguage = isMixed,
            secondaryCode = if (isMixed) second.key else null,
            preservedTechnicalTerms = preservedTerms,
            explicitSwitchTarget = explicitSwitch
        )
    }

    fun detectExplicitSwitchCommand(input: String): String? {
        val lower = input.lowercase(Locale.ROOT)
        return when {
            Regex("(türkçe|turkce).*(cevap|yanıt|konuş|yaz|geç|gec)|in turkish|speak turkish").containsMatchIn(lower) -> "tr"
            Regex("(ingilizce|english).*(cevap|yanıt|respond|reply|speak|switch)|in english").containsMatchIn(lower) -> "en"
            Regex("(almanca|deutsch|german).*(cevap|respond|reply|sprechen|in german|auf deutsch)").containsMatchIn(lower) -> "de"
            Regex("(fransızca|français|francais|french).*(cevap|respond|reply|parler|en français|in french)").containsMatchIn(lower) -> "fr"
            Regex("(ispanyolca|español|espanol|spanish).*(cevap|respond|reply|en español|in spanish)").containsMatchIn(lower) -> "es"
            Regex("(arapça|arabic|العربية)").containsMatchIn(lower) && lower.contains("in ") -> "ar"
            Regex("(japonca|japanese|日本語)").containsMatchIn(lower) && lower.contains("in ") -> "ja"
            Regex("(çince|chinese|中文)").containsMatchIn(lower) && lower.contains("in ") -> "zh"
            else -> null
        }
    }

    fun extractTechnicalTerms(input: String): List<String> {
        val tokens = input.split(Regex("[^A-Za-z0-9_+#.-]+"))
            .map { it.trim('.', '-', ',', ':', ';') }
            .filter { it.isNotBlank() }
        return tokens.filter { it.lowercase(Locale.ROOT) in technicalTerms }.distinct()
    }

    fun displayNameFor(code: String): String =
        supportedLanguages.firstOrNull { it.code == code }?.nativeName ?: code.uppercase(Locale.ROOT)

    fun authStrings(langCode: String): AuthUiStrings = when (langCode) {
        "tr" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "Kişiye Özel Cloudy Alanı",
            workspaceDescription = "Her hesap kendine özel izole bulut veritabanı, abonelik planı (Free/Pro/Ultra), tema, sistem dili ve entegrasyonlara sahiptir.",
            googleButton = "Google ile Devam Et",
            googleConnecting = "Google ile bağlanılıyor...",
            orProviders = "veya OAuth ile Giriş",
            isolationActive = "Google Sign-In Aktif • Hesaba Özel İzolasyon",
            oauthConfigNote = "GitHub, X ve Facebook girişleri Firebase OAuthProvider kullanır; canlı kimlik doğrulama için sağlayıcı anahtarlarının Firebase Auth üzerinde etkin olması gerekir.",
            languageLabel = "Dil"
        )
        "de" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "Privater Cloudy-Arbeitsbereich",
            workspaceDescription = "Jedes Konto erhält eine isolierte Cloud-Datenbank, Abo-Pläne (Free/Pro/Ultra), Themen, Systemsprache und Integrationen.",
            googleButton = "Mit Google anmelden",
            googleConnecting = "Verbindung mit Google...",
            orProviders = "oder per OAuth anmelden",
            isolationActive = "Google Sign-In Aktiv • Strikte Konto-Isolation",
            oauthConfigNote = "GitHub, X und Facebook nutzen Firebase OAuthProvider und erfordern aktivierte Provider-Clients in Firebase Auth.",
            languageLabel = "Sprache"
        )
        "fr" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "Espace Cloudy Privé",
            workspaceDescription = "Chaque compte dispose de sa base cloud isolée, son abonnement (Free/Pro/Ultra), ses thèmes, sa langue et ses intégrations.",
            googleButton = "Continuer avec Google",
            googleConnecting = "Connexion à Google...",
            orProviders = "ou via OAuth",
            isolationActive = "Google Sign-In Actif • Isolation par Compte",
            oauthConfigNote = "GitHub, X et Facebook utilisent Firebase OAuthProvider et nécessitent l'activation des clients OAuth dans Firebase Auth.",
            languageLabel = "Langue"
        )
        "es" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "Espacio Privado Cloudy",
            workspaceDescription = "Cada cuenta incluye base en la nube aislada, planes (Free/Pro/Ultra), temas, idioma del sistema e integraciones.",
            googleButton = "Continuar con Google",
            googleConnecting = "Conectando con Google...",
            orProviders = "o con proveedores OAuth",
            isolationActive = "Google Sign-In Activo • Aislamiento por Usuario",
            oauthConfigNote = "GitHub, X y Facebook usan Firebase OAuthProvider; requieren tener sus credenciales OAuth activadas en Firebase Auth.",
            languageLabel = "Idioma"
        )
        "ar" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "مساحة Cloudy الخاصة بك",
            workspaceDescription = "يمتلك كل حساب قاعدة بيانات معزولة وخطط اشتراك وثيمات ولغة النظام وتكاملات خاصة به.",
            googleButton = "المتابعة باستخدام Google",
            googleConnecting = "جارٍ الاتصال بـ Google...",
            orProviders = "أو عبر مزودي OAuth",
            isolationActive = "Google Sign-In نشط • عزل كامل لكل حساب",
            oauthConfigNote = "تستخدم أزرار GitHub و X و Facebook مزود Firebase OAuthProvider وتتطلب تفعيلها في إعدادات Firebase Auth.",
            languageLabel = "اللغة"
        )
        "ja" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "パーソナル Cloudy ワークスペース",
            workspaceDescription = "アカウントごとに独立したクラウドDB、プラン（Free/Pro/Ultra）、テーマ、システム言語、連携が保存されます。",
            googleButton = "Google で続行",
            googleConnecting = "Google に接続中...",
            orProviders = "または OAuth でサインイン",
            isolationActive = "Google Sign-In 有効 • アカウント完全分離",
            oauthConfigNote = "GitHub・X・Facebook は Firebase OAuthProvider を使用し、Firebase Auth 側での有効化が必要です。",
            languageLabel = "言語"
        )
        "ko" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "개인 Cloudy 워크스페이스",
            workspaceDescription = "각 계정은 독립된 클라우드 DB, 구독 플랜(Free/Pro/Ultra), 테마, 시스템 언어 및 연동을 보유합니다.",
            googleButton = "Google로 계속하기",
            googleConnecting = "Google 연결 중...",
            orProviders = "또는 OAuth 로그인",
            isolationActive = "Google Sign-In 활성 • 계정별 데이터 격리",
            oauthConfigNote = "GitHub, X, Facebook 로그인은 Firebase OAuthProvider를 사용하며 Firebase Auth 설정이 필요합니다.",
            languageLabel = "언어"
        )
        "zh" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "专属 Cloudy 工作空间",
            workspaceDescription = "每个账户拥有独立隔离的云端数据库、订阅方案 (Free/Pro/Ultra)、主题与系统语言。",
            googleButton = "通过 Google 继续",
            googleConnecting = "正在连接 Google...",
            orProviders = "或使用 OAuth 登录",
            isolationActive = "Google Sign-In 已启用 • 账户严格隔离",
            oauthConfigNote = "GitHub、X 与 Facebook 使用 Firebase OAuthProvider，需在 Firebase Auth 中启用对应客户端。",
            languageLabel = "语言"
        )
        "ru" -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "Персональное пространство Cloudy",
            workspaceDescription = "Каждый аккаунт имеет изолированную облачную базу, тариф (Free/Pro/Ultra), темы, язык системы и интеграции.",
            googleButton = "Продолжить с Google",
            googleConnecting = "Подключение к Google...",
            orProviders = "или вход через OAuth",
            isolationActive = "Google Sign-In активен • Изоляция данных",
            oauthConfigNote = "GitHub, X и Facebook используют Firebase OAuthProvider и требуют настройки OAuth в Firebase Auth.",
            languageLabel = "Язык"
        )
        else -> AuthUiStrings(
            heroSubtitle = "2.0 Breeze • 1.1 Neo • 1.0 Pro • DeepThink Ultra • Voice Live",
            workspaceTitle = "Private Cloudy Workspace",
            workspaceDescription = "Every account has its own isolated cloud database, subscription tier (Free/Pro/Ultra), themes, system language, and integrations.",
            googleButton = "Continue with Google",
            googleConnecting = "Connecting to Google...",
            orProviders = "or Sign in with OAuth",
            isolationActive = "Google Sign-In Active • Strict Per-User Isolation",
            oauthConfigNote = "GitHub, X, and Facebook use Firebase OAuthProvider and require provider OAuth credentials enabled in Firebase Authentication.",
            languageLabel = "Language"
        )
    }

    fun buildConversationalGreeting(langCode: String, isMixed: Boolean, preservedTerms: List<String>): String {
        val termNote = if (preservedTerms.isNotEmpty()) {
            when (langCode) {
                "tr" -> "\nTeknik terimler korundu: ${preservedTerms.joinToString(", ")}"
                "de" -> "\nTechnische Begriffe beibehalten: ${preservedTerms.joinToString(", ")}"
                "fr" -> "\nTermes techniques conservés : ${preservedTerms.joinToString(", ")}"
                "es" -> "\nTérminos técnicos conservados: ${preservedTerms.joinToString(", ")}"
                else -> "\nPreserved technical terms: ${preservedTerms.joinToString(", ")}"
            }
        } else ""

        val mixedNote = if (isMixed) {
            when (langCode) {
                "tr" -> " (Çok dilli mesaj algılandı)"
                "de" -> " (Gemischtsprachige Eingabe erkannt)"
                "fr" -> " (Entrée multilingue détectée)"
                "es" -> " (Entrada multilingüe detectada)"
                else -> " (Mixed-language input detected)"
            }
        } else ""

        return when (langCode) {
            "tr" -> "Merhaba! Cloudy çekirdeği aktif.$mixedNote 2.0 Breeze, 1.1 Neo, 1.0 Pro ve Multi-AI modlarıyla yerel doğrulama birlikte çalışıyor.$termNote"
            "de" -> "Hallo! Die Cloudy Engine ist aktiv.$mixedNote 2.0 Breeze, 1.1 Neo, 1.0 Pro und Multi-AI arbeiten mit lokaler Verifikation.$termNote"
            "fr" -> "Bonjour ! Cloudy est actif.$mixedNote 2.0 Breeze, 1.1 Neo, 1.0 Pro et Multi-AI fonctionnent avec vérification locale.$termNote"
            "es" -> "¡Hola! Cloudy está activo.$mixedNote 2.0 Breeze, 1.1 Neo, 1.0 Pro y Multi-AI funcionan con verificación local.$termNote"
            "ar" -> "مرحباً! محرك Cloudy نشط مع نماذج 2.0 Breeze و 1.1 Neo و 1.0 Pro.$termNote"
            "ja" -> "こんにちは！Cloudy が稼働中です。2.0 Breeze・1.1 Neo・1.0 Pro が利用可能です。$termNote"
            "zh" -> "你好！Cloudy 引擎已启动，支持 2.0 Breeze、1.1 Neo、1.0 Pro 与 Multi-AI。$termNote"
            "ko" -> "안녕하세요! Cloudy가 활성화되었습니다. 2.0 Breeze, 1.1 Neo, 1.0 Pro 모델을 사용할 수 있습니다.$termNote"
            "ru" -> "Привет! Платформа Cloudy активна: 2.0 Breeze, 1.1 Neo, 1.0 Pro и Multi-AI готовы к работе.$termNote"
            else -> "Hello! Cloudy Studio is active.$mixedNote Powered by 2.0 Breeze, 1.1 Neo, 1.0 Pro, Multi-AI Ensemble & local verification.$termNote"
        }
    }

    fun buildUnsupportedNotice(langCode: String, reason: String): String {
        return when (langCode) {
            "tr" -> "Yerel Çevrimdışı Mod: Açık uçlu yanıtlar için 2.0 Breeze, 1.1 Neo, 1.0 Pro veya Multi-AI seçin. $reason"
            "de" -> "Lokaler CPU-Modus: Wählen Sie 2.0 Breeze, 1.1 Neo, 1.0 Pro oder Multi-AI für Cloud-KI. $reason"
            "fr" -> "Mode CPU local : Sélectionnez 2.0 Breeze, 1.1 Neo, 1.0 Pro ou Multi-AI pour l'IA cloud. $reason"
            "es" -> "Modo CPU local: Selecciona 2.0 Breeze, 1.1 Neo, 1.0 Pro o Multi-AI para IA en la nube. $reason"
            "ru" -> "Локальный режим CPU: выберите 2.0 Breeze, 1.1 Neo или 1.0 Pro для облачного ИИ. $reason"
            else -> "Offline Local CPU Mode: Select Cloudy 2.0 Breeze, 1.1 Neo, 1.0 Pro, or Multi-AI for cloud inference. $reason"
        }
    }

    fun uiStrings(langCode: String): LocalizedUiStrings {
        return when (langCode) {
            "tr" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Çoklu Yapay Zeka Stüdyosu",
                navCore = "Stüdyo",
                navModels = "Modeller",
                navLab = "Entegrasyon",
                navSystem = "Ayarlar",
                promptHint = "Cloudy'ya sor veya görsel/kod ekle...",
                sendLabel = "Gönder",
                statusHealthy = "HAZIR",
                cpuFoundationLabel = "Cloudy Multi-AI Stüdyo",
                remotePlaneLabel = "FastAPI Kontrol Düzlemi",
                emptyConsoleTitle = "Cloudy Stüdyo Hazır",
                emptyConsoleBody = "2.0 Breeze, 1.1 Neo, 1.0 Pro, DeepThink Ultra veya Voice Live seçin. Tüm sohbetler, planlar ve entegrasyonlar hesabınıza özel izole alanda saklanır.",
                activeLangLabel = "Etkin Dil",
                clearSessionLabel = "Yeni Sohbet"
            )
            "de" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Multi-KI Studio",
                navCore = "Studio",
                navModels = "Modelle",
                navLab = "Integrationen",
                navSystem = "Profil",
                promptHint = "Cloudy fragen oder Bild/Code anhängen...",
                sendLabel = "Senden",
                statusHealthy = "BEREIT",
                cpuFoundationLabel = "Cloudy Multi-AI Studio",
                remotePlaneLabel = "FastAPI Control Plane",
                emptyConsoleTitle = "Cloudy Studio Bereit",
                emptyConsoleBody = "Wählen Sie 2.0 Breeze, 1.1 Neo, 1.0 Pro oder DeepThink Ultra. Ihre Chats, Pläne und Integrationen sind privat pro Konto gespeichert.",
                activeLangLabel = "Aktive Sprache",
                clearSessionLabel = "Neuer Chat"
            )
            "fr" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Studio Multi-IA",
                navCore = "Studio",
                navModels = "Modèles",
                navLab = "Intégrations",
                navSystem = "Réglages",
                promptHint = "Demander à Cloudy ou joindre une image...",
                sendLabel = "Envoyer",
                statusHealthy = "ACTIF",
                cpuFoundationLabel = "Cloudy Multi-AI Studio",
                remotePlaneLabel = "Plan FastAPI",
                emptyConsoleTitle = "Cloudy Studio Prêt",
                emptyConsoleBody = "Sélectionnez 2.0 Breeze, 1.1 Neo, 1.0 Pro ou DeepThink Ultra. Votre espace et vos thèmes sont isolés par compte.",
                activeLangLabel = "Langue Active",
                clearSessionLabel = "Nouveau fil"
            )
            "es" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Estudio Multi-IA",
                navCore = "Estudio",
                navModels = "Modelos",
                navLab = "Integraciones",
                navSystem = "Ajustes",
                promptHint = "Pregunta a Cloudy o adjunta una imagen...",
                sendLabel = "Enviar",
                statusHealthy = "ACTIVO",
                cpuFoundationLabel = "Cloudy Multi-AI Estudio",
                remotePlaneLabel = "Plano FastAPI",
                emptyConsoleTitle = "Cloudy Estudio Listo",
                emptyConsoleBody = "Elige 2.0 Breeze, 1.1 Neo, 1.0 Pro o DeepThink Ultra. Tus hilos, planes e integraciones están aislados por usuario.",
                activeLangLabel = "Idioma Activo",
                clearSessionLabel = "Nuevo hilo"
            )
            "it" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Studio Multi-IA",
                navCore = "Studio",
                navModels = "Modelli",
                navLab = "Connetti",
                navSystem = "Impostazioni",
                promptHint = "Chiedi a Cloudy o allega un'immagine...",
                sendLabel = "Invia",
                statusHealthy = "PRONTO",
                cpuFoundationLabel = "Cloudy Multi-AI Studio",
                remotePlaneLabel = "Piano FastAPI",
                emptyConsoleTitle = "Cloudy Studio Pronto",
                emptyConsoleBody = "Scegli 2.0 Breeze, 1.1 Neo, 1.0 Pro o DeepThink Ultra. Tutti i dati sono isolati per account.",
                activeLangLabel = "Lingua Attiva",
                clearSessionLabel = "Nuova chat"
            )
            "pt" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Estúdio Multi-IA",
                navCore = "Estúdio",
                navModels = "Modelos",
                navLab = "Integrações",
                navSystem = "Ajustes",
                promptHint = "Pergunte ao Cloudy ou anexe uma imagem...",
                sendLabel = "Enviar",
                statusHealthy = "ATIVO",
                cpuFoundationLabel = "Cloudy Multi-AI Estúdio",
                remotePlaneLabel = "Controle FastAPI",
                emptyConsoleTitle = "Cloudy Estúdio Pronto",
                emptyConsoleBody = "Escolha 2.0 Breeze, 1.1 Neo, 1.0 Pro ou DeepThink Ultra. Suas conversas são privadas por conta.",
                activeLangLabel = "Idioma Ativo",
                clearSessionLabel = "Novo chat"
            )
            "az" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Çox-Modelli Süni İntellekt",
                navCore = "Studiya",
                navModels = "Modellər",
                navLab = "Bağlantı",
                navSystem = "Ayarlar",
                promptHint = "Cloudy-dan soruşun və ya şəkil əlavə edin...",
                sendLabel = "Göndər",
                statusHealthy = "HAZIR",
                cpuFoundationLabel = "Cloudy Multi-AI Studiya",
                remotePlaneLabel = "FastAPI İdarəetmə",
                emptyConsoleTitle = "Cloudy Studiya Hazırdır",
                emptyConsoleBody = "2.0 Breeze, 1.1 Neo, 1.0 Pro və ya DeepThink Ultra seçin. Bütün məlumatlar hesabınıza özəl qorunur.",
                activeLangLabel = "Aktiv Dil",
                clearSessionLabel = "Yeni Söhbət"
            )
            "ru" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Мульти-ИИ Студия",
                navCore = "Студия",
                navModels = "Модели",
                navLab = "Интеграции",
                navSystem = "Настройки",
                promptHint = "Спросите Cloudy или прикрепите фото...",
                sendLabel = "Отправить",
                statusHealthy = "ГОТОВ",
                cpuFoundationLabel = "Cloudy Multi-AI Студия",
                remotePlaneLabel = "FastAPI Панель",
                emptyConsoleTitle = "Cloudy Студия готова",
                emptyConsoleBody = "Выберите 2.0 Breeze, 1.1 Neo, 1.0 Pro или DeepThink Ultra. Ваши чаты и тарифы изолированы в вашем аккаунте.",
                activeLangLabel = "Язык",
                clearSessionLabel = "Новый чат"
            )
            "ar" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "استوديو الذكاء المتعدد",
                navCore = "الاستوديو",
                navModels = "النماذج",
                navLab = "التكامل",
                navSystem = "الإعدادات",
                promptHint = "اسأل Cloudy أو أرفق صورة...",
                sendLabel = "إرسال",
                statusHealthy = "جاهز",
                cpuFoundationLabel = "استوديو Cloudy Multi-AI",
                remotePlaneLabel = "تحكم FastAPI",
                emptyConsoleTitle = "استوديو Cloudy جاهز",
                emptyConsoleBody = "اختر 2.0 Breeze أو 1.1 Neo أو 1.0 Pro أو DeepThink Ultra. بياناتك وخطتك محمية لكل حساب.",
                activeLangLabel = "اللغة النشطة",
                clearSessionLabel = "محادثة جديدة"
            )
            "ja" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "マルチAIクラウドスタジオ",
                navCore = "スタジオ",
                navModels = "モデル",
                navLab = "連携",
                navSystem = "設定",
                promptHint = "Cloudy に質問、または画像を追加...",
                sendLabel = "送信",
                statusHealthy = "準備完了",
                cpuFoundationLabel = "Cloudy Multi-AI スタジオ",
                remotePlaneLabel = "FastAPI コントロール",
                emptyConsoleTitle = "Cloudy スタジオ準備完了",
                emptyConsoleBody = "2.0 Breeze、1.1 Neo、1.0 Pro、DeepThink Ultra を選択してください。会話とプランはアカウントごとに分離保存されます。",
                activeLangLabel = "言語",
                clearSessionLabel = "新規チャット"
            )
            "ko" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "멀티 AI 클라우드 스튜디오",
                navCore = "스튜디오",
                navModels = "모델",
                navLab = "연동",
                navSystem = "설정",
                promptHint = "Cloudy에게 질문하거나 이미지를 첨부하세요...",
                sendLabel = "전송",
                statusHealthy = "준비됨",
                cpuFoundationLabel = "Cloudy Multi-AI 스튜디오",
                remotePlaneLabel = "FastAPI 제어",
                emptyConsoleTitle = "Cloudy 스튜디오 준비 완료",
                emptyConsoleBody = "2.0 Breeze, 1.1 Neo, 1.0 Pro 또는 DeepThink Ultra를 선택하세요. 모든 대화와 플랜은 계정별로 안전하게 분리됩니다.",
                activeLangLabel = "활성 언어",
                clearSessionLabel = "새 채팅"
            )
            "zh" -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "多模型智能工作室",
                navCore = "工作室",
                navModels = "模型",
                navLab = "集成",
                navSystem = "设置",
                promptHint = "向 Cloudy 提问或附加图片...",
                sendLabel = "发送",
                statusHealthy = "就绪",
                cpuFoundationLabel = "Cloudy Multi-AI 工作室",
                remotePlaneLabel = "FastAPI 控制面",
                emptyConsoleTitle = "Cloudy 工作室已就绪",
                emptyConsoleBody = "选择 2.0 Breeze、1.1 Neo、1.0 Pro 或 DeepThink Ultra。您的对话、订阅与主题按账户独立隔离。",
                activeLangLabel = "当前语言",
                clearSessionLabel = "新对话"
            )
            else -> LocalizedUiStrings(
                appTitle = "Cloudy",
                subtitle = "Multi-AI Cloud Studio",
                navCore = "Studio",
                navModels = "Models",
                navLab = "Connect",
                navSystem = "Settings",
                promptHint = "Ask Cloudy anything...",
                sendLabel = "Send",
                statusHealthy = "ACTIVE",
                cpuFoundationLabel = "Cloudy Multi-AI Studio",
                remotePlaneLabel = "FastAPI Control Plane",
                emptyConsoleTitle = "Hello! I'm Cloudy.",
                emptyConsoleBody = "How can I help you today?",
                activeLangLabel = "Active Language",
                clearSessionLabel = "New Chat"
            )
        }
    }

    fun homeStrings(langCode: String): HomeUiStrings = when (langCode) {
        "tr" -> HomeUiStrings(
            greetingTitle = "Merhaba! Ben Cloudy.",
            greetingSubtitle = "Bugün sana nasıl yardımcı olabilirim?",
            newChatLabel = "Yeni Sohbet",
            historyLabel = "Geçmiş",
            searchHistoryHint = "Sohbetlerde ara...",
            selectModelLabel = "Model Seç",
            liveVoiceShortcut = "Cloudy Live",
            imageGenShortcut = "Görsel Üret",
            attachDocShortcut = "Dosya / PDF",
            attachPhotoShortcut = "Fotoğraf",
            webSearchLabel = "Web Arama",
            codingModeLabel = "Kod Modu",
            stopGeneratingLabel = "Durdur",
            regenerateLabel = "Yeniden Üret",
            continueLabel = "Devam Et",
            editLabel = "Düzenle",
            copyLabel = "Kopyala",
            autoRouteLabel = "Akıllı Yönlendirme"
        )
        "de" -> HomeUiStrings(
            greetingTitle = "Hallo! Ich bin Cloudy.",
            greetingSubtitle = "Wie kann ich dir heute helfen?",
            newChatLabel = "Neuer Chat",
            historyLabel = "Verlauf",
            searchHistoryHint = "Chats durchsuchen...",
            selectModelLabel = "Modell wählen",
            liveVoiceShortcut = "Cloudy Live",
            imageGenShortcut = "Bild erstellen",
            attachDocShortcut = "Dokument",
            attachPhotoShortcut = "Foto",
            webSearchLabel = "Websuche",
            codingModeLabel = "Code-Modus",
            stopGeneratingLabel = "Stopp",
            regenerateLabel = "Neu generieren",
            continueLabel = "Fortsetzen",
            editLabel = "Bearbeiten",
            copyLabel = "Kopieren",
            autoRouteLabel = "Auto-Routing"
        )
        "fr" -> HomeUiStrings(
            greetingTitle = "Bonjour ! Je suis Cloudy.",
            greetingSubtitle = "Comment puis-je vous aider aujourd'hui ?",
            newChatLabel = "Nouveau chat",
            historyLabel = "Historique",
            searchHistoryHint = "Rechercher...",
            selectModelLabel = "Choisir un modèle",
            liveVoiceShortcut = "Cloudy Live",
            imageGenShortcut = "Générer image",
            attachDocShortcut = "Document",
            attachPhotoShortcut = "Photo",
            webSearchLabel = "Recherche Web",
            codingModeLabel = "Mode Code",
            stopGeneratingLabel = "Arrêter",
            regenerateLabel = "Régénérer",
            continueLabel = "Continuer",
            editLabel = "Modifier",
            copyLabel = "Copier",
            autoRouteLabel = "Routage Auto"
        )
        "es" -> HomeUiStrings(
            greetingTitle = "¡Hola! Soy Cloudy.",
            greetingSubtitle = "¿Cómo puedo ayudarte hoy?",
            newChatLabel = "Nuevo chat",
            historyLabel = "Historial",
            searchHistoryHint = "Buscar chats...",
            selectModelLabel = "Elegir modelo",
            liveVoiceShortcut = "Cloudy Live",
            imageGenShortcut = "Crear imagen",
            attachDocShortcut = "Documento",
            attachPhotoShortcut = "Foto",
            webSearchLabel = "Búsqueda Web",
            codingModeLabel = "Modo Código",
            stopGeneratingLabel = "Detener",
            regenerateLabel = "Regenerar",
            continueLabel = "Continuar",
            editLabel = "Editar",
            copyLabel = "Copiar",
            autoRouteLabel = "Auto-Ruta"
        )
        else -> HomeUiStrings(
            greetingTitle = "Hello! I'm Cloudy.",
            greetingSubtitle = "How can I help you today?",
            newChatLabel = "New Chat",
            historyLabel = "History",
            searchHistoryHint = "Search conversations...",
            selectModelLabel = "Select Model",
            liveVoiceShortcut = "Cloudy Live",
            imageGenShortcut = "Generate Image",
            attachDocShortcut = "Upload File",
            attachPhotoShortcut = "Photo",
            webSearchLabel = "Web Search",
            codingModeLabel = "Code Mode",
            stopGeneratingLabel = "Stop",
            regenerateLabel = "Regenerate",
            continueLabel = "Continue",
            editLabel = "Edit",
            copyLabel = "Copy",
            autoRouteLabel = "Auto-Route"
        )
    }

    fun liveStrings(langCode: String): LiveUiStrings = when (langCode) {
        "tr" -> LiveUiStrings(
            title = "Cloudy Live",
            idleHint = "Gerçek zamanlı çift yönlü sesli konuşmayı başlatmak için dokunun.",
            connectingLabel = "Canlı ses oturumu kuruluyor...",
            listeningLabel = "Dinliyorum...",
            processingLabel = "Düşünüyor...",
            speakingLabel = "Konuşuyor (sözünü kesmek için konuşun)",
            interruptedLabel = "Söz kesildi — dinlemeye geçildi",
            reconnectingLabel = "Yeniden bağlanıyor...",
            errorLabel = "Bağlantı hatası",
            muteLabel = "Sessiz",
            unmuteLabel = "Sesi Aç",
            interruptLabel = "Durdur",
            endCallLabel = "Bitir",
            startCallLabel = "Canlı Sohbeti Başlat",
            transcriptTitle = "Canlı Döküm",
            noTranscriptHint = "Konuşmaya başladığınızda canlı döküm burada akacaktır.",
            permissionRequired = "Gerçek zamanlı sesli sohbet için mikrofon izni gerekir.",
            grantMicButton = "Mikrofon İzni Ver"
        )
        "de" -> LiveUiStrings(
            title = "Cloudy Live",
            idleHint = "Tippen Sie, um das Echtzeit-Sprachgespräch zu starten.",
            connectingLabel = "Verbindung wird hergestellt...",
            listeningLabel = "Ich höre zu...",
            processingLabel = "Denke nach...",
            speakingLabel = "Spricht...",
            interruptedLabel = "Unterbrochen — hört wieder zu",
            reconnectingLabel = "Verbindung wird wiederhergestellt...",
            errorLabel = "Verbindungsfehler",
            muteLabel = "Stumm",
            unmuteLabel = "Mikrofon an",
            interruptLabel = "Unterbrechen",
            endCallLabel = "Beenden",
            startCallLabel = "Live starten",
            transcriptTitle = "Live-Transkript",
            noTranscriptHint = "Gesprochene Sätze erscheinen hier in Echtzeit.",
            permissionRequired = "Für Echtzeit-Audio ist eine Mikrofonberechtigung erforderlich.",
            grantMicButton = "Mikrofon erlauben"
        )
        else -> LiveUiStrings(
            title = "Cloudy Live",
            idleHint = "Tap below to start a natural, real-time voice conversation.",
            connectingLabel = "Connecting live audio session...",
            listeningLabel = "Listening...",
            processingLabel = "Thinking...",
            speakingLabel = "Speaking (speak anytime to interrupt)",
            interruptedLabel = "Interrupted — listening to you",
            reconnectingLabel = "Reconnecting...",
            errorLabel = "Connection error",
            muteLabel = "Mute",
            unmuteLabel = "Unmute",
            interruptLabel = "Interrupt",
            endCallLabel = "End",
            startCallLabel = "Start Live Voice",
            transcriptTitle = "Live Transcript",
            noTranscriptHint = "Spoken turns will appear here in real time.",
            permissionRequired = "Microphone permission is required for real-time voice conversations.",
            grantMicButton = "Allow Microphone"
        )
    }
}
