package com.example.genix.models

import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

data class FastApiHealthResponse(
    val status: String = "unknown",
    val version: String? = null,
    val mode: String? = null,
    @Json(name = "loaded_models") val loadedModels: Int? = null
)

data class FastApiSystemStatusResponse(
    val status: String = "unknown",
    val phase: String? = null,
    @Json(name = "cpu_only") val cpuOnly: Boolean? = null,
    @Json(name = "active_models") val activeModels: List<String>? = null
)

data class FastApiChatRequest(
    val message: String,
    @Json(name = "preferred_language") val preferredLanguage: String? = null,
    @Json(name = "session_id") val sessionId: String = "android-client"
)

data class FastApiChatResponse(
    val reply: String? = null,
    val response: String? = null,
    @Json(name = "detected_language") val detectedLanguage: String? = null,
    @Json(name = "model_id") val modelId: String? = null,
    val verified: Boolean? = null
)

interface GenixFastApiService {
    @GET("api/v1/health")
    suspend fun getHealth(): Response<FastApiHealthResponse>

    @GET("api/v1/system/status")
    suspend fun getSystemStatus(): Response<FastApiSystemStatusResponse>

    @POST("api/v1/chat")
    suspend fun postChat(@Body request: FastApiChatRequest): Response<FastApiChatResponse>
}

data class RemoteProbeResult(
    val reachable: Boolean,
    val statusText: String,
    val latencyMs: Long,
    val details: String
)

/**
 * Real Retrofit/OkHttp client for an optional self-hosted GENIX FastAPI Control Plane.
 * Never fakes remote responses when unreachable.
 */
class RemoteFastApiAdapter {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private fun buildService(baseUrl: String): GenixFastApiService {
        val normalized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(normalized)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GenixFastApiService::class.java)
    }

    suspend fun probeHealth(baseUrl: String): RemoteProbeResult {
        val start = System.currentTimeMillis()
        if (!baseUrl.startsWith("http://") && !baseUrl.startsWith("https://")) {
            return RemoteProbeResult(
                reachable = false,
                statusText = "Invalid URL",
                latencyMs = 0L,
                details = "Control Plane URL must start with http:// or https://"
            )
        }
        return try {
            val service = buildService(baseUrl)
            val response = service.getHealth()
            val elapsed = System.currentTimeMillis() - start
            if (response.isSuccessful) {
                val body = response.body()
                RemoteProbeResult(
                    reachable = true,
                    statusText = body?.status?.uppercase() ?: "OK",
                    latencyMs = elapsed,
                    details = "Connected (${response.code()}) • mode=${body?.mode ?: "fastapi"} • version=${body?.version ?: "1.0"}"
                )
            } else {
                RemoteProbeResult(
                    reachable = false,
                    statusText = "HTTP ${response.code()}",
                    latencyMs = elapsed,
                    details = "Server responded with HTTP ${response.code()} on /api/v1/health"
                )
            }
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - start
            RemoteProbeResult(
                reachable = false,
                statusText = "Unreachable",
                latencyMs = elapsed,
                details = e.localizedMessage ?: "Connection refused / timed out"
            )
        }
    }

    suspend fun sendChat(
        baseUrl: String,
        message: String,
        preferredLanguage: String?,
        sessionId: String
    ): Result<FastApiChatResponse> {
        return try {
            val service = buildService(baseUrl)
            val response = service.postChat(
                FastApiChatRequest(
                    message = message,
                    preferredLanguage = if (preferredLanguage == "auto") null else preferredLanguage,
                    sessionId = sessionId
                )
            )
            val body = response.body()
            if (response.isSuccessful && body != null) {
                Result.success(body)
            } else {
                Result.failure(IllegalStateException("FastAPI /api/v1/chat failed with HTTP ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
