package com.example.genix.core

import com.example.genix.firebase.CrystalXModelId
import com.example.ui.theme.AppThemeMode

enum class ModelAccessScope(
    val shortBadge: String,
    val descriptionTr: String
) {
    SHARED(
        shortBadge = "ORTAK",
        descriptionTr = "Tüm planlarda (Free, Pro, Ultra) ortak kullanılabilir"
    ),
    PRO_EXCLUSIVE(
        shortBadge = "PRO ÖZEL",
        descriptionTr = "Cloudy Pro ve Ultra abonelerine özel"
    ),
    ULTRA_EXCLUSIVE(
        shortBadge = "ULTRA ÖZEL",
        descriptionTr = "Yalnızca Cloudy Ultra abonelerine özel"
    )
}

enum class SubscriptionPlan(
    val id: String,
    val rank: Int,
    val displayName: String,
    val priceLabel: String,
    val badge: String,
    val monthlyTokenQuota: Int,
    val maxVaultSlots: Int,
    val summary: String,
    val highlights: List<String>
) {
    FREE(
        id = "FREE",
        rank = 0,
        displayName = "Cloudy Free",
        priceLabel = "$0 / Ücretsiz",
        badge = "FREE",
        monthlyTokenQuota = 50_000,
        maxVaultSlots = 20,
        summary = "Ortak modeller, Beyaz & Koyu temalar, 19 ülke & sistem dili.",
        highlights = listOf(
            "Ortak Modeller: 2.0 Breeze, 1.1 Neo & Local CPU",
            "Beyaz Tema (Free) ve Koyu Tema (Free)",
            "50K Aylık Token Kotası • 20 Bulut Kasa Kaydı"
        )
    ),
    PRO(
        id = "PRO",
        rank = 1,
        displayName = "Cloudy Pro",
        priceLabel = "$9.99 / ay (Sandbox)",
        badge = "PRO",
        monthlyTokenQuota = 500_000,
        maxVaultSlots = 200,
        summary = "Buz Kristali Pro tema, 1.0 Pro, Vision & Code + Fotoğraf Analizi ve Voice Live.",
        highlights = listOf(
            "Free'deki tüm ortak modeller + 3 Pro-Özel Model",
            "Cloudy 1.0 Pro • Vision & Code (Görsel + Kod) • Voice Live",
            "Buz Kristali (Pro) Tema & Özel Kodlu/API Ses Profilleri"
        )
    ),
    ULTRA(
        id = "ULTRA",
        rank = 2,
        displayName = "Cloudy Ultra",
        priceLabel = "$24.99 / ay (Sandbox)",
        badge = "ULTRA",
        monthlyTokenQuota = 2_500_000,
        maxVaultSlots = 2000,
        summary = "Çift-turlu DeepThink Ultra, 3'lü paralel Multi-AI Konsensüs ve sınırsıza yakın kasa.",
        highlights = listOf(
            "Pro'daki tüm modeller + 2 Ultra-Özel Zirve Model",
            "Cloudy 2.5 DeepThink Ultra (2 Aşamalı Öz-Denetim Motoru)",
            "Cloudy Multi-AI Ensemble (2.0 Breeze + 1.1 Neo + 1.0 Pro)"
        )
    );

    fun canAccess(model: CrystalXModelId): Boolean {
        return when (model.accessScope) {
            ModelAccessScope.SHARED -> true
            ModelAccessScope.PRO_EXCLUSIVE -> rank >= PRO.rank
            ModelAccessScope.ULTRA_EXCLUSIVE -> rank >= ULTRA.rank
        }
    }

    fun canAccessTheme(mode: AppThemeMode): Boolean {
        return if (!mode.isPro) true else rank >= PRO.rank
    }

    companion object {
        fun fromId(id: String?): SubscriptionPlan =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: FREE

        fun requiredPlanFor(model: CrystalXModelId): SubscriptionPlan = when (model.accessScope) {
            ModelAccessScope.SHARED -> FREE
            ModelAccessScope.PRO_EXCLUSIVE -> PRO
            ModelAccessScope.ULTRA_EXCLUSIVE -> ULTRA
        }
    }
}
