package com.example.genix.firebase

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

enum class SocialAuthProvider(
    val providerId: String,
    val displayName: String,
    val scopes: List<String>
) {
    GITHUB("github.com", "GitHub", listOf("read:user", "user:email")),
    TWITTER("twitter.com", "X (Twitter)", emptyList()),
    FACEBOOK("facebook.com", "Facebook", listOf("email", "public_profile"))
}

object AuthHelper {

    private tailrec fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }

    fun attemptAutoSignIn(
        context: Context,
        credentialManager: CredentialManager,
        onAuthSuccess: () -> Unit,
        onUnauthenticated: () -> Unit,
        scope: CoroutineScope
    ) {
        if (Firebase.auth.currentUser != null) {
            onAuthSuccess()
            return
        }
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            onUnauthenticated()
            return
        }
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(true)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        scope.launch {
            try {
                val cred = credentialManager.getCredential(context, request).credential
                if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                    Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                    linkPendingCredentialIfAny()
                    onAuthSuccess()
                } else {
                    onUnauthenticated()
                }
            } catch (_: Exception) {
                onUnauthenticated()
            }
        }
    }

    fun onGoogleSignInClicked(
        context: Context,
        credentialManager: CredentialManager,
        onAuthSuccess: () -> Unit,
        onAuthError: (String) -> Unit,
        scope: CoroutineScope,
        onAuthCancelled: () -> Unit = {}
    ) {
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            onAuthError("Google ile giriş şu an kullanılamıyor.")
            return
        }
        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()

        scope.launch {
            try {
                val activity = context.findActivity()
                val cred = if (activity != null) {
                    credentialManager.getCredential(activity, request).credential
                } else {
                    credentialManager.getCredential(context, request).credential
                }
                if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                    Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                    linkPendingCredentialIfAny()
                    onAuthSuccess()
                } else {
                    onAuthError("Google ile giriş yapılamadı. Lütfen tekrar deneyin.")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
                onAuthCancelled()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("Auth", "Google Sign-In failed", e)
                val raw = e.localizedMessage.orEmpty()
                onAuthError(
                    when {
                        e is androidx.credentials.exceptions.NoCredentialException ->
                            "Cihazda Google hesabı bulunamadı. Ayarlar'dan bir Google hesabı ekleyip tekrar deneyin."
                        e is FirebaseNetworkException || raw.contains("network", ignoreCase = true) ->
                            "İnternet bağlantısı yok gibi görünüyor. Bağlantınızı kontrol edip tekrar deneyin."
                        e is FirebaseAuthUserCollisionException ->
                            "Bu e-posta başka bir giriş yöntemiyle kayıtlı. Lütfen o yöntemle giriş yapın."
                        else -> "Google ile giriş yapılamadı. Lütfen tekrar deneyin."
                    }
                )
            }
        }
    }

    /**
     * Credential from a GitHub / X / Facebook sign-in that collided with an existing account
     * (same e-mail, different provider). It is linked automatically after the user signs in
     * with the original provider so both buttons keep working for that account.
     */
    @Volatile
    private var pendingLinkCredential: AuthCredential? = null

    @Volatile
    private var pendingLinkProviderName: String? = null

    private fun languageTag(): String = java.util.Locale.getDefault().language.ifBlank { "en" }

    private fun buildProvider(provider: SocialAuthProvider): OAuthProvider {
        val builder = OAuthProvider.newBuilder(provider.providerId)
        if (provider.scopes.isNotEmpty()) {
            builder.setScopes(provider.scopes)
        }
        val params = when (provider) {
            SocialAuthProvider.GITHUB -> mapOf("allow_signup" to "true")
            SocialAuthProvider.TWITTER -> mapOf("lang" to languageTag())
            SocialAuthProvider.FACEBOOK -> emptyMap()
        }
        builder.addCustomParameters(params)
        return builder.build()
    }

    /** Links a credential saved from an earlier provider collision to the now signed-in user. */
    private suspend fun linkPendingCredentialIfAny() {
        val pending = pendingLinkCredential ?: return
        val user = Firebase.auth.currentUser ?: return
        runCatching { user.linkWithCredential(pending).await() }
            .onSuccess { Log.i("Auth", "Linked pending ${pendingLinkProviderName ?: "OAuth"} credential to existing account.") }
            .onFailure { Log.w("Auth", "Could not link pending credential: ${it.message}") }
        pendingLinkCredential = null
        pendingLinkProviderName = null
    }

    /**
     * Completes an OAuth sign-in that was still running when Android recreated the activity
     * (common on low-memory devices while the browser tab is open). Call once when the
     * sign-in screen appears.
     */
    fun recoverPendingOAuthResult(
        onAuthSuccess: () -> Unit,
        onAuthError: (String) -> Unit,
        scope: CoroutineScope
    ) {
        val pendingTask = Firebase.auth.pendingAuthResult ?: return
        scope.launch {
            try {
                val result = pendingTask.await()
                if (result?.user != null) {
                    linkPendingCredentialIfAny()
                    onAuthSuccess()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = friendlyOAuthError(e, null)
                if (msg != null) onAuthError(msg)
            }
        }
    }

    /** Maps Firebase / browser errors to a short, human message. Returns null for user cancellations. */
    private fun friendlyOAuthError(e: Exception, provider: SocialAuthProvider?): String? {
        val name = provider?.displayName ?: "Sağlayıcı"
        if (e is FirebaseAuthUserCollisionException) {
            val email = e.email
            e.updatedCredential?.let {
                pendingLinkCredential = it
                pendingLinkProviderName = provider?.displayName
            }
            return if (!email.isNullOrBlank()) {
                "$email adresi başka bir giriş yöntemiyle kayıtlı. O yöntemle (ör. Google) giriş yapın; $name hesabınız otomatik olarak bağlanacak."
            } else {
                "Bu e-posta başka bir giriş yöntemiyle kayıtlı. O yöntemle giriş yapın; $name hesabınız otomatik olarak bağlanacak."
            }
        }
        if (e is FirebaseNetworkException) {
            return "İnternet bağlantısı yok gibi görünüyor. Bağlantınızı kontrol edip tekrar deneyin."
        }
        if (e is android.content.ActivityNotFoundException) {
            return "$name girişi için cihazda bir tarayıcı bulunamadı. Chrome'u yükleyip/etkinleştirip tekrar deneyin."
        }
        val code = (e as? FirebaseAuthException)?.errorCode.orEmpty()
        val raw = e.localizedMessage.orEmpty()
        val lower = raw.lowercase()
        if (code == "ERROR_WEB_CONTEXT_CANCELED" || lower.contains("canceled") || lower.contains("cancelled")) {
            return null
        }
        return when {
            code == "ERROR_OPERATION_NOT_ALLOWED" || lower.contains("operation-not-allowed") || lower.contains("not enabled") ->
                "$name girişi şu an kullanılamıyor. Lütfen başka bir yöntemle giriş yapın."
            code == "ERROR_WEB_CONTEXT_ALREADY_PRESENTED" ->
                "$name giriş sayfası zaten açık. Tarayıcıdaki girişi tamamlayın veya kapatıp tekrar deneyin."
            code == "ERROR_INVALID_CREDENTIAL" || lower.contains("malformed") || lower.contains("invalid-credential") ->
                "$name oturumu doğrulanamadı. Birkaç saniye bekleyip tekrar deneyin."
            code == "ERROR_APP_NOT_AUTHORIZED" || lower.contains("not authorized") ->
                "Bu uygulama sürümü $name girişi için henüz yetkilendirilmedi. Lütfen Google ile giriş yapın."
            code == "ERROR_TOO_MANY_REQUESTS" || lower.contains("too many") ->
                "Çok fazla deneme yapıldı. Lütfen biraz bekleyip tekrar deneyin."
            code == "ERROR_USER_DISABLED" ->
                "Bu hesap devre dışı bırakılmış."
            code == "ERROR_WEB_STORAGE_UNSUPPORTED" || code == "ERROR_WEB_INTERNAL_ERROR" || lower.contains("web-internal-error") ->
                "$name giriş sayfası tarayıcıda açılamadı. Chrome'un güncel olduğundan emin olup tekrar deneyin."
            lower.contains("app check") || lower.contains("attestation") ->
                "Güvenlik doğrulaması tamamlanamadı. Lütfen tekrar deneyin."
            lower.contains("network") || lower.contains("timeout") || lower.contains("unreachable") ->
                "İnternet bağlantısı yok gibi görünüyor. Bağlantınızı kontrol edip tekrar deneyin."
            else -> "$name ile giriş yapılamadı. Lütfen tekrar deneyin."
        }
    }

    fun signInWithOAuthProvider(
        context: Context,
        provider: SocialAuthProvider,
        onAuthSuccess: () -> Unit,
        onAuthError: (String) -> Unit,
        scope: CoroutineScope,
        onAuthCancelled: () -> Unit = {}
    ) {
        val activity = context.findActivity()
        if (activity == null || activity.isFinishing) {
            onAuthError("${provider.displayName} girişi başlatılamadı. Lütfen tekrar deneyin.")
            return
        }

        scope.launch {
            try {
                val auth = Firebase.auth
                // An OAuth flow may already be in progress (e.g. activity recreated while the browser was open).
                val pendingTask = auth.pendingAuthResult
                if (pendingTask != null) {
                    val recovered = runCatching { pendingTask.await() }.getOrNull()
                    if (recovered?.user != null) {
                        linkPendingCredentialIfAny()
                        onAuthSuccess()
                        return@launch
                    }
                }

                val oauthProvider = buildProvider(provider)
                val current = auth.currentUser
                if (current != null && current.isAnonymous) {
                    current.startActivityForLinkWithProvider(activity, oauthProvider).await()
                } else {
                    auth.startActivityForSignInWithProvider(activity, oauthProvider).await()
                }
                linkPendingCredentialIfAny()
                onAuthSuccess()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = friendlyOAuthError(e, provider)
                if (msg == null) {
                    Log.w("Auth", "${provider.displayName} sign-in cancelled by user.")
                    onAuthCancelled()
                } else {
                    Log.e("Auth", "${provider.displayName} sign-in failed (${(e as? FirebaseAuthException)?.errorCode ?: e.javaClass.simpleName})", e)
                    onAuthError(msg)
                }
            }
        }
    }

    fun signOut(
        credentialManager: CredentialManager,
        scope: CoroutineScope,
        onSignOutComplete: () -> Unit = {}
    ) {
        scope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w("Auth", "Failed to clear credential state: ${e.message}")
                } finally {
                    Firebase.auth.signOut()
                    onSignOutComplete()
                }
            }
        }
    }
}
