package com.example.genix.intelligence.planning

import java.util.Locale
import java.util.UUID

enum class PlanStepStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED
}

enum class AgentRole(val label: String) {
    PLANNING_AGENT("PlanningAgent"),
    RESEARCH_AGENT("ResearchAgent"),
    CODING_AGENT("CodingAgent"),
    DEBUGGING_AGENT("DebuggingAgent"),
    VERIFICATION_AGENT("VerificationAgent")
}

data class PlanStep(
    val stepIndex: Int,
    val title: String,
    val assignedAgent: AgentRole,
    val dependsOnStep: Int?,
    val estimatedMemoryMb: Int,
    val timeoutSeconds: Int,
    val maxRetries: Int,
    val status: PlanStepStatus = PlanStepStatus.PENDING
)

data class ExecutionPlan(
    val planId: String = UUID.randomUUID().toString(),
    val objective: String,
    val languageCode: String,
    val steps: List<PlanStep>,
    val totalEstimatedRamMb: Int,
    val createdAtMs: Long = System.currentTimeMillis()
)

/**
 * GENIX Planning & Agent Orchestration Engine:
 * Decomposes complex goals into dependency-linked subtasks assigned to controlled agents
 * with explicit timeouts, retry limits, and permission boundaries.
 */
class PlanningEngine {

    fun isPlanningRequest(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT)
        return Regex("\\b(plan|roadmap|steps|architecture|decompose|subtasks|pipeline|workflow|planla|mimari|adım|yol haritası)\\b")
            .containsMatchIn(lower)
    }

    fun createPlan(objective: String, langCode: String): ExecutionPlan {
        val lower = objective.lowercase(Locale.ROOT)
        val includesCode = Regex("\\b(code|api|fastapi|python|kotlin|docker|build|test|kod|geliştir)\\b")
            .containsMatchIn(lower)
        val includesTraining = Regex("\\b(train|tokenizer|model|dataset|pytorch|eğit|veri)\\b")
            .containsMatchIn(lower)

        val steps = mutableListOf<PlanStep>()

        steps.add(
            PlanStep(
                stepIndex = 1,
                title = localizeStep(langCode, "Clarify objective constraints & validate permissions", "Hedef kısıtlarını doğrula ve izin sınırlarını kontrol et"),
                assignedAgent = AgentRole.PLANNING_AGENT,
                dependsOnStep = null,
                estimatedMemoryMb = 32,
                timeoutSeconds = 10,
                maxRetries = 1,
                status = PlanStepStatus.COMPLETED
            )
        )

        steps.add(
            PlanStep(
                stepIndex = 2,
                title = localizeStep(langCode, "Retrieve isolated context & inspect repository state", "Yalıtılmış bağlamı getir ve mevcut mimariyi incele"),
                assignedAgent = AgentRole.RESEARCH_AGENT,
                dependsOnStep = 1,
                estimatedMemoryMb = 64,
                timeoutSeconds = 20,
                maxRetries = 2
            )
        )

        if (includesTraining) {
            steps.add(
                PlanStep(
                    stepIndex = 3,
                    title = localizeStep(langCode, "Prepare tokenizer & dataset license/deduplication checks", "Tokenizer ve veri seti lisans/tekilleştirme kontrollerini hazırla"),
                    assignedAgent = AgentRole.CODING_AGENT,
                    dependsOnStep = 2,
                    estimatedMemoryMb = 512,
                    timeoutSeconds = 60,
                    maxRetries = 1
                )
            )
        } else if (includesCode) {
            steps.add(
                PlanStep(
                    stepIndex = 3,
                    title = localizeStep(langCode, "Generate modular implementation & sandboxed tests", "Modüler kodu ve korumalı alan testlerini oluştur"),
                    assignedAgent = AgentRole.CODING_AGENT,
                    dependsOnStep = 2,
                    estimatedMemoryMb = 128,
                    timeoutSeconds = 30,
                    maxRetries = 2
                )
            )
        } else {
            steps.add(
                PlanStep(
                    stepIndex = 3,
                    title = localizeStep(langCode, "Execute structured domain analysis", "Yapılandırılmış alan analizini yürüt"),
                    assignedAgent = AgentRole.RESEARCH_AGENT,
                    dependsOnStep = 2,
                    estimatedMemoryMb = 96,
                    timeoutSeconds = 25,
                    maxRetries = 2
                )
            )
        }

        steps.add(
            PlanStep(
                stepIndex = 4,
                title = localizeStep(langCode, "Audit outputs, security boundaries & acceptance criteria", "Çıktıları, güvenlik sınırlarını ve kabul kriterlerini doğrula"),
                assignedAgent = AgentRole.VERIFICATION_AGENT,
                dependsOnStep = 3,
                estimatedMemoryMb = 48,
                timeoutSeconds = 15,
                maxRetries = 1
            )
        )

        return ExecutionPlan(
            objective = objective.trim(),
            languageCode = langCode,
            steps = steps,
            totalEstimatedRamMb = steps.sumOf { it.estimatedMemoryMb }
        )
    }

    fun formatPlanSummary(plan: ExecutionPlan): String {
        val header = if (plan.languageCode == "tr") {
            "Oluşturulan Yürütme Planı (${plan.steps.size} Adım • Tahmini Bellek: ${plan.totalEstimatedRamMb} MB):"
        } else {
            "Generated Execution Plan (${plan.steps.size} Steps • Est. Memory: ${plan.totalEstimatedRamMb} MB):"
        }
        val lines = plan.steps.joinToString("\n") { step ->
            val dep = step.dependsOnStep?.let { " [dep:#$it]" } ?: ""
            "${step.stepIndex}. [${step.assignedAgent.label}]$dep ${step.title} (${step.timeoutSeconds}s timeout, retries=${step.maxRetries})"
        }
        return "$header\n$lines"
    }

    private fun localizeStep(langCode: String, en: String, tr: String): String =
        if (langCode == "tr") tr else en
}
