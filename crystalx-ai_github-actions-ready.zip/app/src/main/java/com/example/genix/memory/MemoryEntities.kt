package com.example.genix.memory

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "short_term_messages")
data class ShortTermMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String,
    val role: String, // "user" or "assistant"
    val content: String,
    val languageCode: String,
    val engineUsed: String,
    val modelId: String,
    val verificationStatus: String,
    val verificationNotes: String,
    val latencyMs: Long,
    val tokenCount: Int,
    val retrievedContextCount: Int,
    val isRemoteInference: Boolean,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "long_term_memories")
data class LongTermMemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "local-researcher",
    val category: String, // "preference", "project_context", "constraint"
    val keyName: String,
    val valueText: String,
    val userApproved: Boolean = true,
    val expiresAtMs: Long? = null,
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "knowledge_documents")
data class KnowledgeDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "local-researcher",
    val title: String,
    val sourceLabel: String,
    val content: String,
    val languageCode: String,
    val trustBoundary: String = "UNTRUSTED_RETRIEVED_CONTEXT",
    val createdAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val component: String,
    val severity: String,
    val message: String,
    val metadataJson: String,
    val timestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "generated_images")
data class GeneratedImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val prompt: String,
    val modelId: String,
    val aspectRatio: String,
    val filePath: String,
    val createdAtMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "document_artifacts")
data class DocumentArtifactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val pageCount: Int,
    val extractedText: String,
    val createdAtMs: Long = System.currentTimeMillis()
)
