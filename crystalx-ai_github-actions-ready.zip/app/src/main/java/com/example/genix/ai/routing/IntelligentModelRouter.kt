package com.example.genix.ai.routing

import com.example.genix.ai.core.AiModelCategory
import com.example.genix.ai.core.AiProviderKind
import com.example.genix.ai.core.CloudyAiModel
import com.example.genix.ai.core.ModelAvailabilityStatus
import com.example.genix.ai.registry.CloudyModelCatalog
import com.example.genix.ai.security.ProviderCredentialRecord
import com.example.genix.core.SubscriptionPlan
import com.example.genix.firebase.CrystalXModelId
import java.util.Locale

data class SmartRouteDecision(
    val selectedModel: CloudyAiModel,
    val detectedCategory: AiModelCategory,
    val wasAutoSwitched: Boolean,
    val rationale: String
)

/**
 * Multi-Model AI Router:
 * - When `autoRouteEnabled == false`: strictly respects the user's chosen model (while auto-upgrading
 *   non-vision models only if an image was explicitly attached).
 * - When `autoRouteEnabled == true`: classifies intent (Coding, Reasoning, Vision, Document, Creative, Fast)
 *   and selects the best unlocked & configured model without interrupting the conversation thread.
 */
class IntelligentModelRouter(
    private val catalog: CloudyModelCatalog
) {
    fun resolveModelForTurn(
        prompt: String,
        selectedModel: CloudyAiModel,
        autoRouteEnabled: Boolean,
        hasImages: Boolean,
        hasDocument: Boolean,
        codingMode: Boolean,
        plan: SubscriptionPlan,
        credentials: Map<AiProviderKind, ProviderCredentialRecord>,
        fastApiUrl: String
    ): SmartRouteDecision {
        val intentCategory = classifyIntent(
            prompt = prompt,
            hasImages = hasImages,
            hasDocument = hasDocument,
            codingMode = codingMode
        )

        if (!autoRouteEnabled) {
            if (hasImages && !selectedModel.capabilities.visionInput) {
                val visionModel = pickBestAvailable(
                    candidates = listOf(CrystalXModelId.VISION_CODE.id, CrystalXModelId.NEO_1_1.id),
                    plan = plan,
                    credentials = credentials,
                    fastApiUrl = fastApiUrl
                ) ?: selectedModel
                return SmartRouteDecision(
                    selectedModel = visionModel,
                    detectedCategory = AiModelCategory.IMAGE_UNDERSTANDING,
                    wasAutoSwitched = visionModel.id != selectedModel.id,
                    rationale = "Switched to vision-capable ${visionModel.displayName} for attached photo."
                )
            }
            return SmartRouteDecision(
                selectedModel = selectedModel,
                detectedCategory = intentCategory,
                wasAutoSwitched = false,
                rationale = "Manual model selection preserved: ${selectedModel.displayName}"
            )
        }

        // If user explicitly picked a configured external BYOK model, keep it unless vision is needed & unsupported
        if (selectedModel.provider.requiresByokKey &&
            catalog.availabilityFor(selectedModel, plan, credentials, fastApiUrl) == ModelAvailabilityStatus.READY
        ) {
            if (!hasImages || selectedModel.capabilities.visionInput) {
                return SmartRouteDecision(
                    selectedModel = selectedModel,
                    detectedCategory = intentCategory,
                    wasAutoSwitched = false,
                    rationale = "Active BYOK provider ${selectedModel.displayName} handles $intentCategory."
                )
            }
        }

        val preferredIds = when (intentCategory) {
            AiModelCategory.IMAGE_UNDERSTANDING, AiModelCategory.CODING -> listOf(
                CrystalXModelId.VISION_CODE.id,
                CrystalXModelId.PRO_1_0.id,
                "anthropic-claude-sonnet",
                "deepseek-chat",
                CrystalXModelId.NEO_1_1.id
            )
            AiModelCategory.ADVANCED_REASONING -> listOf(
                CrystalXModelId.DEEPTHINK_ULTRA.id,
                CrystalXModelId.PRO_1_0.id,
                "openai-o3-mini",
                "deepseek-reasoner",
                CrystalXModelId.NEO_1_1.id
            )
            AiModelCategory.FAST_RESPONSES -> listOf(
                CrystalXModelId.BREEZE_2_0.id,
                "meta-llama-3.3-70b",
                CrystalXModelId.NEO_1_1.id
            )
            AiModelCategory.CREATIVE_WRITING -> listOf(
                CrystalXModelId.NEO_1_1.id,
                "anthropic-claude-sonnet",
                "mistral-large-latest"
            )
            else -> listOf(
                selectedModel.id,
                CrystalXModelId.NEO_1_1.id,
                CrystalXModelId.BREEZE_2_0.id
            )
        }

        val chosen = pickBestAvailable(preferredIds, plan, credentials, fastApiUrl) ?: selectedModel
        return SmartRouteDecision(
            selectedModel = chosen,
            detectedCategory = intentCategory,
            wasAutoSwitched = chosen.id != selectedModel.id,
            rationale = "Auto-routed $intentCategory → ${chosen.displayName}"
        )
    }

    fun classifyIntent(
        prompt: String,
        hasImages: Boolean,
        hasDocument: Boolean,
        codingMode: Boolean
    ): AiModelCategory {
        val lower = prompt.lowercase(Locale.ROOT).trim()
        if (hasImages) return AiModelCategory.IMAGE_UNDERSTANDING
        if (codingMode || lower.contains("```") ||
            Regex("\\b(kotlin|python|java|sql|typescript|javascript|compose|gradle|bug|refactor|regex|api|function|class|stacktrace|hata|kod)\\b")
                .containsMatchIn(lower)
        ) {
            return AiModelCategory.CODING
        }
        if (hasDocument ||
            Regex("\\b(prove|theorem|architecture|system design|benchmark|compare|analyze|audit|equation|deriv|neden|karşılaştır|mimar)\\b")
                .containsMatchIn(lower)
        ) {
            return AiModelCategory.ADVANCED_REASONING
        }
        if (Regex("\\b(story|poem|essay|script|creative|novel|slogan|hikaye|şiir|senaryo|yaratıcı)\\b")
                .containsMatchIn(lower)
        ) {
            return AiModelCategory.CREATIVE_WRITING
        }
        if (lower.length < 75) return AiModelCategory.FAST_RESPONSES
        return AiModelCategory.GENERAL_AI
    }

    private fun pickBestAvailable(
        candidates: List<String>,
        plan: SubscriptionPlan,
        credentials: Map<AiProviderKind, ProviderCredentialRecord>,
        fastApiUrl: String
    ): CloudyAiModel? {
        for (id in candidates) {
            val candidate = catalog.findById(id)
            if (candidate.id == id &&
                catalog.availabilityFor(candidate, plan, credentials, fastApiUrl) == ModelAvailabilityStatus.READY
            ) {
                return candidate
            }
        }
        return null
    }
}
