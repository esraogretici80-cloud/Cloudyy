package com.example.genix.core

import com.example.genix.intelligence.coding.CodingEngine
import com.example.genix.intelligence.language.MultilingualLanguageSystem
import com.example.genix.intelligence.planning.ExecutionPlan
import com.example.genix.intelligence.planning.PlanningEngine
import com.example.genix.intelligence.reasoning.ReasoningEngine
import com.example.genix.memory.KnowledgeSearchHit
import com.example.genix.memory.MemoryRepository
import com.example.genix.memory.ShortTermMessageEntity
import com.example.genix.models.ModelRegistry
import com.example.genix.models.RemoteFastApiAdapter
import com.example.genix.router.ModelRouter
import com.example.genix.training.GenixTokenizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * GENIX AI Central Core Engine (Section 4):
 * - Validates incoming requests
 * - Detects language independently via MultilingualLanguageSystem
 * - Routes via ModelRouter across Language, Reasoning, Coding, Planning, and Embedding engines
 * - Supports CPU-only Local Foundation and optional self-hosted Remote FastAPI Control Plane
 * - Persists Short-Term Memory & Audit Logs
 */
class CoreEngine(
    private val eventSystem: EventSystem,
    val modelRegistry: ModelRegistry,
    val modelRouter: ModelRouter,
    val reasoningEngine: ReasoningEngine,
    val codingEngine: CodingEngine,
    val planningEngine: PlanningEngine,
    val tokenizer: GenixTokenizer,
    private val memoryRepository: MemoryRepository,
    private val remoteFastApiAdapter: RemoteFastApiAdapter
) {
    private val _latestPlan = MutableStateFlow<ExecutionPlan?>(null)
    val latestPlan: StateFlow<ExecutionPlan?> = _latestPlan.asStateFlow()

    private val _lastRetrievedHits = MutableStateFlow<List<KnowledgeSearchHit>>(emptyList())
    val lastRetrievedHits: StateFlow<List<KnowledgeSearchHit>> = _lastRetrievedHits.asStateFlow()

    suspend fun processRequest(
        request: GenixRequest,
        config: GenixConfig
    ): Result<GenixResponse> {
        val startMs = System.currentTimeMillis()
        val trimmed = request.prompt.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Request prompt cannot be empty."))
        }
        if (trimmed.length > 16_000) {
            eventSystem.log("CoreEngine", LogSeverity.SECURITY, "Rejected oversized request (${trimmed.length} chars)")
            return Result.failure(IllegalArgumentException("Request exceeds maximum allowed input quota (16,000 chars)."))
        }

        // 1. Independent Multilingual Detection
        val fallbackLang = when {
            config.preferredLanguageCode != "auto" -> config.preferredLanguageCode
            !request.activeConversationLanguage.isNullOrBlank() -> request.activeConversationLanguage
            else -> "en"
        }
        val detected = MultilingualLanguageSystem.detectLanguage(trimmed, fallbackLang)
        val responseLang = when {
            detected.explicitSwitchTarget != null -> detected.explicitSwitchTarget
            config.preferredLanguageCode != "auto" -> config.preferredLanguageCode
            else -> detected.primaryCode
        }

        eventSystem.log(
            component = "LanguageSystem",
            severity = LogSeverity.INFO,
            message = "Detected=${detected.primaryCode} (${(detected.confidence * 100).toInt()}%), responseLang=$responseLang, mixed=${detected.isMixedLanguage}"
        )

        // 2. Persist User Turn into Short-Term Memory
        val tokenCount = tokenizer.encode(trimmed).size
        memoryRepository.appendShortTermMessage(
            ShortTermMessageEntity(
                sessionId = request.sessionId,
                role = "user",
                content = trimmed,
                languageCode = detected.primaryCode,
                engineUsed = "USER_INPUT",
                modelId = "client",
                verificationStatus = VerificationStatus.LOCAL_DETERMINISTIC.name,
                verificationNotes = "User input tokenized ($tokenCount tokens)",
                latencyMs = 0L,
                tokenCount = tokenCount,
                retrievedContextCount = 0,
                isRemoteInference = false
            )
        )

        // 3. Optional Knowledge Memory Retrieval (strictly isolated as UNTRUSTED_RETRIEVED_CONTEXT)
        val retrievedHits = if (request.useKnowledgeContext) {
            memoryRepository.searchKnowledge(trimmed)
        } else {
            emptyList()
        }
        _lastRetrievedHits.value = retrievedHits

        // 4. Intelligent Model Routing
        val routing = modelRouter.route(
            prompt = trimmed,
            languageCode = responseLang,
            availableModels = modelRegistry.models.value,
            executionMode = config.executionMode,
            maxContextBudget = config.maxContextTokens
        )

        eventSystem.log(
            component = "ModelRouter",
            severity = LogSeverity.INFO,
            message = "Category=${routing.requestCategory}, Engine=${routing.selectedEngine}, Model=${routing.selectedModelId}"
        )

        // 5. Execute on Remote FastAPI Control Plane if enabled & appropriate, else Local Foundation
        var responseText: String
        var verificationStatus: VerificationStatus
        var verificationNotes: String
        var traceSteps: List<String> = emptyList()
        var isRemote = false

        if (config.executionMode == ExecutionMode.REMOTE_FASTAPI_CONTROL_PLANE &&
            routing.requestCategory != RequestCategory.REASONING_MATH &&
            routing.requestCategory != RequestCategory.CODING
        ) {
            val remoteResult = remoteFastApiAdapter.sendChat(
                baseUrl = config.controlPlaneUrl,
                message = trimmed,
                preferredLanguage = responseLang,
                sessionId = request.sessionId
            )
            if (remoteResult.isSuccess) {
                val body = remoteResult.getOrThrow()
                responseText = body.reply ?: body.response ?: "(Empty payload from FastAPI server)"
                verificationStatus = if (body.verified == true) VerificationStatus.VERIFIED_COMPUTATION else VerificationStatus.REMOTE_MODEL_UNVERIFIED
                verificationNotes = "Served by self-hosted FastAPI backend (${body.modelId ?: routing.selectedModelId})"
                isRemote = true
            } else {
                val err = remoteResult.exceptionOrNull()?.message ?: "FastAPI unreachable"
                eventSystem.log("CoreEngine", LogSeverity.WARN, "Remote FastAPI failed: $err. Falling back cleanly.")
                responseText = if (responseLang == "tr") {
                    "Uzak FastAPI Kontrol Düzlemine erişilemedi ($err). Sahte yanıt üretilmedi; Sistem sekmesinden sunucu bağlantısını doğrulayın veya Yerel CPU Temeli moduna geçin."
                } else {
                    "Remote FastAPI Control Plane unreachable ($err). GENIX never fabricates responses; verify your server URL in System or switch to Local CPU Foundation."
                }
                verificationStatus = VerificationStatus.UNSUPPORTED_CAPABILITY
                verificationNotes = "Remote inference unavailable: $err"
            }
        } else {
            when (routing.requestCategory) {
                RequestCategory.REASONING_MATH -> {
                    val res = reasoningEngine.evaluate(trimmed, responseLang)
                    responseText = res.answer
                    verificationStatus = res.verificationStatus
                    verificationNotes = res.verificationSummary
                    traceSteps = res.steps
                }
                RequestCategory.CODING -> {
                    val report = codingEngine.analyzeCode(trimmed, responseLang)
                    responseText = codingEngine.formatReportForConsole(report, responseLang)
                    verificationStatus = report.verificationStatus
                    verificationNotes = "Static lexer & security scan completed on ${report.detectedLanguage}."
                    traceSteps = listOf(
                        "Language=${report.detectedLanguage}",
                        "DelimitersBalanced=${report.delimitersBalanced}",
                        "SecurityFindings=${report.securityFindings.size}"
                    )
                }
                RequestCategory.PLANNING -> {
                    val plan = planningEngine.createPlan(trimmed, responseLang)
                    _latestPlan.value = plan
                    responseText = planningEngine.formatPlanSummary(plan)
                    verificationStatus = VerificationStatus.LOCAL_DETERMINISTIC
                    verificationNotes = "Dependency-ordered execution plan generated (${plan.steps.size} steps)."
                    traceSteps = plan.steps.map { "${it.stepIndex}. ${it.assignedAgent.label}: ${it.title}" }
                }
                RequestCategory.EMBEDDING_SEARCH -> {
                    if (retrievedHits.isEmpty()) {
                        responseText = if (responseLang == "tr") {
                            "Bilgi Belleğinde sorguyla eşleşen kayıt bulunamadı. Lab > Bellek sekmesinden yeni belge ekleyebilirsiniz."
                        } else {
                            "No matching records found in local Knowledge Memory. Add documents in Lab > Memory to index them."
                        }
                    } else {
                        val hitLines = retrievedHits.joinToString("\n\n") { hit ->
                            val pct = (hit.similarityScore * 100).toInt()
                            "[${hit.isolationBoundary}] (${pct}% match) ${hit.document.title} (${hit.document.sourceLabel}):\n${hit.document.content}"
                        }
                        responseText = if (responseLang == "tr") {
                            "Yerel Bilgi Belleği Sonuçları:\n\n$hitLines"
                        } else {
                            "Local Knowledge Memory Matches:\n\n$hitLines"
                        }
                    }
                    verificationStatus = VerificationStatus.LOCAL_DETERMINISTIC
                    verificationNotes = "Local character-trigram + word cosine retrieval (${retrievedHits.size} hits)."
                }
                RequestCategory.CONVERSATION, RequestCategory.UNSUPPORTED -> {
                    if (modelRouter.isGreetingOrCapabilityQuestion(trimmed) || detected.explicitSwitchTarget != null) {
                        responseText = MultilingualLanguageSystem.buildConversationalGreeting(
                            langCode = responseLang,
                            isMixed = detected.isMixedLanguage,
                            preservedTerms = detected.preservedTechnicalTerms
                        )
                        verificationStatus = VerificationStatus.LOCAL_DETERMINISTIC
                        verificationNotes = "Multilingual Core Engine capability response ($responseLang)."
                    } else if (retrievedHits.isNotEmpty()) {
                        val topHit = retrievedHits.first()
                        val pct = (topHit.similarityScore * 100).toInt()
                        val prefix = if (responseLang == "tr") {
                            "Yerel Bilgi Belleğinden ilgili kayıt bulundu (%$pct eşleşme — güvenilmeyen bağlam olarak etiketlendi):"
                        } else {
                            "Relevant record found in local Knowledge Memory ($pct% match — tagged as untrusted retrieved context):"
                        }
                        responseText = "$prefix\n\n• ${topHit.document.title}: ${topHit.document.content}\n\n" +
                            MultilingualLanguageSystem.buildUnsupportedNotice(
                                responseLang,
                                routing.limitationReason ?: ""
                            )
                        verificationStatus = VerificationStatus.LOCAL_DETERMINISTIC
                        verificationNotes = "Retrieved local knowledge context; open-ended neural synthesis deferred to Phase 2+."
                    } else {
                        responseText = MultilingualLanguageSystem.buildUnsupportedNotice(
                            responseLang,
                            routing.limitationReason ?: "Requires open-weight or GENIX Base neural weights."
                        )
                        verificationStatus = VerificationStatus.UNSUPPORTED_CAPABILITY
                        verificationNotes = "Honest Phase 1 CPU-only boundary reported."
                    }
                }
            }
        }

        val latency = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
        val outTokens = tokenizer.encode(responseText).size

        // Persist Assistant Turn into Short-Term Memory
        memoryRepository.appendShortTermMessage(
            ShortTermMessageEntity(
                sessionId = request.sessionId,
                role = "assistant",
                content = responseText,
                languageCode = responseLang,
                engineUsed = routing.selectedEngine.name,
                modelId = routing.selectedModelId,
                verificationStatus = verificationStatus.name,
                verificationNotes = verificationNotes,
                latencyMs = latency,
                tokenCount = outTokens,
                retrievedContextCount = retrievedHits.size,
                isRemoteInference = isRemote
            )
        )

        return Result.success(
            GenixResponse(
                requestId = request.requestId,
                content = responseText,
                detectedLanguage = detected,
                responseLanguageCode = responseLang,
                routingDecision = routing,
                verificationStatus = verificationStatus,
                verificationNotes = verificationNotes,
                latencyMs = latency,
                tokenCount = outTokens,
                retrievedContextCount = retrievedHits.size,
                traceSteps = traceSteps,
                isRemoteInference = isRemote
            )
        )
    }

    fun getHealthStatus(config: GenixConfig, activeLang: String): HealthStatus {
        val loadedCount = modelRegistry.loadedCount()
        return HealthStatus(
            state = if (loadedCount > 0 || config.executionMode == ExecutionMode.REMOTE_FASTAPI_CONTROL_PLANE) {
                HealthState.HEALTHY
            } else {
                HealthState.DEGRADED
            },
            mode = config.executionMode,
            cpuOnlyReady = config.cpuOnlySafeMode,
            loadedModelsCount = loadedCount,
            activeLanguage = activeLang,
            message = if (config.executionMode == ExecutionMode.LOCAL_CPU_FOUNDATION) {
                "CPU-only Phase 1 Core Engine operational ($loadedCount models loaded)"
            } else {
                "Configured for Remote FastAPI Control Plane (${config.controlPlaneUrl})"
            }
        )
    }

    fun getPhaseRoadmap(): List<PhaseRoadmapItem> = listOf(
        PhaseRoadmapItem(1, "Phase 1 — Foundation", PhaseStatus.IMPLEMENTED_FOUNDATION, "Core Engine, Config, Logging, Health, Registry, Multilingual System, Tests."),
        PhaseRoadmapItem(2, "Phase 2 — First Model", PhaseStatus.PARTIAL_LOCAL_PROTOTYPE, "ModelAdapter interface & Remote FastAPI adapter ready; local open-weight GGUF/vLLM worker runs on compute plane."),
        PhaseRoadmapItem(3, "Phase 3 — Intelligence", PhaseStatus.IMPLEMENTED_FOUNDATION, "Model Router, Language, Deterministic Reasoning, Static Coding & Planning engines active."),
        PhaseRoadmapItem(4, "Phase 4 — Memory", PhaseStatus.PARTIAL_LOCAL_PROTOTYPE, "3-layer Room + cosine retrieval implemented locally; server PostgreSQL/pgvector/Redis in cloud plane."),
        PhaseRoadmapItem(5, "Phase 5 — Agents", PhaseStatus.PARTIAL_LOCAL_PROTOTYPE, "Bounded DAG Planning & Agent roles modeled; isolated execution sandboxes run on compute plane."),
        PhaseRoadmapItem(6, "Phase 6 — GENIX Base", PhaseStatus.PARTIAL_LOCAL_PROTOTYPE, "Phase A Unicode Tokenizer & Phase B Transformer Estimator live; PyTorch pretraining runs on GPU workers."),
        PhaseRoadmapItem(7, "Phase 7 — Production", PhaseStatus.PLANNED_COMPUTE_PLANE, "Cloud GPU inference, Prometheus monitoring, automated security & load benchmarks."),
        PhaseRoadmapItem(8, "Phase 8 — Independence", PhaseStatus.PLANNED_COMPUTE_PLANE, "Proprietary GENIX model weights & autonomous evaluation benchmarks.")
    )
}
