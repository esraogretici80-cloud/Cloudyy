package com.example.genix.ai.security

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.genix.ai.core.AiProviderKind
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.providerKeysDataStore: DataStore<Preferences> by preferencesDataStore(name = "cloudy_provider_keys")

data class ProviderCredentialRecord(
    val provider: AiProviderKind,
    val apiKey: String = "",
    val baseUrl: String = provider.defaultBaseUrl
) {
    val hasKey: Boolean get() = apiKey.isNotBlank()

    fun maskedKey(): String {
        val clean = apiKey.trim()
        if (clean.isEmpty()) return ""
        return if (clean.length <= 8) {
            "••••${clean.takeLast(2)}"
        } else {
            "${clean.take(4)}••••${clean.takeLast(4)}"
        }
    }
}

/**
 * Device-local BYOK (Bring Your Own Key) credential store.
 * Security rule: API keys stay strictly inside private device DataStore and are NEVER written to Firestore or logs.
 */
class ProviderAuthManager(private val context: Context) {

    private fun keyFor(provider: AiProviderKind) = stringPreferencesKey("byok_key_${provider.id}")
    private fun urlFor(provider: AiProviderKind) = stringPreferencesKey("byok_url_${provider.id}")

    val credentialsFlow: Flow<Map<AiProviderKind, ProviderCredentialRecord>> =
        context.providerKeysDataStore.data.map { prefs ->
            AiProviderKind.entries.associateWith { kind ->
                ProviderCredentialRecord(
                    provider = kind,
                    apiKey = prefs[keyFor(kind)].orEmpty(),
                    baseUrl = prefs[urlFor(kind)]?.takeIf { it.isNotBlank() } ?: kind.defaultBaseUrl
                )
            }
        }

    suspend fun getCredential(provider: AiProviderKind): ProviderCredentialRecord {
        val prefs = context.providerKeysDataStore.data.first()
        return ProviderCredentialRecord(
            provider = provider,
            apiKey = prefs[keyFor(provider)].orEmpty(),
            baseUrl = prefs[urlFor(provider)]?.takeIf { it.isNotBlank() } ?: provider.defaultBaseUrl
        )
    }

    suspend fun saveCredential(provider: AiProviderKind, apiKey: String, customBaseUrl: String = "") {
        val cleanUrl = customBaseUrl.trim().ifBlank { provider.defaultBaseUrl }
        context.providerKeysDataStore.edit { prefs ->
            if (apiKey.isBlank()) {
                prefs.remove(keyFor(provider))
            } else {
                prefs[keyFor(provider)] = apiKey.trim()
            }
            prefs[urlFor(provider)] = cleanUrl
        }
    }

    suspend fun clearCredential(provider: AiProviderKind) {
        context.providerKeysDataStore.edit { prefs ->
            prefs.remove(keyFor(provider))
            prefs.remove(urlFor(provider))
        }
    }

    suspend fun clearAllKeys() {
        context.providerKeysDataStore.edit { it.clear() }
    }
}
