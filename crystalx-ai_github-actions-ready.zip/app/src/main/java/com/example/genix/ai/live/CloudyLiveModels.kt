package com.example.genix.ai.live

enum class LiveConnectionState {
    IDLE,
    CONNECTING,
    LISTENING,
    PROCESSING,
    SPEAKING,
    INTERRUPTED,
    RECONNECTING,
    ERROR
}

enum class LiveTransportBackend(val displayName: String, val isNativeBidirectional: Boolean) {
    FIREBASE_GEMINI_LIVE("Gemini Live Native Audio (WebSocket)", true),
    OPENAI_REALTIME("OpenAI Realtime Audio (WebSocket)", true),
    TURN_BASED_FALLBACK("Studio Turn-Based Voice Fallback (Mic STT + Neural TTS)", false)
}

data class LiveTranscriptEntry(
    val id: String,
    val role: String, // "user" | "assistant" | "system"
    val text: String,
    val timestampMs: Long = System.currentTimeMillis()
)

data class LiveSessionTelemetry(
    val connectionState: LiveConnectionState = LiveConnectionState.IDLE,
    val backend: LiveTransportBackend = LiveTransportBackend.FIREBASE_GEMINI_LIVE,
    val activeVoiceName: String = "Aoede",
    val isMuted: Boolean = false,
    val elapsedSeconds: Long = 0L,
    val micLevel: Float = 0.08f,
    val speakerLevel: Float = 0.08f,
    val waveformBars: List<Float> = List(24) { 0.1f },
    val transcripts: List<LiveTranscriptEntry> = emptyList(),
    val statusDetail: String = "Ready",
    val errorMessage: String? = null
)
