package com.example.genix.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.SpeechConfig
import com.google.firebase.ai.type.Voice
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

private const val TAG = "CloudyVoiceEngine"

enum class CloudyVoicePersona(
    val id: String,
    val displayName: String,
    val badge: String,
    val studioVoiceName: String,
    val engineType: String,
    val description: String
) {
    AOEDE(
        id = "aoede",
        displayName = "Aoede",
        badge = "UNIVERSAL WARM",
        studioVoiceName = "Aoede",
        engineType = "Neural Multilingual Studio",
        description = "Warm, expressive universal voice fluent in Turkish, English, Arabic, European & Asian languages."
    ),
    KORE(
        id = "kore",
        displayName = "Kore",
        badge = "CRYSTAL CLEAR",
        studioVoiceName = "Kore",
        engineType = "Neural Multilingual Studio",
        description = "Crisp, balanced high-clarity studio voice ideal for explanations, summaries & technical dialogue."
    ),
    CHARON(
        id = "charon",
        displayName = "Charon",
        badge = "DEEP BARITONE",
        studioVoiceName = "Charon",
        engineType = "Neural Multilingual Studio",
        description = "Deep, calm baritone voice with natural cadence across all supported global languages."
    ),
    PUCK(
        id = "puck",
        displayName = "Puck",
        badge = "LIVELY LIVE",
        studioVoiceName = "Puck",
        engineType = "Neural Multilingual Studio",
        description = "Energetic, conversational live voice tailored for fast back-and-forth Voice Live chats."
    ),
    FENRIR(
        id = "fenrir",
        displayName = "Fenrir",
        badge = "AUTHORITATIVE",
        studioVoiceName = "Fenrir",
        engineType = "Neural Multilingual Studio",
        description = "Rich, confident narrative voice for DeepThink audits and long-form briefings."
    ),
    CUSTOM_API(
        id = "custom_api",
        displayName = "Custom Voice API",
        badge = "EXTERNAL API",
        studioVoiceName = "Aoede",
        engineType = "HTTP Audio Stream",
        description = "Streams MP3/WAV from ElevenLabs, OpenAI /v1/audio/speech, Piper, or Kokoro FastAPI."
    );

    companion object {
        fun fromId(raw: String?): CloudyVoicePersona = when (raw) {
            "nova_crystal", "aoede", "AOEDE" -> AOEDE
            "velvet_echo", "kore", "KORE" -> KORE
            "glacial_titan", "charon", "CHARON" -> CHARON
            "cyber_aero", "puck", "PUCK" -> PUCK
            "fenrir", "FENRIR" -> FENRIR
            "custom_api", "CUSTOM_API" -> CUSTOM_API
            else -> entries.firstOrNull { it.id.equals(raw, ignoreCase = true) || it.name.equals(raw, ignoreCase = true) } ?: AOEDE
        }
    }
}

enum class VoiceApiProvider(val id: String, val label: String) {
    CUSTOM_HTTP("custom_http", "Piper / Kokoro / Custom HTTP"),
    ELEVENLABS("elevenlabs", "ElevenLabs TTS API"),
    OPENAI_TTS("openai_tts", "OpenAI-Compatible /v1/audio/speech");

    companion object {
        fun fromId(raw: String?): VoiceApiProvider =
            entries.firstOrNull { it.id == raw } ?: CUSTOM_HTTP
    }
}

data class VoicePlaybackState(
    val isSpeaking: Boolean = false,
    val isSynthesizing: Boolean = false,
    val activePersona: CloudyVoicePersona = CloudyVoicePersona.AOEDE,
    val activeSourceLabel: String = "Universal Neural Studio Voice Ready",
    val activeMessageId: String? = null,
    val waveformBars: List<Float> = List(20) { 0.12f },
    val lastError: String? = null
)

/**
 * Universal Neural Studio Voice Engine for Cloudy AI.
 * Eliminates synthetic "vzzz" tone beeps and avoids robotic built-in device voices.
 * Uses:
 * 1) Gemini 3.1 Flash TTS (`gemini-3.1-flash-tts-preview`) via Firebase AI Logic with native multilingual voices (Aoede, Kore, Charon, Puck, Fenrir)
 * 2) External HTTP Voice API (ElevenLabs, OpenAI-compatible /v1/audio/speech, Piper, Kokoro) when Custom API is configured.
 */
class CloudyVoiceEngine(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _state = MutableStateFlow(VoicePlaybackState())
    val state: StateFlow<VoicePlaybackState> = _state.asStateFlow()

    private var playJob: Job? = null

    @Volatile
    private var currentAudioTrack: AudioTrack? = null

    @Volatile
    private var currentMediaPlayer: MediaPlayer? = null

    fun speak(
        text: String,
        messageId: String?,
        persona: CloudyVoicePersona,
        languageCode: String,
        speedMultiplier: Float = 1.0f,
        pitchMultiplier: Float = 1.0f,
        apiProvider: VoiceApiProvider = VoiceApiProvider.CUSTOM_HTTP,
        apiUrl: String = "",
        apiKey: String = "",
        customVoiceId: String = "nova"
    ) {
        stopSpeaking()
        val cleanText = sanitizeForSpeech(text)
        if (cleanText.isBlank()) return

        playJob = scope.launch {
            if (persona == CloudyVoicePersona.CUSTOM_API && apiUrl.isNotBlank()) {
                val apiResult = playFromExternalVoiceApi(
                    text = cleanText,
                    messageId = messageId,
                    languageCode = languageCode,
                    speedMultiplier = speedMultiplier,
                    pitchMultiplier = pitchMultiplier,
                    provider = apiProvider,
                    apiUrl = apiUrl,
                    apiKey = apiKey,
                    customVoiceId = customVoiceId
                )
                if (apiResult.isSuccess) return@launch

                val errMsg = apiResult.exceptionOrNull()?.message ?: "External Voice API error"
                Log.w(TAG, "External Voice API failed, falling back to Aoede Neural Studio: $errMsg")
                playGeminiNeuralVoice(
                    text = cleanText,
                    messageId = messageId,
                    persona = CloudyVoicePersona.AOEDE,
                    speedMultiplier = speedMultiplier,
                    pitchMultiplier = pitchMultiplier,
                    sourcePrefix = "API Fallback • Aoede"
                )
            } else {
                playGeminiNeuralVoice(
                    text = cleanText,
                    messageId = messageId,
                    persona = persona,
                    speedMultiplier = speedMultiplier,
                    pitchMultiplier = pitchMultiplier,
                    sourcePrefix = "${persona.displayName} • Neural Studio"
                )
            }
        }
    }

    fun stopSpeaking() {
        playJob?.cancel()
        playJob = null
        runCatching {
            currentAudioTrack?.pause()
            currentAudioTrack?.flush()
            currentAudioTrack?.release()
        }
        currentAudioTrack = null
        runCatching {
            currentMediaPlayer?.stop()
            currentMediaPlayer?.release()
        }
        currentMediaPlayer = null
        _state.value = _state.value.copy(
            isSpeaking = false,
            isSynthesizing = false,
            activeMessageId = null,
            waveformBars = List(20) { 0.10f }
        )
    }

    fun release() {
        stopSpeaking()
    }

    @Suppress("OPT_IN_USAGE_ERROR")
    private suspend fun playGeminiNeuralVoice(
        text: String,
        messageId: String?,
        persona: CloudyVoicePersona,
        speedMultiplier: Float,
        pitchMultiplier: Float,
        sourcePrefix: String
    ) = withContext(Dispatchers.IO) {
        _state.value = VoicePlaybackState(
            isSpeaking = true,
            isSynthesizing = true,
            activePersona = persona,
            activeSourceLabel = "$sourcePrefix (Generating natural speech...)",
            activeMessageId = messageId,
            waveformBars = List(20) { 0.22f },
            lastError = null
        )

        try {
            val ttsModel = Firebase.ai.generativeModel(
                modelName = "gemini-3.1-flash-tts-preview",
                generationConfig = generationConfig {
                    responseModalities = listOf(ResponseModality.AUDIO)
                    speechConfig = SpeechConfig(voice = Voice(persona.studioVoiceName))
                }
            )

            val response = withTimeout(45_000L) {
                ttsModel.generateContent(text.take(1800))
            }

            val audioPart = response.inlineDataParts.firstOrNull {
                it.mimeType.startsWith("audio/", ignoreCase = true)
            } ?: response.candidates
                .firstOrNull()
                ?.content
                ?.parts
                ?.filterIsInstance<com.google.firebase.ai.type.InlineDataPart>()
                ?.firstOrNull()

            if (audioPart == null || audioPart.inlineData.isEmpty()) {
                val errDetail = response.text?.take(120)?.takeIf { it.isNotBlank() }
                    ?: "Neural TTS returned no audio bytes"
                _state.value = _state.value.copy(
                    isSpeaking = false,
                    isSynthesizing = false,
                    activeMessageId = null,
                    activeSourceLabel = "$sourcePrefix unavailable",
                    waveformBars = List(20) { 0.10f },
                    lastError = errDetail
                )
                return@withContext
            }

            val mime = audioPart.mimeType.lowercase(Locale.ROOT)
            val audioBytes = audioPart.inlineData

            _state.value = _state.value.copy(
                isSynthesizing = false,
                activeSourceLabel = "$sourcePrefix • Speaking"
            )

            if (mime.contains("pcm") || mime.contains("l16")) {
                val sampleRate = parseSampleRateFromMime(mime, defaultRate = 24000)
                playRawPcm16(
                    pcmBytes = audioBytes,
                    sampleRate = sampleRate,
                    speedMultiplier = speedMultiplier,
                    pitchMultiplier = pitchMultiplier
                )
            } else {
                val ext = when {
                    mime.contains("wav") -> "wav"
                    mime.contains("ogg") -> "ogg"
                    mime.contains("mp4") || mime.contains("m4a") -> "m4a"
                    else -> "mp3"
                }
                playEncodedAudioFile(
                    audioBytes = audioBytes,
                    extension = ext,
                    speedMultiplier = speedMultiplier,
                    pitchMultiplier = pitchMultiplier
                )
            }

            _state.value = _state.value.copy(
                isSpeaking = false,
                isSynthesizing = false,
                activeMessageId = null,
                activeSourceLabel = "$sourcePrefix Ready",
                waveformBars = List(20) { 0.10f }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini Neural TTS failed", e)
            val errMsg = e.localizedMessage ?: "Neural voice synthesis failed"
            _state.value = _state.value.copy(
                isSpeaking = false,
                isSynthesizing = false,
                activeMessageId = null,
                activeSourceLabel = "Voice synthesis paused ($errMsg)",
                waveformBars = List(20) { 0.10f },
                lastError = errMsg
            )
        }
    }

    private suspend fun playRawPcm16(
        pcmBytes: ByteArray,
        sampleRate: Int,
        speedMultiplier: Float,
        pitchMultiplier: Float
    ) = withContext(Dispatchers.IO) {
        val effectiveRate = (sampleRate * speedMultiplier.coerceIn(0.70f, 1.50f) * pitchMultiplier.coerceIn(0.85f, 1.20f))
            .toInt()
            .coerceIn(12000, 48000)

        val minBuf = AudioTrack.getMinBufferSize(
            effectiveRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(effectiveRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        currentAudioTrack = track
        try {
            track.play()
            val chunkBytes = 3200
            var offset = 0
            var tick = 0
            while (offset < pcmBytes.size && coroutineContext.isActive) {
                val len = minOf(chunkBytes, pcmBytes.size - offset)
                // Convert even byte slice RMS for authentic live waveform feedback
                var sumSq = 0.0
                var samples = 0
                var idx = offset
                while (idx + 1 < offset + len) {
                    val lo = pcmBytes[idx].toInt() and 0xFF
                    val hi = pcmBytes[idx + 1].toInt()
                    val sample = ((hi shl 8) or lo).toShort() / 32768.0
                    sumSq += sample * sample
                    samples++
                    idx += 2
                }
                val rms = if (samples > 0) sqrt(sumSq / samples).toFloat() else 0.1f
                val level = (rms * 4.5f).coerceIn(0.12f, 0.98f)
                tick++
                val bars = List(20) { b ->
                    val arch = 1f - abs(b - 9.5f) / 11f
                    (level * (0.45f + 0.6f * arch) * (0.7f + 0.3f * sin(tick * 0.7 + b * 0.6).toFloat()))
                        .coerceIn(0.08f, 0.98f)
                }
                _state.value = _state.value.copy(waveformBars = bars)

                track.write(pcmBytes, offset, len)
                offset += len
            }
            // Wait slightly so tail buffers finish cleanly
            delay(180L)
        } finally {
            runCatching {
                track.stop()
                track.release()
            }
            if (currentAudioTrack === track) currentAudioTrack = null
        }
    }

    private suspend fun playEncodedAudioFile(
        audioBytes: ByteArray,
        extension: String,
        speedMultiplier: Float,
        pitchMultiplier: Float
    ) = withContext(Dispatchers.IO) {
        val tempFile = File(context.cacheDir, "cloudy_voice_stream.$extension").apply {
            writeBytes(audioBytes)
        }

        val doneSignal = CompletableDeferred<Unit>()
        val player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            setDataSource(tempFile.absolutePath)
            setOnCompletionListener { doneSignal.complete(Unit) }
            setOnErrorListener { _, what, extra ->
                doneSignal.completeExceptionally(IllegalStateException("MediaPlayer error ($what/$extra)"))
                true
            }
            prepare()
            runCatching {
                playbackParams = PlaybackParams().apply {
                    speed = speedMultiplier.coerceIn(0.70f, 1.50f)
                    pitch = pitchMultiplier.coerceIn(0.75f, 1.35f)
                }
            }
            start()
        }
        currentMediaPlayer = player

        try {
            var tick = 0
            while (!doneSignal.isCompleted && currentMediaPlayer != null && coroutineContext.isActive) {
                tick++
                val bars = List(20) { idx ->
                    val phase = tick * 0.48 + idx * 0.62
                    (0.24f + 0.68f * abs(sin(phase)).toFloat()).coerceIn(0.12f, 0.96f)
                }
                _state.value = _state.value.copy(waveformBars = bars)
                delay(55L)
            }
            doneSignal.await()
        } finally {
            runCatching {
                player.stop()
                player.release()
            }
            if (currentMediaPlayer === player) currentMediaPlayer = null
        }
    }

    private suspend fun playFromExternalVoiceApi(
        text: String,
        messageId: String?,
        languageCode: String,
        speedMultiplier: Float,
        pitchMultiplier: Float,
        provider: VoiceApiProvider,
        apiUrl: String,
        apiKey: String,
        customVoiceId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            _state.value = VoicePlaybackState(
                isSpeaking = true,
                isSynthesizing = true,
                activePersona = CloudyVoicePersona.CUSTOM_API,
                activeSourceLabel = "Streaming ${provider.label}...",
                activeMessageId = messageId,
                waveformBars = List(20) { 0.35f }
            )

            val endpoint = apiUrl.trim()
            require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) {
                "Voice API URL must start with http:// or https://"
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBuilder = Request.Builder().url(endpoint)

            val payload = when (provider) {
                VoiceApiProvider.ELEVENLABS -> {
                    if (apiKey.isNotBlank()) requestBuilder.addHeader("xi-api-key", apiKey.trim())
                    requestBuilder.addHeader("Accept", "audio/mpeg")
                    JSONObject().apply {
                        put("text", text.take(2400))
                        put("model_id", "eleven_multilingual_v2")
                    }.toString()
                }
                VoiceApiProvider.OPENAI_TTS -> {
                    if (apiKey.isNotBlank()) requestBuilder.addHeader("Authorization", "Bearer ${apiKey.trim()}")
                    JSONObject().apply {
                        put("model", "tts-1")
                        put("voice", customVoiceId.ifBlank { "nova" })
                        put("input", text.take(2400))
                        put("response_format", "mp3")
                    }.toString()
                }
                VoiceApiProvider.CUSTOM_HTTP -> {
                    if (apiKey.isNotBlank()) requestBuilder.addHeader("Authorization", "Bearer ${apiKey.trim()}")
                    JSONObject().apply {
                        put("text", text.take(2400))
                        put("voice", customVoiceId.ifBlank { "cloudy" })
                        put("language", languageCode)
                    }.toString()
                }
            }

            val req = requestBuilder.post(payload.toRequestBody(mediaType)).build()
            val audioBytes = httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val errBody = resp.body?.string()?.take(140).orEmpty()
                    error("HTTP ${resp.code}: $errBody")
                }
                resp.body?.bytes() ?: error("Empty audio response")
            }

            _state.value = _state.value.copy(
                isSynthesizing = false,
                activeSourceLabel = "Playing ${provider.label} ($customVoiceId)"
            )

            playEncodedAudioFile(
                audioBytes = audioBytes,
                extension = "mp3",
                speedMultiplier = speedMultiplier,
                pitchMultiplier = pitchMultiplier
            )
        }.also {
            _state.value = _state.value.copy(
                isSpeaking = false,
                isSynthesizing = false,
                activeMessageId = null,
                waveformBars = List(20) { 0.10f },
                lastError = it.exceptionOrNull()?.message
            )
        }
    }

    private fun parseSampleRateFromMime(mime: String, defaultRate: Int): Int {
        val match = Regex("rate=(\\d+)").find(mime)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull()?.coerceIn(8000, 48000) ?: defaultRate
    }

    private fun sanitizeForSpeech(raw: String): String {
        return raw
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*#_`~|━]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
