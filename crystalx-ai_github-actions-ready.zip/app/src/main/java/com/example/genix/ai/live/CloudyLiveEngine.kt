package com.example.genix.ai.live

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import com.example.genix.voice.CloudyVoicePersona
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.AudioTranscriptionConfig
import com.google.firebase.ai.type.InlineData
import com.google.firebase.ai.type.InlineDataPart
import com.google.firebase.ai.type.LiveServerContent
import com.google.firebase.ai.type.LiveServerGoAway
import com.google.firebase.ai.type.LiveSession
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.RealtimeInputConfig
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.SpeechConfig
import com.google.firebase.ai.type.Voice
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.liveGenerationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

private const val TAG = "CloudyLiveEngine"
private const val CAPTURE_SAMPLE_RATE = 16000
private const val PLAYBACK_SAMPLE_RATE = 24000

/**
 * Genuine Real-Time Bidirectional Voice Engine for Cloudy Live.
 *
 * Primary Transport: Firebase AI Logic Gemini Live WebSocket (`Firebase.ai.liveModel`)
 *   - 16kHz PCM16 AudioRecord microphone capture -> `session.sendAudioRealtime(InlineData(...))`
 *   - 24kHz PCM16 AudioTrack streaming playback from `session.receive()`
 *   - Native barge-in interruption via `RealtimeInputConfig.ActivityHandling.INTERRUPT` + immediate AudioTrack flush
 *   - Real-time input & output transcripts (`inputTranscription` / `outputTranscription`)
 *
 * Secondary Transport (BYOK): OpenAI Realtime WebSocket (`wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview`)
 */
@OptIn(PublicPreviewAPI::class)
class CloudyLiveEngine(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wsClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private val _telemetry = MutableStateFlow(LiveSessionTelemetry())
    val telemetry: StateFlow<LiveSessionTelemetry> = _telemetry.asStateFlow()

    private var sessionJob: Job? = null
    private var timerJob: Job? = null
    private var captureJob: Job? = null
    private var receiveJob: Job? = null

    @Volatile
    private var activeLiveSession: LiveSession? = null

    @Volatile
    private var activeOpenAiWs: WebSocket? = null

    @Volatile
    private var audioRecord: AudioRecord? = null

    @Volatile
    private var audioTrack: AudioTrack? = null

    private var currentTranscriptAssistantId: String? = null
    private var currentTranscriptUserId: String? = null
    private var currentSessionLanguage: String = "en"
    private var currentPersona: CloudyVoicePersona = CloudyVoicePersona.AOEDE
    private var currentOpenAiKey: String = ""
    private var currentCustomInstructions: String = ""
    private var currentBackendChoice: LiveTransportBackend = LiveTransportBackend.FIREBASE_GEMINI_LIVE

    private val liveModelCandidates = listOf(
        "gemini-live-2.5-flash-preview",
        "gemini-2.5-flash-native-audio-preview-12-2025",
        "gemini-2.0-flash-live-preview-04-09"
    )

    @SuppressLint("MissingPermission")
    fun startSession(
        languageCode: String,
        persona: CloudyVoicePersona,
        openAiApiKey: String = "",
        preferOpenAiRealtime: Boolean = false,
        customInstructions: String = ""
    ) {
        stopInternal(resetToIdle = false)

        currentSessionLanguage = languageCode
        currentPersona = persona
        currentOpenAiKey = openAiApiKey.trim()
        currentCustomInstructions = customInstructions.trim()
        currentBackendChoice = if (preferOpenAiRealtime && currentOpenAiKey.isNotBlank()) {
            LiveTransportBackend.OPENAI_REALTIME
        } else {
            LiveTransportBackend.FIREBASE_GEMINI_LIVE
        }

        _telemetry.value = LiveSessionTelemetry(
            connectionState = LiveConnectionState.CONNECTING,
            backend = currentBackendChoice,
            activeVoiceName = persona.studioVoiceName,
            statusDetail = "Connecting to ${currentBackendChoice.displayName}..."
        )

        timerJob = scope.launch {
            while (isActive) {
                delay(1000L)
                val st = _telemetry.value.connectionState
                if (st in setOf(
                        LiveConnectionState.LISTENING,
                        LiveConnectionState.PROCESSING,
                        LiveConnectionState.SPEAKING,
                        LiveConnectionState.INTERRUPTED
                    )
                ) {
                    _telemetry.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1L) }
                }
            }
        }

        sessionJob = scope.launch {
            if (currentBackendChoice == LiveTransportBackend.OPENAI_REALTIME) {
                connectOpenAiRealtime()
            } else {
                connectFirebaseGeminiLive(attempt = 0)
            }
        }
    }

    private suspend fun connectFirebaseGeminiLive(attempt: Int) {
        var lastError: Throwable? = null
        var connectedSession: LiveSession? = null

        val voiceName = if (currentPersona == CloudyVoicePersona.CUSTOM_API) {
            CloudyVoicePersona.AOEDE.studioVoiceName
        } else {
            currentPersona.studioVoiceName
        }

        val instructionText = buildString {
            append("You are Cloudy Live, a warm, natural, conversational real-time AI voice companion. ")
            append("Speak naturally without robotic filler or markdown symbols. ")
            append("Always understand and respond fluently in language code '$currentSessionLanguage' ")
            append("(especially Turkish and English, switching seamlessly if the speaker switches). ")
            append("Keep responses crisp, conversational, and natural for spoken dialogue. ")
            if (currentCustomInstructions.isNotBlank()) {
                append("User preference: $currentCustomInstructions")
            }
        }

        for (modelId in liveModelCandidates) {
            try {
                val cfg = liveGenerationConfig {
                    responseModality = ResponseModality.AUDIO
                    speechConfig = SpeechConfig(voice = Voice(voiceName))
                    inputAudioTranscription = AudioTranscriptionConfig()
                    outputAudioTranscription = AudioTranscriptionConfig()
                    realtimeInputConfig = RealtimeInputConfig.builder()
                        .setActivityHandling(RealtimeInputConfig.ActivityHandling.INTERRUPT)
                        .build()
                }
                val liveModel = Firebase.ai.liveModel(
                    modelName = modelId,
                    generationConfig = cfg,
                    systemInstruction = content { text(instructionText) }
                )
                val session = liveModel.connect()
                connectedSession = session
                break
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                Log.w(TAG, "Gemini Live connect failed on $modelId: ${t.message}")
                lastError = t
            }
        }

        val session = connectedSession
        if (session == null) {
            if (attempt < 1) {
                _telemetry.update {
                    it.copy(
                        connectionState = LiveConnectionState.RECONNECTING,
                        statusDetail = "Reconnecting live voice channel..."
                    )
                }
                delay(1500L)
                connectFirebaseGeminiLive(attempt + 1)
                return
            }
            val msg = lastError?.localizedMessage ?: "Unable to connect Gemini Live WebSocket."
            _telemetry.update {
                it.copy(
                    connectionState = LiveConnectionState.ERROR,
                    statusDetail = "Live connection unavailable",
                    errorMessage = msg
                )
            }
            return
        }

        activeLiveSession = session
        setupAudioTrack()
        _telemetry.update {
            it.copy(
                connectionState = LiveConnectionState.LISTENING,
                backend = LiveTransportBackend.FIREBASE_GEMINI_LIVE,
                activeVoiceName = voiceName,
                statusDetail = "Live audio active • Speak anytime",
                errorMessage = null
            )
        }

        launchMicrophoneCapture { pcmBytes ->
            runCatching {
                session.sendAudioRealtime(InlineData(pcmBytes, "audio/pcm;rate=$CAPTURE_SAMPLE_RATE"))
            }
        }

        receiveJob = scope.launch {
            try {
                session.receive().collect { serverMsg ->
                    when (serverMsg) {
                        is LiveServerContent -> {
                            if (serverMsg.interrupted) {
                                handleServerInterruption()
                            }
                            val inTranscript = serverMsg.inputTranscription?.text?.trim().orEmpty()
                            if (inTranscript.isNotEmpty()) {
                                appendOrUpdateTranscript(role = "user", chunk = inTranscript, appendSpace = true)
                                if (_telemetry.value.connectionState == LiveConnectionState.LISTENING) {
                                    _telemetry.update { it.copy(connectionState = LiveConnectionState.PROCESSING) }
                                }
                            }

                            val outTranscript = serverMsg.outputTranscription?.text?.trim().orEmpty()
                            if (outTranscript.isNotEmpty()) {
                                appendOrUpdateTranscript(role = "assistant", chunk = outTranscript, appendSpace = true)
                            }

                            val parts = serverMsg.content?.parts.orEmpty()
                            for (part in parts) {
                                if (part is InlineDataPart && part.mimeType.startsWith("audio/", ignoreCase = true)) {
                                    val audioBytes = part.inlineData
                                    if (audioBytes.isNotEmpty()) {
                                        if (_telemetry.value.connectionState != LiveConnectionState.SPEAKING) {
                                            _telemetry.update {
                                                it.copy(
                                                    connectionState = LiveConnectionState.SPEAKING,
                                                    statusDetail = "Speaking (${voiceName})"
                                                )
                                            }
                                        }
                                        writePcmToSpeaker(audioBytes)
                                    }
                                }
                            }

                            if (serverMsg.turnComplete || serverMsg.generationComplete) {
                                currentTranscriptUserId = null
                                currentTranscriptAssistantId = null
                                _telemetry.update {
                                    it.copy(
                                        connectionState = LiveConnectionState.LISTENING,
                                        speakerLevel = 0.08f,
                                        statusDetail = "Listening..."
                                    )
                                }
                            }
                        }
                        is LiveServerGoAway -> {
                            _telemetry.update {
                                it.copy(
                                    connectionState = LiveConnectionState.RECONNECTING,
                                    statusDetail = "Refreshing live session..."
                                )
                            }
                            launch {
                                session.close()
                                connectFirebaseGeminiLive(attempt = 0)
                            }
                        }
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                Log.e(TAG, "Gemini Live receive loop failed", t)
                _telemetry.update {
                    it.copy(
                        connectionState = LiveConnectionState.ERROR,
                        statusDetail = "Live stream interrupted",
                        errorMessage = t.localizedMessage ?: "WebSocket receive error"
                    )
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectOpenAiRealtime() {
        val url = "wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview"
        val req = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $currentOpenAiKey")
            .addHeader("OpenAI-Beta", "realtime=v1")
            .build()

        setupAudioTrack()
        val ws = wsClient.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val voice = when (currentPersona) {
                    CloudyVoicePersona.KORE -> "shimmer"
                    CloudyVoicePersona.CHARON -> "ash"
                    CloudyVoicePersona.PUCK -> "echo"
                    CloudyVoicePersona.FENRIR -> "onyx"
                    else -> "alloy"
                }
                val sessionUpdate = JSONObject().apply {
                    put("type", "session.update")
                    put(
                        "session",
                        JSONObject()
                            .put("voice", voice)
                            .put("input_audio_format", "pcm16")
                            .put("output_audio_format", "pcm16")
                            .put("instructions", "Speak naturally in '$currentSessionLanguage' as Cloudy Live.")
                            .put("input_audio_transcription", JSONObject().put("model", "whisper-1"))
                            .put(
                                "turn_detection",
                                JSONObject().put("type", "server_vad").put("threshold", 0.5).put("silence_duration_ms", 500)
                            )
                    )
                }
                webSocket.send(sessionUpdate.toString())
                _telemetry.update {
                    it.copy(
                        connectionState = LiveConnectionState.LISTENING,
                        backend = LiveTransportBackend.OPENAI_REALTIME,
                        activeVoiceName = voice,
                        statusDetail = "OpenAI Realtime WebSocket active",
                        errorMessage = null
                    )
                }

                launchMicrophoneCapture { pcmBytes ->
                    val b64 = Base64.encodeToString(pcmBytes, Base64.NO_WRAP)
                    val ev = JSONObject().put("type", "input_audio_buffer.append").put("audio", b64)
                    webSocket.send(ev.toString())
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val obj = runCatching { JSONObject(text) }.getOrNull() ?: return
                when (obj.optString("type")) {
                    "input_audio_buffer.speech_started" -> handleServerInterruption()
                    "conversation.item.input_audio_transcription.completed" -> {
                        val tr = obj.optString("transcript").trim()
                        if (tr.isNotEmpty()) {
                            appendOrUpdateTranscript("user", tr, appendSpace = false)
                            currentTranscriptUserId = null
                            _telemetry.update { it.copy(connectionState = LiveConnectionState.PROCESSING) }
                        }
                    }
                    "response.audio_transcript.delta" -> {
                        val delta = obj.optString("delta")
                        if (delta.isNotEmpty()) appendOrUpdateTranscript("assistant", delta, appendSpace = false)
                    }
                    "response.audio.delta" -> {
                        val b64 = obj.optString("delta")
                        if (b64.isNotEmpty()) {
                            val bytes = Base64.decode(b64, Base64.DEFAULT)
                            _telemetry.update { it.copy(connectionState = LiveConnectionState.SPEAKING) }
                            writePcmToSpeaker(bytes)
                        }
                    }
                    "response.done" -> {
                        currentTranscriptAssistantId = null
                        _telemetry.update {
                            it.copy(
                                connectionState = LiveConnectionState.LISTENING,
                                speakerLevel = 0.08f,
                                statusDetail = "Listening..."
                            )
                        }
                    }
                    "error" -> {
                        val err = obj.optJSONObject("error")?.optString("message").orEmpty()
                        _telemetry.update {
                            it.copy(
                                connectionState = LiveConnectionState.ERROR,
                                errorMessage = err.ifBlank { "OpenAI Realtime error" }
                            )
                        }
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _telemetry.update {
                    it.copy(
                        connectionState = LiveConnectionState.ERROR,
                        statusDetail = "Realtime WebSocket disconnected",
                        errorMessage = t.localizedMessage ?: "Connection failed"
                    )
                }
            }
        })
        activeOpenAiWs = ws
    }

    @SuppressLint("MissingPermission")
    private fun launchMicrophoneCapture(onAudioChunk: suspend (ByteArray) -> Unit) {
        captureJob?.cancel()
        captureJob = scope.launch {
            val minBuf = AudioRecord.getMinBufferSize(
                CAPTURE_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3200)

            val recorder = runCatching {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    CAPTURE_SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf * 2
                )
            }.getOrNull()

            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                _telemetry.update {
                    it.copy(
                        connectionState = LiveConnectionState.ERROR,
                        errorMessage = "Microphone audio recorder could not initialize."
                    )
                }
                return@launch
            }

            audioRecord = recorder
            recorder.startRecording()
            val buffer = ByteArray(2048)
            var tick = 0

            try {
                while (isActive) {
                    val read = recorder.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        val slice = buffer.copyOf(read)
                        val rms = computeRmsNormalized(slice)
                        tick++

                        if (!_telemetry.value.isMuted) {
                            // Local barge-in signal if user starts speaking loudly during assistant output
                            if (_telemetry.value.connectionState == LiveConnectionState.SPEAKING && rms > 0.24f) {
                                handleServerInterruption()
                            }
                            onAudioChunk(slice)
                            updateWaveform(micRms = rms, speakerRms = _telemetry.value.speakerLevel, tick = tick)
                        } else {
                            updateWaveform(micRms = 0.04f, speakerRms = _telemetry.value.speakerLevel, tick = tick)
                        }
                    }
                }
            } finally {
                runCatching {
                    recorder.stop()
                    recorder.release()
                }
                if (audioRecord === recorder) audioRecord = null
            }
        }
    }

    private fun setupAudioTrack() {
        val minBuf = AudioTrack.getMinBufferSize(
            PLAYBACK_SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(PLAYBACK_SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track.play()
        audioTrack = track
    }

    private fun writePcmToSpeaker(pcmBytes: ByteArray) {
        val track = audioTrack ?: return
        val rms = computeRmsNormalized(pcmBytes)
        updateWaveform(micRms = _telemetry.value.micLevel, speakerRms = rms, tick = (System.currentTimeMillis() / 60L).toInt())
        runCatching {
            track.write(pcmBytes, 0, pcmBytes.size)
        }
    }

    fun toggleMute() {
        _telemetry.update { it.copy(isMuted = !it.isMuted) }
    }

    fun interruptAssistant() {
        handleServerInterruption()
        scope.launch {
            runCatching { activeLiveSession?.sendStartActivityRealtime() }
            activeOpenAiWs?.send(JSONObject().put("type", "response.cancel").toString())
        }
    }

    fun sendLiveTextTurn(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        appendOrUpdateTranscript("user", clean, appendSpace = false)
        currentTranscriptUserId = null
        scope.launch {
            _telemetry.update { it.copy(connectionState = LiveConnectionState.PROCESSING) }
            runCatching { activeLiveSession?.send(clean) }
            activeOpenAiWs?.let { ws ->
                val item = JSONObject()
                    .put("type", "conversation.item.create")
                    .put(
                        "item",
                        JSONObject()
                            .put("type", "message")
                            .put("role", "user")
                            .put("content", org.json.JSONArray().put(JSONObject().put("type", "input_text").put("text", clean)))
                    )
                ws.send(item.toString())
                ws.send(JSONObject().put("type", "response.create").toString())
            }
        }
    }

    fun reconnect() {
        startSession(
            languageCode = currentSessionLanguage,
            persona = currentPersona,
            openAiApiKey = currentOpenAiKey,
            preferOpenAiRealtime = currentBackendChoice == LiveTransportBackend.OPENAI_REALTIME,
            customInstructions = currentCustomInstructions
        )
    }

    fun endSession() {
        stopInternal(resetToIdle = true)
    }

    private fun handleServerInterruption() {
        runCatching {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        }
        currentTranscriptAssistantId = null
        _telemetry.update {
            it.copy(
                connectionState = LiveConnectionState.INTERRUPTED,
                speakerLevel = 0.08f,
                statusDetail = "Interrupted — listening..."
            )
        }
        scope.launch {
            delay(380L)
            if (_telemetry.value.connectionState == LiveConnectionState.INTERRUPTED) {
                _telemetry.update {
                    it.copy(
                        connectionState = LiveConnectionState.LISTENING,
                        statusDetail = "Listening..."
                    )
                }
            }
        }
    }

    private fun stopInternal(resetToIdle: Boolean) {
        captureJob?.cancel()
        captureJob = null
        receiveJob?.cancel()
        receiveJob = null
        sessionJob?.cancel()
        sessionJob = null
        timerJob?.cancel()
        timerJob = null

        val sessionToClose = activeLiveSession
        activeLiveSession = null
        if (sessionToClose != null) {
            scope.launch { runCatching { sessionToClose.close() } }
        }

        runCatching { activeOpenAiWs?.close(1000, "User ended call") }
        activeOpenAiWs = null

        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null

        runCatching {
            audioTrack?.stop()
            audioTrack?.release()
        }
        audioTrack = null

        currentTranscriptAssistantId = null
        currentTranscriptUserId = null

        if (resetToIdle) {
            _telemetry.value = LiveSessionTelemetry(
                connectionState = LiveConnectionState.IDLE,
                activeVoiceName = currentPersona.studioVoiceName,
                transcripts = _telemetry.value.transcripts,
                statusDetail = "Session ended"
            )
        }
    }

    private fun appendOrUpdateTranscript(role: String, chunk: String, appendSpace: Boolean) {
        val currentId = if (role == "user") currentTranscriptUserId else currentTranscriptAssistantId
        _telemetry.update { state ->
            val list = state.transcripts.toMutableList()
            val idx = if (currentId != null) list.indexOfFirst { it.id == currentId } else -1
            if (idx >= 0) {
                val existing = list[idx]
                val separator = if (appendSpace && !existing.text.endsWith(" ") && !chunk.startsWith(" ")) " " else ""
                list[idx] = existing.copy(text = existing.text + separator + chunk)
            } else {
                val newId = UUID.randomUUID().toString()
                if (role == "user") currentTranscriptUserId = newId else currentTranscriptAssistantId = newId
                list.add(LiveTranscriptEntry(id = newId, role = role, text = chunk))
            }
            state.copy(transcripts = list.takeLast(40))
        }
    }

    private fun updateWaveform(micRms: Float, speakerRms: Float, tick: Int) {
        val level = maxOf(micRms, speakerRms).coerceIn(0.08f, 1.0f)
        val bars = List(24) { idx ->
            val centerArch = 1f - abs(idx - 11.5f) / 13f
            (level * (0.35f + 0.65f * centerArch) * (0.68f + 0.32f * sin(tick * 0.55 + idx * 0.52).toFloat()))
                .coerceIn(0.08f, 0.98f)
        }
        _telemetry.update { it.copy(micLevel = micRms, speakerLevel = speakerRms, waveformBars = bars) }
    }

    private fun computeRmsNormalized(pcmBytes: ByteArray): Float {
        var sumSq = 0.0
        var count = 0
        var i = 0
        while (i + 1 < pcmBytes.size) {
            val lo = pcmBytes[i].toInt() and 0xFF
            val hi = pcmBytes[i + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort() / 32768.0
            sumSq += sample * sample
            count++
            i += 2
        }
        val rms = if (count > 0) sqrt(sumSq / count).toFloat() else 0.05f
        return (rms * 5.0f).coerceIn(0.06f, 1.0f)
    }

    fun release() {
        stopInternal(resetToIdle = true)
    }
}
