package com.example.genix.core

import java.util.UUID

enum class EngineCategory {
    LANGUAGE,
    REASONING,
    CODING,
    PLANNING,
    EMBEDDING,
    EXPERIMENTAL
}

enum class ExecutionMode {
    LOCAL_CPU_FOUNDATION,
    REMOTE_FASTAPI_CONTROL_PLANE
}

enum class VerificationStatus {
    VERIFIED_COMPUTATION,
    STATIC_ANALYSIS_VERIFIED,
    LOCAL_DETERMINISTIC,
    REMOTE_MODEL_UNVERIFIED,
    UNSUPPORTED_CAPABILITY
}

enum class RequestCategory {
    CONVERSATION,
    REASONING_MATH,
    CODING,
    PLANNING,
    EMBEDDING_SEARCH,
    UNSUPPORTED
}

data class LanguageDetectionResult(
    val primaryCode: String,
    val primaryDisplayName: String,
    val confidence: Float,
    val isMixedLanguage: Boolean = false,
    val secondaryCode: String? = null,
    val preservedTechnicalTerms: List<String> = emptyList(),
    val explicitSwitchTarget: String? = null
)

data class RoutingCandidateScore(
    val modelId: String,
    val modelName: String,
    val score: Double,
    val reason: String,
    val selected: Boolean
)

data class RoutingDecision(
    val requestCategory: RequestCategory,
    val selectedEngine: EngineCategory,
    val selectedModelId: String,
    val selectedModelName: String,
    val estimatedContextTokens: Int,
    val policySummary: String,
    val candidates: List<RoutingCandidateScore>,
    val capabilitySupported: Boolean = true,
    val limitationReason: String? = null
)

data class GenixRequest(
    val requestId: String = UUID.randomUUID().toString(),
    val sessionId: String = "default-session",
    val prompt: String,
    val preferredLanguageCode: String = "auto",
    val activeConversationLanguage: String? = null,
    val useKnowledgeContext: Boolean = true,
    val timestampMs: Long = System.currentTimeMillis()
)

data class GenixResponse(
    val requestId: String,
    val content: String,
    val detectedLanguage: LanguageDetectionResult,
    val responseLanguageCode: String,
    val routingDecision: RoutingDecision,
    val verificationStatus: VerificationStatus,
    val verificationNotes: String,
    val latencyMs: Long,
    val tokenCount: Int,
    val retrievedContextCount: Int = 0,
    val traceSteps: List<String> = emptyList(),
    val isRemoteInference: Boolean = false
)

enum class HealthState {
    HEALTHY,
    DEGRADED,
    UNREACHABLE
}

data class HealthStatus(
    val state: HealthState,
    val mode: ExecutionMode,
    val cpuOnlyReady: Boolean,
    val loadedModelsCount: Int,
    val activeLanguage: String,
    val message: String,
    val checkedAtMs: Long = System.currentTimeMillis()
)

data class PhaseRoadmapItem(
    val phaseNumber: Int,
    val title: String,
    val status: PhaseStatus,
    val summary: String
)

enum class PhaseStatus {
    IMPLEMENTED_FOUNDATION,
    PARTIAL_LOCAL_PROTOTYPE,
    PLANNED_COMPUTE_PLANE
}

enum class LogSeverity {
    INFO,
    WARN,
    ERROR,
    SECURITY
}

data class GenixEventLog(
    val id: String = UUID.randomUUID().toString(),
    val timestampMs: Long = System.currentTimeMillis(),
    val component: String,
    val severity: LogSeverity,
    val message: String,
    val metadataJson: String = "{}"
)
