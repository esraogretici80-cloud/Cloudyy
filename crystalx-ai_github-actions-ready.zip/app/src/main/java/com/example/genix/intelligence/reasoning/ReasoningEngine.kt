package com.example.genix.intelligence.reasoning

import com.example.genix.core.VerificationStatus
import java.util.Locale
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

data class ReasoningResult(
    val answer: String,
    val verificationStatus: VerificationStatus,
    val verificationSummary: String,
    val steps: List<String>
)

/**
 * GENIX Reasoning Engine:
 * Distinguishes independently verified deterministic math/logic computations from
 * unverified or open-ended requests. Never pretends a heuristic guess is verified.
 */
class ReasoningEngine {

    fun evaluate(prompt: String, langCode: String): ReasoningResult {
        val cleaned = extractExpressionCandidate(prompt)
        if (cleaned != null) {
            // Check simple linear equation like "2x + 4 = 10" or "3*x - 5 = 16"
            val linearResult = trySolveLinearEquation(cleaned, langCode)
            if (linearResult != null) return linearResult

            // Evaluate pure arithmetic / function expression
            val exprResult = tryEvaluateExpression(cleaned)
            if (exprResult != null) {
                val (value, trace) = exprResult
                val formatted = formatNumber(value)
                val responseText = when (langCode) {
                    "tr" -> "Doğrulanmış Hesaplama Sonucu: $cleaned = $formatted"
                    "de" -> "Verifiziertes Berechnungsergebnis: $cleaned = $formatted"
                    "fr" -> "Résultat de calcul vérifié : $cleaned = $formatted"
                    "es" -> "Resultado de cálculo verificado: $cleaned = $formatted"
                    else -> "Verified Computation Result: $cleaned = $formatted"
                }
                return ReasoningResult(
                    answer = responseText,
                    verificationStatus = VerificationStatus.VERIFIED_COMPUTATION,
                    verificationSummary = "Deterministic recursive-descent AST evaluation + arithmetic check passed.",
                    steps = trace + "Result = $formatted"
                )
            }
        }

        // Check simple boolean / comparison expression
        val logicResult = tryEvaluateComparison(prompt)
        if (logicResult != null) return logicResult

        val fallback = when (langCode) {
            "tr" -> "Bu akıl yürütme isteği sembolik/sayısal bir ifadeye indirgenemedi. Faz 1 CPU çekirdeği yalnızca deterministik matematik ve mantık ifadelerini doğrular; açık uçlu akıl yürütme için Faz 2 açık-ağırlıklı çıkarım modeli veya uzak FastAPI sunucusu gereklidir."
            "de" -> "Diese Anfrage konnte nicht auf einen deterministischen mathematischen/logischen Ausdruck reduziert werden. Die Phase-1-CPU-Basis verifiziert nur exakte Ausdrücke."
            "fr" -> "Cette requête n'a pas pu être réduite à une expression mathématique ou logique déterministe. Le noyau CPU Phase 1 ne vérifie que les calculs exacts."
            "es" -> "Esta solicitud no pudo reducirse a una expresión matemática o lógica determinista. La base CPU Fase 1 solo verifica cálculos exactos."
            else -> "Could not reduce this prompt to a deterministic mathematical or logical expression. GENIX Phase 1 CPU foundation only marks exact AST computations as VERIFIED; open-ended reasoning requires a loaded Phase 2 open-weight model or remote FastAPI runtime."
        }
        return ReasoningResult(
            answer = fallback,
            verificationStatus = VerificationStatus.UNSUPPORTED_CAPABILITY,
            verificationSummary = "No deterministic proof or symbolic expression matched; refused to fabricate verification.",
            steps = listOf("Input parsed -> no closed-form arithmetic/logic AST found.")
        )
    }

    fun isMathematicalOrLogical(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT)
        if (extractExpressionCandidate(prompt) != null) return true
        if (Regex("\\b(calculate|solve|compute|equation|math|hesapla|çöz|denklem|berechne|calculer|calcular)\\b").containsMatchIn(lower)) {
            return true
        }
        return Regex("\\d+\\s*[+\\-*/^=<>]\\s*\\d+").containsMatchIn(lower)
    }

    private fun extractExpressionCandidate(prompt: String): String? {
        // Strip leading phrases like "calculate", "hesapla:", "what is", etc.
        var candidate = prompt.trim()
        val prefixRegex = Regex(
            "^(calculate|compute|solve|evaluate|what is|hesapla|çöz|berechne|calculer|calcular)\\s*[:?]?\\s*",
            RegexOption.IGNORE_CASE
        )
        candidate = candidate.replace(prefixRegex, "").trim()
        candidate = candidate.trimEnd('?', '.', ' ')

        // Also support inline math substring if prompt wraps a formula
        if (Regex("^[0-9xX+\\-*/^().=\\s,sqrtabspow]+$").matches(candidate) &&
            Regex("[0-9]").containsMatchIn(candidate) &&
            Regex("[+\\-*/^=]|sqrt|abs|pow").containsMatchIn(candidate)
        ) {
            return candidate
        }

        val inlineMatch = Regex("([0-9]+(?:\\.[0-9]+)?(?:\\s*[+\\-*/^()]\\s*[0-9.()]+)+)").find(prompt)
        return inlineMatch?.groupValues?.getOrNull(1)?.trim()
    }

    private fun trySolveLinearEquation(expr: String, langCode: String): ReasoningResult? {
        if (!expr.contains("=") || !expr.contains("x", ignoreCase = true)) return null
        val parts = expr.split("=")
        if (parts.size != 2) return null

        // Parse simple form ax + b = c by evaluating LHS at x=0 and x=1 (linear test)
        val lhs = parts[0].trim()
        val rhs = parts[1].trim()
        val rhsVal = tryEvaluateExpression(rhs)?.first ?: return null

        val lhsAt0 = tryEvaluateExpression(lhs.replace(Regex("[xX]"), "(0)"))?.first ?: return null
        val lhsAt1 = tryEvaluateExpression(lhs.replace(Regex("[xX]"), "(1)"))?.first ?: return null
        val lhsAt2 = tryEvaluateExpression(lhs.replace(Regex("[xX]"), "(2)"))?.first ?: return null

        val slope1 = lhsAt1 - lhsAt0
        val slope2 = lhsAt2 - lhsAt1
        if (abs(slope1 - slope2) > 1e-6 || abs(slope1) < 1e-9) return null

        val xValue = (rhsVal - lhsAt0) / slope1
        // Independent verification check
        val checkLhs = slope1 * xValue + lhsAt0
        if (abs(checkLhs - rhsVal) > 1e-6) return null

        val formattedX = formatNumber(xValue)
        val answer = when (langCode) {
            "tr" -> "Doğrulanmış Denklem Çözümü: $expr → x = $formattedX (Sağlama: ${formatNumber(checkLhs)} = ${formatNumber(rhsVal)})"
            else -> "Verified Linear Solution: $expr → x = $formattedX (Check: ${formatNumber(checkLhs)} = ${formatNumber(rhsVal)})"
        }
        return ReasoningResult(
            answer = answer,
            verificationStatus = VerificationStatus.VERIFIED_COMPUTATION,
            verificationSummary = "Linear equation solved and back-substituted (|LHS - RHS| < 1e-6).",
            steps = listOf(
                "Parsed equation: $lhs = $rhs",
                "Identified linear coefficient a = ${formatNumber(slope1)}, intercept b = ${formatNumber(lhsAt0)}",
                "Solved x = (${formatNumber(rhsVal)} - ${formatNumber(lhsAt0)}) / ${formatNumber(slope1)} = $formattedX",
                "Back-substitution check passed."
            )
        )
    }

    private fun tryEvaluateComparison(prompt: String): ReasoningResult? {
        val match = Regex("^\\s*([-+]?[0-9]+(?:\\.[0-9]+)?)\\s*(>=|<=|==|!=|>|<)\\s*([-+]?[0-9]+(?:\\.[0-9]+)?)\\s*\\??\\s*$")
            .find(prompt) ?: return null
        val a = match.groupValues[1].toDoubleOrNull() ?: return null
        val op = match.groupValues[2]
        val b = match.groupValues[3].toDoubleOrNull() ?: return null
        val result = when (op) {
            ">" -> a > b
            "<" -> a < b
            ">=" -> a >= b
            "<=" -> a <= b
            "==" -> abs(a - b) < 1e-9
            "!=" -> abs(a - b) >= 1e-9
            else -> return null
        }
        return ReasoningResult(
            answer = "Verified Comparison: ${formatNumber(a)} $op ${formatNumber(b)} → $result",
            verificationStatus = VerificationStatus.VERIFIED_COMPUTATION,
            verificationSummary = "Direct numeric predicate evaluation passed.",
            steps = listOf("Evaluated ${formatNumber(a)} $op ${formatNumber(b)} = $result")
        )
    }

    fun tryEvaluateExpression(expr: String): Pair<Double, List<String>>? {
        return runCatching {
            val parser = ExpressionParser(expr)
            val value = parser.parseExpression()
            if (!parser.isAtEnd() || value.isNaN() || value.isInfinite()) return null
            value to parser.trace
        }.getOrNull()
    }

    private fun formatNumber(value: Double): String {
        val rounded = value.toLong()
        return if (abs(value - rounded.toDouble()) < 1e-9) {
            rounded.toString()
        } else {
            String.format(Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
        }
    }

    private class ExpressionParser(private val input: String) {
        private var pos = 0
        val trace = mutableListOf<String>()

        fun isAtEnd(): Boolean {
            skipWhitespace()
            return pos >= input.length
        }

        private fun skipWhitespace() {
            while (pos < input.length && input[pos].isWhitespace()) pos++
        }

        private fun peek(): Char? {
            skipWhitespace()
            return if (pos < input.length) input[pos] else null
        }

        private fun consume(expected: Char): Boolean {
            skipWhitespace()
            if (pos < input.length && input[pos] == expected) {
                pos++
                return true
            }
            return false
        }

        fun parseExpression(): Double {
            var left = parseTerm()
            while (true) {
                when {
                    consume('+') -> {
                        val right = parseTerm()
                        val res = left + right
                        trace.add("${left.toCompactStr()} + ${right.toCompactStr()} = ${res.toCompactStr()}")
                        left = res
                    }
                    consume('-') -> {
                        val right = parseTerm()
                        val res = left - right
                        trace.add("${left.toCompactStr()} - ${right.toCompactStr()} = ${res.toCompactStr()}")
                        left = res
                    }
                    else -> return left
                }
            }
        }

        private fun parseTerm(): Double {
            var left = parsePower()
            while (true) {
                when {
                    consume('*') -> {
                        val right = parsePower()
                        val res = left * right
                        trace.add("${left.toCompactStr()} * ${right.toCompactStr()} = ${res.toCompactStr()}")
                        left = res
                    }
                    consume('/') -> {
                        val right = parsePower()
                        require(abs(right) > 1e-12) { "Division by zero" }
                        val res = left / right
                        trace.add("${left.toCompactStr()} / ${right.toCompactStr()} = ${res.toCompactStr()}")
                        left = res
                    }
                    consume('%') -> {
                        val right = parsePower()
                        require(abs(right) > 1e-12) { "Modulo by zero" }
                        val res = left % right
                        trace.add("${left.toCompactStr()} % ${right.toCompactStr()} = ${res.toCompactStr()}")
                        left = res
                    }
                    else -> return left
                }
            }
        }

        private fun parsePower(): Double {
            val base = parseUnary()
            return if (consume('^')) {
                val exp = parsePower()
                val res = base.pow(exp)
                trace.add("${base.toCompactStr()} ^ ${exp.toCompactStr()} = ${res.toCompactStr()}")
                res
            } else {
                base
            }
        }

        private fun parseUnary(): Double {
            return when {
                consume('+') -> parseUnary()
                consume('-') -> -parseUnary()
                else -> parsePrimary()
            }
        }

        private fun parsePrimary(): Double {
            if (consume('(')) {
                val inner = parseExpression()
                require(consume(')')) { "Unclosed parenthesis" }
                return inner
            }
            skipWhitespace()
            if (pos < input.length && input[pos].isLetter()) {
                val start = pos
                while (pos < input.length && input[pos].isLetter()) pos++
                val fn = input.substring(start, pos).lowercase(Locale.ROOT)
                require(consume('(')) { "Expected '(' after function $fn" }
                val arg1 = parseExpression()
                return when (fn) {
                    "sqrt" -> {
                        require(consume(')')) { "Expected ')'" }
                        require(arg1 >= 0) { "Negative sqrt" }
                        sqrt(arg1).also { trace.add("sqrt(${arg1.toCompactStr()}) = ${it.toCompactStr()}") }
                    }
                    "abs" -> {
                        require(consume(')')) { "Expected ')'" }
                        abs(arg1).also { trace.add("abs(${arg1.toCompactStr()}) = ${it.toCompactStr()}") }
                    }
                    "pow" -> {
                        require(consume(',')) { "Expected ',' in pow(a,b)" }
                        val arg2 = parseExpression()
                        require(consume(')')) { "Expected ')'" }
                        arg1.pow(arg2).also { trace.add("pow(${arg1.toCompactStr()}, ${arg2.toCompactStr()}) = ${it.toCompactStr()}") }
                    }
                    else -> throw IllegalArgumentException("Unknown function: $fn")
                }
            }

            val start = pos
            while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
            require(pos > start) { "Unexpected token at $pos" }
            val numStr = input.substring(start, pos)
            val num = numStr.toDouble()
            // Implicit multiplication like 2(3+4)
            if (peek() == '(') {
                val right = parsePrimary()
                return (num * right).also { trace.add("${num.toCompactStr()} * ${right.toCompactStr()} = ${it.toCompactStr()}") }
            }
            return num
        }

        private fun Double.toCompactStr(): String {
            val r = toLong()
            return if (abs(this - r.toDouble()) < 1e-9) r.toString()
            else String.format(Locale.US, "%.4f", this).trimEnd('0').trimEnd('.')
        }
    }
}
