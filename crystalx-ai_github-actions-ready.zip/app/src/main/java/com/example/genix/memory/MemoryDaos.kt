package com.example.genix.memory

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ShortTermMemoryDao {
    @Query("SELECT * FROM short_term_messages WHERE sessionId = :sessionId ORDER BY timestampMs ASC, id ASC")
    fun observeMessages(sessionId: String): Flow<List<ShortTermMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(msg: ShortTermMessageEntity)

    @Query("DELETE FROM short_term_messages WHERE sessionId = :sessionId")
    suspend fun clearSession(sessionId: String)
}

@Dao
interface LongTermMemoryDao {
    @Query("SELECT * FROM long_term_memories WHERE userId = :userId ORDER BY updatedAtMs DESC")
    fun observeMemories(userId: String): Flow<List<LongTermMemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(memory: LongTermMemoryEntity)

    @Query("DELETE FROM long_term_memories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM long_term_memories WHERE expiresAtMs IS NOT NULL AND expiresAtMs < :nowMs")
    suspend fun purgeExpired(nowMs: Long)
}

@Dao
interface KnowledgeMemoryDao {
    @Query("SELECT * FROM knowledge_documents WHERE userId = :userId ORDER BY createdAtMs DESC")
    fun observeDocuments(userId: String): Flow<List<KnowledgeDocumentEntity>>

    @Query("SELECT * FROM knowledge_documents WHERE userId = :userId")
    suspend fun getAllDocumentsOnce(userId: String): List<KnowledgeDocumentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: KnowledgeDocumentEntity)

    @Query("DELETE FROM knowledge_documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Long)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestampMs DESC LIMIT 200")
    fun observeRecentLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)

    @Query("DELETE FROM audit_logs")
    suspend fun clearAll()
}

@Dao
interface GeneratedImageDao {
    @Query("SELECT * FROM generated_images WHERE userId = :userId ORDER BY createdAtMs DESC LIMIT 60")
    fun observeForUser(userId: String): Flow<List<GeneratedImageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: GeneratedImageEntity): Long

    @Query("DELETE FROM generated_images WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM generated_images WHERE userId = :userId")
    suspend fun clearForUser(userId: String)
}

@Dao
interface DocumentArtifactDao {
    @Query("SELECT * FROM document_artifacts WHERE userId = :userId ORDER BY createdAtMs DESC LIMIT 40")
    fun observeForUser(userId: String): Flow<List<DocumentArtifactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: DocumentArtifactEntity): Long

    @Query("DELETE FROM document_artifacts WHERE id = :id")
    suspend fun deleteById(id: Long)
}
