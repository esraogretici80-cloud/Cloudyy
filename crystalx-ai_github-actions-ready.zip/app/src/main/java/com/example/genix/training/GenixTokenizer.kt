package com.example.genix.training

import java.nio.charset.StandardCharsets

data class TokenInspectionItem(
    val tokenId: Int,
    val tokenText: String,
    val isByteFallback: Boolean
)

data class TokenizationReport(
    val inputLengthChars: Int,
    val utf8ByteCount: Int,
    val tokenIds: List<Int>,
    val tokens: List<TokenInspectionItem>,
    val decodedText: String,
    val roundTripExactMatch: Boolean,
    val compressionRatio: Float
)

/**
 * GENIX Base — Phase A Independent Unicode Tokenizer (Version 1.0.0-alpha).
 *
 * Combines:
 * 1. Reserved control tokens (<pad>, <bos>, <eos>, <unk>, <sys>, <usr>, <ast>)
 * 2. Multilingual subword vocabulary (Turkish, English, technical/code stems)
 * 3. Lossless UTF-8 byte fallback (<0x00>..<0xFF>) guaranteeing 100% reversible decoding
 *    for Turkish (çğıöşüÇĞİÖŞÜ), Arabic, Japanese, Chinese, emojis, and arbitrary Unicode.
 */
class GenixTokenizer {

    val version: String = "genix-tok-v1.0-unicode-bpe-hybrid"

    private val specialTokens = listOf(
        "<pad>", "<bos>", "<eos>", "<unk>", "<sys>", "<usr>", "<ast>"
    )

    // Curated multilingual + code subwords sorted longest-first for greedy BPE-style matching
    private val subwordVocab = listOf(
        "genix", "fastapi", "pytorch", "postgresql", "pgvector", "transformers",
        "merhaba", "nasılsın", "teşekkür", "yardımcı", "doğrulanmış", "türkçe",
        "çekirdek", "bağımsız", "model", "router", "memory", "engine", "system",
        "python", "kotlin", "docker", "config", "health", "status", "server",
        "hello", "world", "please", "create", "verify", "analyze", "request",
        "response", "token", "layer", "weight", "train", "eval", "async",
        "class", "return", "import", "struct", "print", "function", "const",
        "bir", "ve", "ile", "için", "olarak", "bu", "nasıl", "nedir", "evet", "hayır",
        "the", "and", "for", "with", "that", "this", "from", "into", "not",
        "der", "die", "das", "und", "für", "wie", "bonjour", "merci", "hola",
        "tion", "ing", "lar", "ler", "yor", "mek", "mak", "lık", "lik", "da", "de",
        "   ", "  ", "->", "==", "!=", ">=", "<=", "://", "\n"
    ).distinct().sortedByDescending { it.length }

    private val idToToken = mutableMapOf<Int, String>()
    private val tokenToId = mutableMapOf<String, Int>()
    private val byteOffset = specialTokens.size // 7..262 are raw UTF-8 bytes 0..255

    init {
        var idx = 0
        for (st in specialTokens) {
            idToToken[idx] = st
            tokenToId[st] = idx
            idx++
        }
        for (b in 0..255) {
            val label = "<0x${b.toString(16).uppercase().padStart(2, '0')}>"
            idToToken[idx] = label
            tokenToId[label] = idx
            idx++
        }
        for (sub in subwordVocab) {
            idToToken[idx] = sub
            tokenToId[sub] = idx
            idx++
        }
    }

    val vocabSize: Int get() = idToToken.size

    fun inspectVocabulary(limit: Int = 80): List<Pair<Int, String>> {
        return idToToken.entries
            .sortedBy { it.key }
            .take(limit)
            .map { it.key to it.value }
    }

    fun encode(text: String, addBosEos: Boolean = false): List<Int> {
        val ids = mutableListOf<Int>()
        if (addBosEos) ids.add(tokenToId.getValue("<bos>"))

        var i = 0
        while (i < text.length) {
            var matchedSub: String? = null
            // Match subword only if ASCII/Turkish exact substring matches cleanly
            for (sub in subwordVocab) {
                if (i + sub.length <= text.length && text.regionMatches(i, sub, 0, sub.length, ignoreCase = false)) {
                    matchedSub = sub
                    break
                }
            }
            if (matchedSub != null) {
                ids.add(tokenToId.getValue(matchedSub))
                i += matchedSub.length
            } else {
                // Consume one Unicode code point and encode its UTF-8 bytes losslessly
                val cp = text.codePointAt(i)
                val charCount = Character.charCount(cp)
                val slice = text.substring(i, i + charCount)
                val bytes = slice.toByteArray(StandardCharsets.UTF_8)
                for (b in bytes) {
                    val unsigned = b.toInt() and 0xFF
                    ids.add(byteOffset + unsigned)
                }
                i += charCount
            }
        }

        if (addBosEos) ids.add(tokenToId.getValue("<eos>"))
        return ids
    }

    fun decode(ids: List<Int>): String {
        val sb = StringBuilder()
        val pendingBytes = mutableListOf<Byte>()

        fun flushBytes() {
            if (pendingBytes.isNotEmpty()) {
                sb.append(String(pendingBytes.toByteArray(), StandardCharsets.UTF_8))
                pendingBytes.clear()
            }
        }

        for (id in ids) {
            when {
                id in 0 until specialTokens.size -> {
                    flushBytes()
                    // Skip control tokens in plain text decode
                }
                id in byteOffset until (byteOffset + 256) -> {
                    pendingBytes.add((id - byteOffset).toByte())
                }
                else -> {
                    flushBytes()
                    sb.append(idToToken[id] ?: "<unk>")
                }
            }
        }
        flushBytes()
        return sb.toString()
    }

    fun analyze(text: String): TokenizationReport {
        val ids = encode(text, addBosEos = false)
        val decoded = decode(ids)
        val utf8Bytes = text.toByteArray(StandardCharsets.UTF_8).size
        val items = ids.map { id ->
            val label = idToToken[id] ?: "<unk>"
            val isByte = id in byteOffset until (byteOffset + 256)
            TokenInspectionItem(
                tokenId = id,
                tokenText = if (label == "\n") "\\n" else label,
                isByteFallback = isByte
            )
        }
        val ratio = if (ids.isEmpty()) 1f else utf8Bytes.toFloat() / ids.size.toFloat()
        return TokenizationReport(
            inputLengthChars = text.length,
            utf8ByteCount = utf8Bytes,
            tokenIds = ids,
            tokens = items,
            decodedText = decoded,
            roundTripExactMatch = decoded == text,
            compressionRatio = ratio
        )
    }
}
