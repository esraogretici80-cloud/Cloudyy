package com.example.genix.ai.core

import android.graphics.Bitmap
import com.example.genix.core.ModelAccessScope
import com.example.genix.core.ResponseStyle
import com.example.genix.firebase.CrystalXModelId
import com.example.genix.intelligence.language.CountrySupport
import kotlinx.coroutines.flow.Flow

enum class AiModelCategory(val displayName: String, val badge: String) {
    GENERAL_AI("General AI", "GENERAL"),
    ADVANCED_REASONING("Advanced Reasoning", "REASONING"),
    FAST_RESPONSES("Fast Responses", "FAST"),
    CODING("Coding", "CODE"),
    CREATIVE_WRITING("Creative Writing", "CREATIVE"),
    IMAGE_UNDERSTANDING("Image Understanding", "VISION"),
    IMAGE_GENERATION("Image Generation", "IMAGE GEN"),
    REALTIME_VOICE("Real-Time Voice", "VOICE"),
    MULTIMODAL_AI("Multimodal AI", "MULTIMODAL")
}

enum class AiProviderKind(
    val id: String,
    val displayName: String,
    val defaultBaseUrl: String,
    val requiresByokKey: Boolean,
    val docsHint: String
) {
    CLOUDY_FIREBASE(
        id = "cloudy_firebase",
        displayName = "Cloudy Firebase AI",
        defaultBaseUrl = "firebase://ai-logic",
        requiresByokKey = false,
        docsHint = "Zero-key Firebase AI Logic + App Check"
    ),
    CLOUDY_LOCAL(
        id = "cloudy_local",
        displayName = "Cloudy Local CPU",
        defaultBaseUrl = "local://cpu",
        requiresByokKey = false,
        docsHint = "Deterministic offline AST, math & Unicode tokenizer"
    ),
    OPENAI(
        id = "openai",
        displayName = "OpenAI",
        defaultBaseUrl = "https://api.openai.com/v1",
        requiresByokKey = true,
        docsHint = "GPT-4o / o3-mini / GPT-4.1 via OpenAI API"
    ),
    ANTHROPIC(
        id = "anthropic",
        displayName = "Anthropic Claude",
        defaultBaseUrl = "https://api.anthropic.com/v1",
        requiresByokKey = true,
        docsHint = "Claude Sonnet / Haiku / Opus Messages API"
    ),
    DEEPSEEK(
        id = "deepseek",
        displayName = "DeepSeek",
        defaultBaseUrl = "https://api.deepseek.com/v1",
        requiresByokKey = true,
        docsHint = "DeepSeek Chat & R1 Reasoner"
    ),
    META_LLAMA(
        id = "meta_llama",
        displayName = "Meta Llama (Groq/OpenAI)",
        defaultBaseUrl = "https://api.groq.com/openai/v1",
        requiresByokKey = true,
        docsHint = "Llama 3.3 70B / Llama 4 via OpenAI-compatible API"
    ),
    QWEN(
        id = "qwen",
        displayName = "Qwen (DashScope)",
        defaultBaseUrl = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
        requiresByokKey = true,
        docsHint = "Qwen Max / Qwen Coder Plus OpenAI-compatible"
    ),
    MISTRAL(
        id = "mistral",
        displayName = "Mistral AI",
        defaultBaseUrl = "https://api.mistral.ai/v1",
        requiresByokKey = true,
        docsHint = "Mistral Large / Codestral"
    ),
    REMOTE_FASTAPI(
        id = "remote_fastapi",
        displayName = "Self-Hosted FastAPI",
        defaultBaseUrl = "http://10.0.2.2:8000",
        requiresByokKey = false,
        docsHint = "Your private vLLM / Ollama / FastAPI endpoint"
    )
}

enum class SpeedTier(val label: String, val score: Float) {
    INSTANT("Instant (<15ms)", 1.0f),
    TURBO("Ultra Fast", 0.92f),
    BALANCED("Balanced", 0.78f),
    DEEP("Deep Compute", 0.56f),
    SYNTHESIS("Multi-Pass", 0.42f)
}

enum class ModelAvailabilityStatus(val badge: String) {
    READY("READY"),
    KEY_REQUIRED("API KEY NEEDED"),
    PLAN_LOCKED("PLAN UPGRADE"),
    REMOTE_CONFIG_NEEDED("ENDPOINT NEEDED")
}

data class ModelCapabilities(
    val streaming: Boolean = true,
    val visionInput: Boolean = false,
    val imageGeneration: Boolean = false,
    val realtimeAudio: Boolean = false,
    val documentAnalysis: Boolean = true,
    val codingSpecialty: Boolean = false,
    val reasoningSpecialty: Boolean = false,
    val webGroundedReady: Boolean = true
)

data class ModelSettings(
    val temperature: Float = 0.65f,
    val topP: Float = 0.92f,
    val maxOutputTokens: Int = 4096
)

interface AIModel {
    val id: String
    val upstreamModelName: String
    val displayName: String
    val shortBadge: String
    val provider: AiProviderKind
    val category: AiModelCategory
    val secondaryCategories: List<AiModelCategory>
    val capabilities: ModelCapabilities
    val speedTier: SpeedTier
    val contextWindowTokens: Int?
    val description: String
    val accessScope: ModelAccessScope
    val legacyCrystalId: CrystalXModelId?
    val defaultSettings: ModelSettings
    val isDynamicFetched: Boolean
}

data class CloudyAiModel(
    override val id: String,
    override val upstreamModelName: String,
    override val displayName: String,
    override val shortBadge: String,
    override val provider: AiProviderKind,
    override val category: AiModelCategory,
    override val secondaryCategories: List<AiModelCategory> = emptyList(),
    override val capabilities: ModelCapabilities,
    override val speedTier: SpeedTier,
    override val contextWindowTokens: Int?,
    override val description: String,
    override val accessScope: ModelAccessScope = ModelAccessScope.SHARED,
    override val legacyCrystalId: CrystalXModelId? = null,
    override val defaultSettings: ModelSettings = ModelSettings(),
    override val isDynamicFetched: Boolean = false
) : AIModel

data class WebCitationSource(
    val title: String,
    val url: String,
    val snippet: String,
    val domain: String
)

data class NormalizedAiRequest(
    val model: AIModel,
    val prompt: String,
    val attachedImages: List<Bitmap> = emptyList(),
    val documentContext: String? = null,
    val webCitations: List<WebCitationSource> = emptyList(),
    val historyTurns: List<Pair<String, String>> = emptyList(),
    val pinnedContextNotes: List<String> = emptyList(),
    val integrationNotes: List<String> = emptyList(),
    val responseLanguageCode: String,
    val country: CountrySupport?,
    val responseStyle: ResponseStyle = ResponseStyle.BALANCED,
    val customInstructions: String = "",
    val codingMode: Boolean = false,
    val localVerifiedNote: String? = null,
    val overrideSettings: ModelSettings? = null
)

sealed interface NormalizedAiChunk {
    data class Delta(
        val accumulatedText: String,
        val modelLabel: String,
        val providerName: String
    ) : NormalizedAiChunk

    data class Completed(
        val finalText: String,
        val modelLabel: String,
        val latencyMs: Long,
        val citations: List<WebCitationSource> = emptyList(),
        val isVerifiedLocal: Boolean = false
    ) : NormalizedAiChunk

    data class Failure(
        val message: String,
        val isAppCheckError: Boolean = false,
        val isAuthError: Boolean = false
    ) : NormalizedAiChunk
}

interface ModelProvider {
    val providerKind: AiProviderKind
    suspend fun isConfigured(): Boolean
    fun streamGenerate(request: NormalizedAiRequest): Flow<NormalizedAiChunk>
    suspend fun fetchAvailableModels(): Result<List<CloudyAiModel>> = Result.success(emptyList())
}
