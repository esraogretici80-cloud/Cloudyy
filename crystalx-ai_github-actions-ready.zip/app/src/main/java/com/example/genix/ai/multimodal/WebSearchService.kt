package com.example.genix.ai.multimodal

import com.example.genix.ai.core.WebCitationSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Lightweight real-time Web Grounding & Citation Search Service.
 * Queries DuckDuckGo Instant Answer API and Wikipedia REST Search API in parallel/fallback
 * to provide real web references when Web Search mode is enabled in chat.
 */
class WebSearchService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String, languageCode: String = "en", maxResults: Int = 4): List<WebCitationSource> =
        withContext(Dispatchers.IO) {
            val cleanQuery = query.trim()
            if (cleanQuery.isBlank()) return@withContext emptyList()

            val results = mutableListOf<WebCitationSource>()

            // 1. DuckDuckGo Instant Answer JSON
            runCatching {
                val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                val ddgReq = Request.Builder()
                    .url("https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1")
                    .addHeader("User-Agent", "CloudyAI-Android/2.0")
                    .build()
                client.newCall(ddgReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = JSONObject(resp.body?.string().orEmpty())
                        val abstractText = json.optString("AbstractText").trim()
                        val abstractUrl = json.optString("AbstractURL").trim()
                        val heading = json.optString("Heading").trim().ifBlank { cleanQuery }
                        if (abstractText.isNotBlank() && abstractUrl.isNotBlank()) {
                            results.add(
                                WebCitationSource(
                                    title = heading,
                                    url = abstractUrl,
                                    snippet = abstractText.take(280),
                                    domain = extractDomain(abstractUrl)
                                )
                            )
                        }
                        val related = json.optJSONArray("RelatedTopics")
                        if (related != null) {
                            for (i in 0 until minOf(related.length(), 4)) {
                                val obj = related.optJSONObject(i) ?: continue
                                val text = obj.optString("Text").trim()
                                val firstUrl = obj.optString("FirstURL").trim()
                                if (text.isNotBlank() && firstUrl.isNotBlank()) {
                                    results.add(
                                        WebCitationSource(
                                            title = text.substringBefore(" - ").take(72),
                                            url = firstUrl,
                                            snippet = text.take(240),
                                            domain = extractDomain(firstUrl)
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Wikipedia OpenSearch / Query API (multilingual)
            if (results.size < maxResults) {
                runCatching {
                    val wikiLang = when (languageCode) {
                        "tr", "de", "fr", "es", "it", "pt", "ru", "ar", "ja", "ko", "zh", "pl", "nl", "id" -> languageCode
                        else -> "en"
                    }
                    val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
                    val wikiReq = Request.Builder()
                        .url("https://$wikiLang.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&srlimit=3&utf8=&format=json")
                        .addHeader("User-Agent", "CloudyAI-Android/2.0")
                        .build()
                    client.newCall(wikiReq).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val json = JSONObject(resp.body?.string().orEmpty())
                            val searchArr = json.optJSONObject("query")?.optJSONArray("search")
                            if (searchArr != null) {
                                for (i in 0 until searchArr.length()) {
                                    val item = searchArr.optJSONObject(i) ?: continue
                                    val title = item.optString("title").trim()
                                    val rawSnippet = item.optString("snippet")
                                        .replace(Regex("<[^>]+>"), "")
                                        .replace("&quot;", "\"")
                                        .replace("&amp;", "&")
                                        .trim()
                                    if (title.isNotBlank()) {
                                        val slug = URLEncoder.encode(title.replace(" ", "_"), "UTF-8")
                                        val pageUrl = "https://$wikiLang.wikipedia.org/wiki/$slug"
                                        results.add(
                                            WebCitationSource(
                                                title = title,
                                                url = pageUrl,
                                                snippet = rawSnippet.take(240),
                                                domain = "$wikiLang.wikipedia.org"
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            results.distinctBy { it.url }.take(maxResults)
        }

    private fun extractDomain(url: String): String =
        url.removePrefix("https://").removePrefix("http://").substringBefore('/').ifBlank { "web" }
}
