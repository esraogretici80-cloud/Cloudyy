package com.example.genix.firebase

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.recaptcha.RecaptchaAppCheckProviderFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

private const val TAG = "AppCheckInit"

// App Check contract keys defined by Firebase SDK and AI Studio runtime harness
private const val DEBUG_TOKEN_EXTRA = "FIREBASE_APPCHECK_DEBUG_TOKEN"
private const val DEBUG_TOKEN_EXTRA_ALT = "firebase_appcheck_debug_token"
private const val DEBUG_STORE_PREFIX = "com.google.firebase.appcheck.debug.store."
private const val DEBUG_SECRET_KEY = "com.google.firebase.appcheck.debug.DEBUG_SECRET"
private const val HARNESS_VERIFIED_PREF_KEY = "cloudy_harness_debug_secret_present"
private const val RECAPTCHA_SITE_KEY_RES = "recaptcha_site_key"

data class AppCheckDiagnostics(
    val mode: String = if (BuildConfig.DEBUG) "DEBUG_PROVIDER" else "RECAPTCHA_ENTERPRISE",
    val tokenInjectedFromIntent: Boolean = false,
    val providerInstalled: Boolean = false,
    val tokenVerified: Boolean = false,
    val debugTokenPreview: String = "",
    val fullDebugSecret: String = "",
    val statusNote: String = "Güvenlik doğrulaması hazırlanıyor..."
)

/**
 * Single owner of Firebase App Check setup.
 *
 * Debug builds always use the Debug provider with a deterministic secret:
 *  1. token injected by the AI Studio harness via launch Intent, else
 *  2. a token the user applied manually in Settings, else
 *  3. the fixed token baked into the debug APK (BuildConfig.APPCHECK_DEBUG_TOKEN).
 * Using a fixed secret means one registration in Firebase Console covers every device,
 * instead of the SDK generating a random (unregistered → 403) UUID per install.
 *
 * Release builds use reCAPTCHA Enterprise. Failures are never surfaced as blocking UI;
 * callers retry once after [refreshTokenNow].
 */
object AppCheckCoordinator {
    private val lock = Any()

    @Volatile
    private var installedMode: String? = null

    @Volatile
    private var installedSecret: String? = null

    private val _diagnostics = MutableStateFlow(AppCheckDiagnostics())
    val diagnostics: StateFlow<AppCheckDiagnostics> = _diagnostics.asStateFlow()

    private fun isRobolectric(): Boolean =
        Build.FINGERPRINT.equals("robolectric", ignoreCase = true)

    private fun extractDebugToken(intent: Intent?): String? {
        if (intent == null) return null
        val direct = intent.getStringExtra(DEBUG_TOKEN_EXTRA)
            ?: intent.getStringExtra(DEBUG_TOKEN_EXTRA_ALT)
        if (!direct.isNullOrBlank()) {
            return direct.trim().removeSurrounding("\"")
        }
        val extras = intent.extras ?: return null
        for (key in extras.keySet()) {
            if (key.equals(DEBUG_TOKEN_EXTRA, ignoreCase = true)) {
                val raw = extras.getString(key)
                if (!raw.isNullOrBlank()) {
                    return raw.trim().removeSurrounding("\"")
                }
            }
        }
        return null
    }

    private fun resolveRecaptchaSiteKey(context: Context): String? {
        val resId = context.resources.getIdentifier(RECAPTCHA_SITE_KEY_RES, "string", context.packageName)
        if (resId == 0) return null
        return context.getString(resId).trim().takeIf { it.isNotBlank() }
    }

    private fun ensureFirebase(context: Context): FirebaseApp {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }
        return FirebaseApp.getInstance()
    }

    private fun debugPrefs(context: Context, app: FirebaseApp) =
        context.getSharedPreferences("$DEBUG_STORE_PREFIX${app.persistenceKey}", Context.MODE_PRIVATE)

    private fun metaPrefs(context: Context, app: FirebaseApp) =
        context.getSharedPreferences("cloudy_appcheck_meta_${app.persistenceKey}", Context.MODE_PRIVATE)

    fun configure(context: Context, intent: Intent?) {
        synchronized(lock) {
            try {
                val app = ensureFirebase(context)
                val appCheck = FirebaseAppCheck.getInstance()

                if (BuildConfig.DEBUG) {
                    val prefs = debugPrefs(context, app)
                    val meta = metaPrefs(context, app)

                    val fromIntent = extractDebugToken(intent)
                    val manualOrHarness = if (meta.getBoolean(HARNESS_VERIFIED_PREF_KEY, false)) {
                        prefs.getString(DEBUG_SECRET_KEY, null)?.takeIf { it.isNotBlank() }
                    } else null
                    val baked = BuildConfig.APPCHECK_DEBUG_TOKEN.trim().takeIf { it.isNotBlank() }

                    val secret = fromIntent ?: manualOrHarness ?: baked
                    if (!secret.isNullOrBlank()) {
                        // Synchronous commit() is mandatory before DebugAppCheckProviderFactory reads SharedPreferences
                        prefs.edit().putString(DEBUG_SECRET_KEY, secret).commit()
                        if (fromIntent != null) {
                            meta.edit().putBoolean(HARNESS_VERIFIED_PREF_KEY, true).commit()
                        }
                    }

                    val needsInstall = installedMode != "DEBUG_PROVIDER" || installedSecret != secret
                    if (needsInstall) {
                        appCheck.installAppCheckProviderFactory(DebugAppCheckProviderFactory.getInstance())
                        appCheck.setTokenAutoRefreshEnabled(true)
                        installedMode = "DEBUG_PROVIDER"
                        installedSecret = secret
                        Log.d(TAG, "Debug App Check provider installed (source=${
                            when {
                                fromIntent != null -> "intent"
                                manualOrHarness != null -> "saved"
                                baked != null -> "build"
                                else -> "sdk"
                            }
                        }).")
                    }

                    val active = prefs.getString(DEBUG_SECRET_KEY, "").orEmpty()
                    _diagnostics.value = AppCheckDiagnostics(
                        mode = "DEBUG_PROVIDER",
                        tokenInjectedFromIntent = fromIntent != null || manualOrHarness != null,
                        providerInstalled = true,
                        tokenVerified = false,
                        debugTokenPreview = maskToken(active),
                        fullDebugSecret = active,
                        statusNote = "Güvenlik doğrulaması yapılıyor..."
                    )
                    if (!isRobolectric()) {
                        probeAppCheckExchange(context, forceRefresh = needsInstall)
                    }
                } else {
                    val siteKey = resolveRecaptchaSiteKey(context)
                    if (!siteKey.isNullOrBlank()) {
                        if (installedMode != "RECAPTCHA_ENTERPRISE") {
                            appCheck.installAppCheckProviderFactory(
                                RecaptchaAppCheckProviderFactory.getInstance(siteKey)
                            )
                            appCheck.setTokenAutoRefreshEnabled(true)
                            installedMode = "RECAPTCHA_ENTERPRISE"
                            Log.d(TAG, "RecaptchaAppCheckProviderFactory installed.")
                        }
                        _diagnostics.value = AppCheckDiagnostics(
                            mode = "RECAPTCHA_ENTERPRISE",
                            tokenInjectedFromIntent = true,
                            providerInstalled = true,
                            tokenVerified = false,
                            statusNote = "Güvenlik doğrulaması yapılıyor..."
                        )
                        probeAppCheckExchange(context, forceRefresh = false)
                    } else {
                        Log.w(TAG, "recaptcha_site_key string resource not found; App Check provider not installed.")
                        _diagnostics.value = AppCheckDiagnostics(
                            mode = "RECAPTCHA_ENTERPRISE",
                            providerInstalled = false,
                            statusNote = "Güvenlik doğrulaması bu sürümde kapalı."
                        )
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Firebase App Check could not be initialized", e)
                _diagnostics.value = _diagnostics.value.copy(
                    providerInstalled = installedMode != null,
                    statusNote = "Güvenlik doğrulaması başlatılamadı; uygulama normal çalışmaya devam ediyor."
                )
            }
        }
    }

    fun applyManualDebugToken(context: Context, rawSecret: String) {
        val clean = rawSecret.trim().removeSurrounding("\"")
        if (clean.isBlank()) return
        synchronized(lock) {
            runCatching {
                val app = ensureFirebase(context)
                debugPrefs(context, app).edit().putString(DEBUG_SECRET_KEY, clean).commit()
                metaPrefs(context, app).edit().putBoolean(HARNESS_VERIFIED_PREF_KEY, true).commit()

                val appCheck = FirebaseAppCheck.getInstance()
                appCheck.installAppCheckProviderFactory(DebugAppCheckProviderFactory.getInstance())
                appCheck.setTokenAutoRefreshEnabled(true)
                installedMode = "DEBUG_PROVIDER"
                installedSecret = clean

                _diagnostics.value = AppCheckDiagnostics(
                    mode = "DEBUG_PROVIDER",
                    tokenInjectedFromIntent = true,
                    providerInstalled = true,
                    tokenVerified = false,
                    debugTokenPreview = maskToken(clean),
                    fullDebugSecret = clean,
                    statusNote = "Debug anahtarı kaydedildi; doğrulanıyor..."
                )
                probeAppCheckExchange(context, forceRefresh = true)
            }.onFailure { err ->
                Log.w(TAG, "Failed to apply manual debug token", err)
            }
        }
    }

    /**
     * Fetches a fresh App Check token. Used by AI calls to transparently retry once after a
     * 401/403 attestation rejection. Never throws.
     */
    suspend fun refreshTokenNow(context: Context? = null): Boolean {
        if (isRobolectric()) return false
        return runCatching {
            if (context != null) ensureFirebase(context)
            val result = withTimeoutOrNull(8_000L) {
                FirebaseAppCheck.getInstance().getAppCheckToken(true).await()
            }
            val ok = result?.token?.isNotBlank() == true
            _diagnostics.value = _diagnostics.value.copy(
                tokenVerified = ok,
                statusNote = if (ok) "Güvenlik doğrulandı (${installedMode ?: "ACTIVE"})" else _diagnostics.value.statusNote
            )
            ok
        }.getOrElse { err ->
            Log.w(TAG, "App Check refresh failed: ${err.message}")
            false
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun probeAppCheckExchange(
        context: Context,
        forceRefresh: Boolean = true,
        fallbackToDebugOnRecaptchaFailure: Boolean = false
    ) {
        if (isRobolectric()) return
        runCatching {
            val app = ensureFirebase(context)
            val prefs = debugPrefs(context, app)

            FirebaseAppCheck.getInstance()
                .getAppCheckToken(forceRefresh)
                .addOnSuccessListener { result ->
                    val tokenValid = result.token.isNotBlank()
                    val latestSecret = prefs.getString(DEBUG_SECRET_KEY, "").orEmpty()
                    _diagnostics.value = _diagnostics.value.copy(
                        mode = installedMode ?: _diagnostics.value.mode,
                        providerInstalled = installedMode != null,
                        tokenVerified = tokenValid,
                        debugTokenPreview = maskToken(latestSecret),
                        fullDebugSecret = latestSecret,
                        statusNote = if (tokenValid) {
                            "Güvenlik doğrulandı (${installedMode ?: "ACTIVE"})"
                        } else {
                            "Güvenlik doğrulaması bekleniyor"
                        }
                    )
                    Log.d(TAG, "App Check token exchange verified (${installedMode}).")
                }
                .addOnFailureListener { err ->
                    val latestSecret = prefs.getString(DEBUG_SECRET_KEY, "").orEmpty()
                    // Expected while the debug token is not yet registered in Firebase Console: log quietly.
                    Log.i(TAG, "App Check token not accepted yet: ${err.message}")
                    _diagnostics.value = _diagnostics.value.copy(
                        tokenVerified = false,
                        debugTokenPreview = maskToken(latestSecret),
                        fullDebugSecret = latestSecret,
                        statusNote = if (BuildConfig.DEBUG) {
                            "Debug anahtarı henüz Firebase Console → App Check → Debug tokens listesine eklenmemiş. Aşağıdaki anahtarı kopyalayıp ekleyin."
                        } else {
                            "Güvenlik doğrulaması şu an tamamlanamadı; otomatik olarak yeniden denenecek."
                        }
                    )
                }
        }.onFailure { err ->
            Log.w(TAG, "App Check probe failed", err)
        }
    }

    fun recordAttestationFailure(detail: String) {
        Log.i(TAG, "Attestation rejected: $detail")
        _diagnostics.value = _diagnostics.value.copy(
            tokenVerified = false,
            statusNote = if (BuildConfig.DEBUG) {
                "Debug anahtarı Firebase tarafından kabul edilmedi. Ayarlar'daki anahtarı Firebase Console → App Check → Debug tokens listesine ekleyin."
            } else {
                "Güvenlik doğrulaması reddedildi; otomatik olarak yeniden denenecek."
            }
        )
    }

    private fun maskToken(raw: String): String {
        val clean = raw.trim()
        if (clean.length <= 12) return clean
        return "${clean.take(6)}••••${clean.takeLast(4)}"
    }
}

fun configureAppCheck(context: Context, intent: Intent?) {
    AppCheckCoordinator.configure(context, intent)
}
