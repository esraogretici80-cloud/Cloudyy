package com.example.genix.ai.registry

import com.example.genix.ai.core.AiModelCategory
import com.example.genix.ai.core.AiProviderKind
import com.example.genix.ai.core.CloudyAiModel
import com.example.genix.ai.core.ModelAvailabilityStatus
import com.example.genix.ai.core.ModelCapabilities
import com.example.genix.ai.core.ModelSettings
import com.example.genix.ai.core.SpeedTier
import com.example.genix.ai.security.ProviderCredentialRecord
import com.example.genix.core.ModelAccessScope
import com.example.genix.core.SubscriptionPlan
import com.example.genix.firebase.CrystalXModelId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Central Multi-Model AI Catalog & Dynamic Registry.
 * Bridges built-in Cloudy Firebase models, Local CPU offline engine, Image Generation models,
 * Real-Time Live Voice, and BYOK external providers (OpenAI, Claude, DeepSeek, Meta Llama, Qwen, Mistral).
 */
class CloudyModelCatalog {

    private val builtInModels: List<CloudyAiModel> = listOf(
        // ---- Built-in Cloudy Firebase Models (All Plans / Plan-Gated preserved) ----
        CloudyAiModel(
            id = CrystalXModelId.BREEZE_2_0.id,
            upstreamModelName = "gemini-3.5-flash-lite",
            displayName = "Cloudy 2.0 Breeze",
            shortBadge = "2.0 BREEZE",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.FAST_RESPONSES,
            secondaryCategories = listOf(AiModelCategory.GENERAL_AI, AiModelCategory.CREATIVE_WRITING),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true),
            speedTier = SpeedTier.TURBO,
            contextWindowTokens = 1_000_000,
            description = "Ultra-fast everyday Cloudy model with crisp structure and 1M context.",
            accessScope = ModelAccessScope.SHARED,
            legacyCrystalId = CrystalXModelId.BREEZE_2_0,
            defaultSettings = ModelSettings(temperature = 0.55f, topP = 0.90f, maxOutputTokens = 2048)
        ),
        CloudyAiModel(
            id = CrystalXModelId.NEO_1_1.id,
            upstreamModelName = "gemini-3.8-flash",
            displayName = "Cloudy 1.1 Neo",
            shortBadge = "1.1 NEO",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.GENERAL_AI,
            secondaryCategories = listOf(AiModelCategory.CREATIVE_WRITING, AiModelCategory.MULTIMODAL_AI, AiModelCategory.IMAGE_UNDERSTANDING),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 1_000_000,
            description = "Flagship multilingual conversational & multimodal model with balanced intelligence.",
            accessScope = ModelAccessScope.SHARED,
            legacyCrystalId = CrystalXModelId.NEO_1_1,
            defaultSettings = ModelSettings(temperature = 0.72f, topP = 0.94f, maxOutputTokens = 4096)
        ),
        CloudyAiModel(
            id = CrystalXModelId.LOCAL_CPU.id,
            upstreamModelName = "cloudy-local-ast",
            displayName = "Cloudy Local CPU",
            shortBadge = "OFFLINE CPU",
            provider = AiProviderKind.CLOUDY_LOCAL,
            category = AiModelCategory.FAST_RESPONSES,
            secondaryCategories = listOf(AiModelCategory.CODING, AiModelCategory.ADVANCED_REASONING),
            capabilities = ModelCapabilities(streaming = false, visionInput = false, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true, webGroundedReady = false),
            speedTier = SpeedTier.INSTANT,
            contextWindowTokens = 16_384,
            description = "Zero-network deterministic math solver, AST code auditor & lossless Unicode tokenizer.",
            accessScope = ModelAccessScope.SHARED,
            legacyCrystalId = CrystalXModelId.LOCAL_CPU,
            defaultSettings = ModelSettings(temperature = 0.0f, topP = 1.0f, maxOutputTokens = 2048)
        ),
        CloudyAiModel(
            id = CrystalXModelId.PRO_1_0.id,
            upstreamModelName = "gemini-3.8-flash",
            displayName = "Cloudy 1.0 Pro",
            shortBadge = "1.0 PRO",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.ADVANCED_REASONING,
            secondaryCategories = listOf(AiModelCategory.CODING, AiModelCategory.MULTIMODAL_AI),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true),
            speedTier = SpeedTier.DEEP,
            contextWindowTokens = 1_000_000,
            description = "High-precision architectural reasoning & engineering verifier (Pro+).",
            accessScope = ModelAccessScope.PRO_EXCLUSIVE,
            legacyCrystalId = CrystalXModelId.PRO_1_0,
            defaultSettings = ModelSettings(temperature = 0.18f, topP = 0.85f, maxOutputTokens = 8192)
        ),
        CloudyAiModel(
            id = CrystalXModelId.VISION_CODE.id,
            upstreamModelName = "gemini-3.8-flash",
            displayName = "Cloudy Vision & Code",
            shortBadge = "VISION+CODE",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.CODING,
            secondaryCategories = listOf(AiModelCategory.IMAGE_UNDERSTANDING, AiModelCategory.MULTIMODAL_AI),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 1_000_000,
            description = "Multimodal screenshot, diagram & PDF inspector + OWASP security/code engineer (Pro+).",
            accessScope = ModelAccessScope.PRO_EXCLUSIVE,
            legacyCrystalId = CrystalXModelId.VISION_CODE,
            defaultSettings = ModelSettings(maxOutputTokens = 16384)
        ),
        CloudyAiModel(
            id = CrystalXModelId.VOICE_LIVE.id,
            upstreamModelName = "gemini-live-2.5-flash-preview",
            displayName = "Cloudy Voice Live",
            shortBadge = "VOICE LIVE",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.REALTIME_VOICE,
            secondaryCategories = listOf(AiModelCategory.GENERAL_AI),
            capabilities = ModelCapabilities(streaming = true, realtimeAudio = true, visionInput = false, documentAnalysis = false),
            speedTier = SpeedTier.TURBO,
            contextWindowTokens = 128_000,
            description = "Bidirectional low-latency voice conversation with natural voices & interruption support (Pro+).",
            accessScope = ModelAccessScope.PRO_EXCLUSIVE,
            legacyCrystalId = CrystalXModelId.VOICE_LIVE,
            defaultSettings = ModelSettings(temperature = 0.78f, topP = 0.93f, maxOutputTokens = 1024)
        ),
        CloudyAiModel(
            id = CrystalXModelId.MULTI_AI.id,
            upstreamModelName = "cloudy-consensus-3x",
            displayName = "Cloudy Multi-AI Ensemble",
            shortBadge = "MULTI-AI",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.MULTIMODAL_AI,
            secondaryCategories = listOf(AiModelCategory.ADVANCED_REASONING),
            capabilities = ModelCapabilities(streaming = false, visionInput = true, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true),
            speedTier = SpeedTier.SYNTHESIS,
            contextWindowTokens = 1_000_000,
            description = "Runs 2.0 Breeze, 1.1 Neo & 1.0 Pro in parallel + consensus judge synthesis (Ultra).",
            accessScope = ModelAccessScope.ULTRA_EXCLUSIVE,
            legacyCrystalId = CrystalXModelId.MULTI_AI,
            defaultSettings = ModelSettings(temperature = 0.25f, topP = 0.88f, maxOutputTokens = 8192)
        ),
        CloudyAiModel(
            id = CrystalXModelId.DEEPTHINK_ULTRA.id,
            upstreamModelName = "gemini-3.8-flash",
            displayName = "Cloudy 2.5 DeepThink Ultra",
            shortBadge = "DEEPTHINK",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.ADVANCED_REASONING,
            secondaryCategories = listOf(AiModelCategory.CODING, AiModelCategory.CREATIVE_WRITING),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true),
            speedTier = SpeedTier.SYNTHESIS,
            contextWindowTokens = 1_000_000,
            description = "Two-pass adversarial self-critique & verified deep research synthesis (Ultra).",
            accessScope = ModelAccessScope.ULTRA_EXCLUSIVE,
            legacyCrystalId = CrystalXModelId.DEEPTHINK_ULTRA,
            defaultSettings = ModelSettings(temperature = 0.22f, topP = 0.86f, maxOutputTokens = 8192)
        ),
        CloudyAiModel(
            id = CrystalXModelId.BUILDER_3_0.id,
            upstreamModelName = "gemini-3.8-flash",
            displayName = "Cloudy 3.0 Builder",
            shortBadge = "3.0 BUILDER",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.CODING,
            secondaryCategories = listOf(AiModelCategory.CREATIVE_WRITING, AiModelCategory.MULTIMODAL_AI),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true),
            speedTier = SpeedTier.DEEP,
            contextWindowTokens = 1_000_000,
            description = "Builds games, 3D scenes and web apps as a single runnable HTML file (Pro+).",
            accessScope = ModelAccessScope.PRO_EXCLUSIVE,
            legacyCrystalId = CrystalXModelId.BUILDER_3_0,
            defaultSettings = ModelSettings(maxOutputTokens = 16384)
        ),

        // ---- Image Generation Models (Firebase AI Logic Supported Models) ----
        CloudyAiModel(
            id = "gemini-nano-banana-2.1",
            upstreamModelName = "gemini-nano-banana-2.1",
            displayName = "Nano Banana 2.1 Image",
            shortBadge = "IMAGE FAST",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.IMAGE_GENERATION,
            secondaryCategories = listOf(AiModelCategory.MULTIMODAL_AI, AiModelCategory.CREATIVE_WRITING),
            capabilities = ModelCapabilities(streaming = false, visionInput = true, imageGeneration = true, documentAnalysis = false),
            speedTier = SpeedTier.TURBO,
            contextWindowTokens = 32_768,
            description = "Default high-speed Gemini image synthesis & creative visual generation model.",
            accessScope = ModelAccessScope.SHARED
        ),
        CloudyAiModel(
            id = "gemini-3-pro-image",
            upstreamModelName = "gemini-3-pro-image",
            displayName = "Gemini 3 Pro Image",
            shortBadge = "IMAGE PRO",
            provider = AiProviderKind.CLOUDY_FIREBASE,
            category = AiModelCategory.IMAGE_GENERATION,
            secondaryCategories = listOf(AiModelCategory.MULTIMODAL_AI),
            capabilities = ModelCapabilities(streaming = false, visionInput = true, imageGeneration = true, documentAnalysis = false),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 32_768,
            description = "High-fidelity studio illustration, typography & product photography synthesis.",
            accessScope = ModelAccessScope.PRO_EXCLUSIVE
        ),

        // ---- BYOK External AI Provider Models (OpenAI, Claude, DeepSeek, Llama, Qwen, Mistral) ----
        CloudyAiModel(
            id = "openai-gpt-4o",
            upstreamModelName = "gpt-4o",
            displayName = "GPT-4o (BYOK)",
            shortBadge = "GPT-4o",
            provider = AiProviderKind.OPENAI,
            category = AiModelCategory.MULTIMODAL_AI,
            secondaryCategories = listOf(AiModelCategory.GENERAL_AI, AiModelCategory.IMAGE_UNDERSTANDING, AiModelCategory.CODING),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 128_000,
            description = "OpenAI flagship multimodal chat model via your device-local OpenAI API key."
        ),
        CloudyAiModel(
            id = "openai-o3-mini",
            upstreamModelName = "o3-mini",
            displayName = "OpenAI o3-mini (BYOK)",
            shortBadge = "o3-MINI",
            provider = AiProviderKind.OPENAI,
            category = AiModelCategory.ADVANCED_REASONING,
            secondaryCategories = listOf(AiModelCategory.CODING),
            capabilities = ModelCapabilities(streaming = true, visionInput = false, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true),
            speedTier = SpeedTier.DEEP,
            contextWindowTokens = 200_000,
            description = "OpenAI STEM & algorithmic reasoning model using your local API key."
        ),
        CloudyAiModel(
            id = "anthropic-claude-sonnet",
            upstreamModelName = "claude-sonnet-4-20250514",
            displayName = "Claude Sonnet (BYOK)",
            shortBadge = "CLAUDE",
            provider = AiProviderKind.ANTHROPIC,
            category = AiModelCategory.CODING,
            secondaryCategories = listOf(AiModelCategory.CREATIVE_WRITING, AiModelCategory.ADVANCED_REASONING, AiModelCategory.IMAGE_UNDERSTANDING),
            capabilities = ModelCapabilities(streaming = true, visionInput = true, documentAnalysis = true, codingSpecialty = true, reasoningSpecialty = true),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 200_000,
            description = "Anthropic Claude Sonnet via direct Messages API with your local key."
        ),
        CloudyAiModel(
            id = "deepseek-chat",
            upstreamModelName = "deepseek-chat",
            displayName = "DeepSeek V3 (BYOK)",
            shortBadge = "DEEPSEEK",
            provider = AiProviderKind.DEEPSEEK,
            category = AiModelCategory.CODING,
            secondaryCategories = listOf(AiModelCategory.GENERAL_AI),
            capabilities = ModelCapabilities(streaming = true, visionInput = false, documentAnalysis = true, codingSpecialty = true),
            speedTier = SpeedTier.TURBO,
            contextWindowTokens = 64_000,
            description = "DeepSeek high-efficiency coding & general assistant via your local API key."
        ),
        CloudyAiModel(
            id = "deepseek-reasoner",
            upstreamModelName = "deepseek-reasoner",
            displayName = "DeepSeek R1 (BYOK)",
            shortBadge = "DS-R1",
            provider = AiProviderKind.DEEPSEEK,
            category = AiModelCategory.ADVANCED_REASONING,
            secondaryCategories = listOf(AiModelCategory.CODING),
            capabilities = ModelCapabilities(streaming = true, visionInput = false, documentAnalysis = true, reasoningSpecialty = true),
            speedTier = SpeedTier.DEEP,
            contextWindowTokens = 64_000,
            description = "DeepSeek R1 chain-of-thought reasoner via your local API key."
        ),
        CloudyAiModel(
            id = "meta-llama-3.3-70b",
            upstreamModelName = "llama-3.3-70b-versatile",
            displayName = "Llama 3.3 70B (BYOK)",
            shortBadge = "LLAMA 3.3",
            provider = AiProviderKind.META_LLAMA,
            category = AiModelCategory.FAST_RESPONSES,
            secondaryCategories = listOf(AiModelCategory.GENERAL_AI),
            capabilities = ModelCapabilities(streaming = true, visionInput = false, documentAnalysis = true),
            speedTier = SpeedTier.TURBO,
            contextWindowTokens = 128_000,
            description = "Meta Llama 3.3 70B open-weight model via Groq or OpenAI-compatible host."
        ),
        CloudyAiModel(
            id = "qwen-max",
            upstreamModelName = "qwen-max",
            displayName = "Qwen Max (BYOK)",
            shortBadge = "QWEN MAX",
            provider = AiProviderKind.QWEN,
            category = AiModelCategory.GENERAL_AI,
            secondaryCategories = listOf(AiModelCategory.CODING, AiModelCategory.CREATIVE_WRITING),
            capabilities = ModelCapabilities(streaming = true, visionInput = false, documentAnalysis = true, codingSpecialty = true),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 32_768,
            description = "Alibaba Qwen Max multilingual & coding model via DashScope compatible API."
        ),
        CloudyAiModel(
            id = "mistral-large-latest",
            upstreamModelName = "mistral-large-latest",
            displayName = "Mistral Large (BYOK)",
            shortBadge = "MISTRAL",
            provider = AiProviderKind.MISTRAL,
            category = AiModelCategory.CREATIVE_WRITING,
            secondaryCategories = listOf(AiModelCategory.GENERAL_AI, AiModelCategory.CODING),
            capabilities = ModelCapabilities(streaming = true, visionInput = false, documentAnalysis = true, codingSpecialty = true),
            speedTier = SpeedTier.BALANCED,
            contextWindowTokens = 128_000,
            description = "Mistral AI flagship European multilingual & code model via local API key."
        )
    )

    private val _models = MutableStateFlow(builtInModels)
    val models: StateFlow<List<CloudyAiModel>> = _models.asStateFlow()

    fun findById(id: String?): CloudyAiModel {
        val clean = id?.trim().orEmpty()
        val exact = _models.value.firstOrNull { it.id == clean }
        if (exact != null) return exact
        val legacy = CrystalXModelId.fromId(clean)
        return _models.value.firstOrNull { it.id == legacy.id } ?: builtInModels[1]
    }

    fun registerFetchedModels(provider: AiProviderKind, fetched: List<CloudyAiModel>) {
        if (fetched.isEmpty()) return
        _models.update { current ->
            val kept = current.filterNot { it.provider == provider && it.isDynamicFetched }
            val existingIds = kept.map { it.id }.toSet()
            kept + fetched.filterNot { it.id in existingIds }
        }
    }

    fun availabilityFor(
        model: CloudyAiModel,
        plan: SubscriptionPlan,
        credentials: Map<AiProviderKind, ProviderCredentialRecord>,
        fastApiUrl: String
    ): ModelAvailabilityStatus {
        if (model.provider == AiProviderKind.CLOUDY_FIREBASE && !plan.canAccessScope(model.accessScope)) {
            return ModelAvailabilityStatus.PLAN_LOCKED
        }
        if (model.provider.requiresByokKey) {
            val hasKey = credentials[model.provider]?.hasKey == true
            if (!hasKey) return ModelAvailabilityStatus.KEY_REQUIRED
        }
        if (model.provider == AiProviderKind.REMOTE_FASTAPI && fastApiUrl.isBlank()) {
            return ModelAvailabilityStatus.REMOTE_CONFIG_NEEDED
        }
        return ModelAvailabilityStatus.READY
    }

    fun modelsInCategory(category: AiModelCategory): List<CloudyAiModel> =
        _models.value.filter { it.category == category || category in it.secondaryCategories }

    private fun SubscriptionPlan.canAccessScope(scope: ModelAccessScope): Boolean = when (scope) {
        ModelAccessScope.SHARED -> true
        ModelAccessScope.PRO_EXCLUSIVE -> rank >= SubscriptionPlan.PRO.rank
        ModelAccessScope.ULTRA_EXCLUSIVE -> rank >= SubscriptionPlan.ULTRA.rank
    }
}
