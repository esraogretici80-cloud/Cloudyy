package com.example.genix.training

data class TransformerArchitectureConfig(
    val name: String = "genix-base-nano-15m",
    val vocabSize: Int = 32000,
    val dModel: Int = 384,
    val nHeads: Int = 6,
    val nLayers: Int = 6,
    val dFf: Int = 1536,
    val maxSeqLen: Int = 1024,
    val tieEmbeddings: Boolean = true
)

data class TransformerEstimate(
    val totalParameters: Long,
    val embeddingParams: Long,
    val transformerBlockParams: Long,
    val headParams: Long,
    val fp32WeightsMb: Double,
    val fp16WeightsMb: Double,
    val int8WeightsMb: Double,
    val kvCachePerSeqMb: Double,
    val hardwareNote: String
)

/**
 * GENIX Base — Phase B Experimental Transformer Spec & Parameter Estimator.
 * Computes exact PyTorch-equivalent parameter counts and memory footprints for affordable
 * experimental training before Phase 6 compute-plane runs.
 */
object ExperimentalTransformerSpec {

    val presets = listOf(
        TransformerArchitectureConfig(
            name = "genix-base-micro-4m",
            vocabSize = 8192,
            dModel = 256,
            nHeads = 4,
            nLayers = 4,
            dFf = 1024,
            maxSeqLen = 512
        ),
        TransformerArchitectureConfig(
            name = "genix-base-nano-15m",
            vocabSize = 16384,
            dModel = 384,
            nHeads = 6,
            nLayers = 6,
            dFf = 1536,
            maxSeqLen = 1024
        ),
        TransformerArchitectureConfig(
            name = "genix-base-small-68m",
            vocabSize = 32000,
            dModel = 640,
            nHeads = 10,
            nLayers = 10,
            dFf = 2560,
            maxSeqLen = 2048
        )
    )

    fun estimate(config: TransformerArchitectureConfig): TransformerEstimate {
        val d = config.dModel.toLong()
        val v = config.vocabSize.toLong()
        val l = config.nLayers.toLong()
        val ff = config.dFf.toLong()

        val embeddingParams = v * d
        // Per block: Attention (Q,K,V,O = 4*d*d) + FFN (2*d*ff) + 2 LayerNorms (4*d)
        val perLayer = (4L * d * d) + (2L * d * ff) + (4L * d)
        val blockParams = l * perLayer + (2L * d) // final norm
        val headParams = if (config.tieEmbeddings) 0L else v * d
        val total = embeddingParams + blockParams + headParams

        val fp32Mb = (total * 4.0) / (1024.0 * 1024.0)
        val fp16Mb = (total * 2.0) / (1024.0 * 1024.0)
        val int8Mb = (total * 1.0) / (1024.0 * 1024.0)
        // KV cache FP16: 2 (K+V) * nLayers * maxSeqLen * dModel * 2 bytes
        val kvCacheMb = (2.0 * l * config.maxSeqLen * d * 2.0) / (1024.0 * 1024.0)

        val note = when {
            total <= 10_000_000L -> "Trainable on CPU or entry 4GB GPU for tokenizer & pretraining validation."
            total <= 30_000_000L -> "Recommended for single-GPU (8GB+ VRAM) experimental Phase 6 training."
            else -> "Requires 16GB+ VRAM GPU compute plane with mixed-precision & gradient accumulation."
        }

        return TransformerEstimate(
            totalParameters = total,
            embeddingParams = embeddingParams,
            transformerBlockParams = blockParams,
            headParams = headParams,
            fp32WeightsMb = fp32Mb,
            fp16WeightsMb = fp16Mb,
            int8WeightsMb = int8Mb,
            kvCachePerSeqMb = kvCacheMb,
            hardwareNote = note
        )
    }
}
