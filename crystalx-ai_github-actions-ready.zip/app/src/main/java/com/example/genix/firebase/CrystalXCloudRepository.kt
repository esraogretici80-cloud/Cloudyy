package com.example.genix.firebase

import android.content.Context
import androidx.annotation.Keep
import com.example.R
import com.example.ui.theme.AppThemeMode
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

@Keep
@IgnoreExtraProperties
data class UserProfileSettings(
    @DocumentId val id: String = "",
    val userId: String = "",
    val themeMode: String = AppThemeMode.LIGHT_WHITE.id,
    val proUnlocked: Boolean = false,
    val preferredLanguageCode: String = "system",
    val countryCode: String = "TR",
    val defaultModelId: String = CrystalXModelId.NEO_1_1.id,
    val voiceProfileId: String = "aoede",
    val subscriptionTier: String = "FREE",
    val autoRouteEnabled: Boolean = false,
    val responseStyle: String = "BALANCED",
    val customInstructions: String = "",
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserIntegration(
    @DocumentId val id: String = "",
    val userId: String = "",
    val type: String = "webhook",
    val name: String = "",
    val targetUrl: String = "",
    val notes: String = "",
    val enabled: Boolean = true,
    val lastStatus: String = "Ready",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ConversationThread(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val activeModelId: String = CrystalXModelId.NEO_1_1.id,
    val pinned: Boolean = false,
    val messageCount: Long = 0L,
    val lastPreview: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val role: String = "user",
    val content: String = "",
    val modelLabel: String = "",
    val languageCode: String = "en",
    val verificationStatus: String = "LOCAL_DETERMINISTIC",
    val latencyMs: Long = 0L,
    val starred: Boolean = false,
    val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudMemoryItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "knowledge",
    val content: String = "",
    val languageCode: String = "en",
    val pinned: Boolean = false,
    val tags: List<String> = emptyList(),
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

/**
 * Per-User Isolated Cloud Firestore Repository for Cloudy AI.
 * Strictly initialized with `R.string.firestore_database_id` and scoped under `/users/{uid}/...`.
 */
class CrystalXCloudRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("User must be signed in before accessing Cloudy Cloud Workspace.")
    }

    private fun sanitizeModelId(raw: String?): String {
        val cleaned = raw.orEmpty().trim().take(80)
        return if (cleaned.matches(Regex("^[a-zA-Z0-9._:\\-/]{2,80}$"))) {
            cleaned
        } else {
            CrystalXModelId.NEO_1_1.id
        }
    }

    fun observeUserProfile(): Flow<UserProfileSettings?> = flow {
        val uid = requireUserId()
        val path = "users/$uid/profile/settings"
        emitAll(
            db.collection("users").document(uid).collection("profile").document("settings")
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(UserProfileSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun saveUserProfile(
        themeMode: AppThemeMode,
        proUnlocked: Boolean,
        preferredLanguageCode: String,
        countryCode: String,
        defaultModelId: String,
        voiceProfileId: String = "aoede",
        subscriptionTier: String = "FREE",
        autoRouteEnabled: Boolean = false,
        responseStyle: String = "BALANCED",
        customInstructions: String = ""
    ): Result<Unit> {
        var path = "users/unknown/profile/settings"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("profile").document("settings")
            path = docRef.path
            val safeTier = if (subscriptionTier in listOf("FREE", "PRO", "ULTRA")) subscriptionTier else "FREE"
            val safeStyle = if (responseStyle in listOf("CONCISE", "BALANCED", "DETAILED")) responseStyle else "BALANCED"
            val payload = mapOf(
                "userId" to uid,
                "themeMode" to themeMode.id,
                "proUnlocked" to (proUnlocked || themeMode.isPro || safeTier != "FREE"),
                "preferredLanguageCode" to preferredLanguageCode.take(12).ifBlank { "system" },
                "countryCode" to countryCode.take(8).ifBlank { "TR" },
                "defaultModelId" to sanitizeModelId(defaultModelId),
                "voiceProfileId" to voiceProfileId.take(40).ifBlank { "aoede" },
                "subscriptionTier" to safeTier,
                "autoRouteEnabled" to autoRouteEnabled,
                "responseStyle" to safeStyle,
                "customInstructions" to customInstructions.trim().take(2000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeIntegrations(): Flow<List<UserIntegration>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/integrations"
        emitAll(
            db.collection("users").document(uid).collection("integrations")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserIntegration::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addIntegration(
        type: String,
        name: String,
        targetUrl: String,
        notes: String = "",
        enabled: Boolean = true,
        lastStatus: String = "Ready"
    ): Result<String> {
        var path = "users/unknown/integrations"
        return try {
            val uid = requireUserId()
            val validType = if (type in listOf("webhook", "github_repo", "web_feed", "fastapi_node", "cloud_vault", "voice_tts")) {
                type
            } else "webhook"
            val docRef = db.collection("users").document(uid).collection("integrations").document()
            path = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "type" to validType,
                "name" to name.trim().take(100).ifBlank { "Cloudy Connector" },
                "targetUrl" to targetUrl.trim().take(500),
                "notes" to notes.trim().take(500),
                "enabled" to enabled,
                "lastStatus" to lastStatus.take(300).ifBlank { "Ready" },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleIntegrationEnabled(item: UserIntegration): Result<Unit> {
        var path = "users/unknown/integrations/${item.id}"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("integrations").document(item.id)
            path = docRef.path
            docRef.update(
                mapOf(
                    "enabled" to !item.enabled,
                    "lastStatus" to if (!item.enabled) "Active" else "Paused",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateIntegrationTargetAndStatus(
        integrationId: String,
        targetUrl: String? = null,
        lastStatus: String
    ): Result<Unit> {
        var path = "users/unknown/integrations/$integrationId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("integrations").document(integrationId)
            path = docRef.path
            val updates = mutableMapOf<String, Any>(
                "lastStatus" to lastStatus.take(300),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (targetUrl != null) {
                updates["targetUrl"] = targetUrl.trim().take(500)
            }
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteIntegration(integrationId: String): Result<Unit> {
        var path = "users/unknown/integrations/$integrationId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("integrations").document(integrationId)
            path = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeConversations(): Flow<List<ConversationThread>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/conversations"
        emitAll(
            db.collection("users").document(uid).collection("conversations")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ConversationThread::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(conversationId: String): Flow<List<CloudMessage>> = flow {
        val uid = requireUserId()
        require(conversationId.isNotBlank()) { "Conversation ID cannot be blank" }
        val path = "users/$uid/conversations/$conversationId/messages"
        emitAll(
            db.collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CloudMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMemories(): Flow<List<CloudMemoryItem>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/memories"
        emitAll(
            db.collection("users").document(uid).collection("memories")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CloudMemoryItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    val toLog = fsErr ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createConversation(
        title: String,
        activeModelId: String = CrystalXModelId.NEO_1_1.id,
        pinned: Boolean = false
    ): Result<String> {
        var path = "users/unknown/conversations"
        return try {
            val uid = requireUserId()
            val cleanTitle = title.trim().take(120).ifBlank { "Cloudy Studio" }
            val safeModel = sanitizeModelId(activeModelId)
            val docRef = db.collection("users").document(uid).collection("conversations").document()
            path = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "title" to cleanTitle,
                "activeModelId" to safeModel,
                "pinned" to pinned,
                "messageCount" to 0L,
                "lastPreview" to "Ready",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateConversationModel(conversationId: String, activeModelId: String): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId"
        return try {
            val uid = requireUserId()
            val safeModel = sanitizeModelId(activeModelId)
            val docRef = db.collection("users").document(uid).collection("conversations").document(conversationId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "activeModelId" to safeModel,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleConversationPin(conversationId: String, currentPinned: Boolean): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("conversations").document(conversationId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "pinned" to !currentPinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun renameConversation(conversationId: String, newTitle: String): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId"
        return try {
            val uid = requireUserId()
            val clean = newTitle.trim().take(120)
            require(clean.isNotEmpty()) { "Thread title cannot be empty" }
            val docRef = db.collection("users").document(uid).collection("conversations").document(conversationId)
            path = docRef.path
            docRef.update(
                mapOf(
                    "title" to clean,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteConversation(conversationId: String): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId"
        return try {
            val uid = requireUserId()
            val convRef = db.collection("users").document(uid).collection("conversations").document(conversationId)
            path = convRef.path
            val msgs = convRef.collection("messages").get().await()
            for (doc in msgs.documents) {
                doc.reference.delete().await()
            }
            convRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteAllConversations(): Result<Int> {
        var path = "users/unknown/conversations"
        return try {
            val uid = requireUserId()
            val colRef = db.collection("users").document(uid).collection("conversations")
            path = colRef.path
            val snap = colRef.get().await()
            var count = 0
            for (conv in snap.documents) {
                val msgs = conv.reference.collection("messages").get().await()
                for (m in msgs.documents) {
                    m.reference.delete().await()
                }
                conv.reference.delete().await()
                count++
            }
            Result.success(count)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun appendCloudMessage(
        conversationId: String,
        role: String,
        content: String,
        modelLabel: String,
        languageCode: String,
        verificationStatus: String,
        latencyMs: Long
    ): Result<String> {
        var path = "users/unknown/conversations/$conversationId/messages"
        return try {
            val uid = requireUserId()
            val cleanContent = content.trim().take(31_500).ifBlank { "(empty)" }
            val convRef = db.collection("users").document(uid).collection("conversations").document(conversationId)
            val msgRef = convRef.collection("messages").document()
            path = msgRef.path

            val msgPayload = mapOf(
                "userId" to uid,
                "role" to if (role == "assistant") "assistant" else "user",
                "content" to cleanContent,
                "modelLabel" to modelLabel.take(80).ifBlank { "Cloudy AI" },
                "languageCode" to languageCode.take(12).ifBlank { "en" },
                "verificationStatus" to verificationStatus.take(60),
                "latencyMs" to latencyMs.coerceIn(0L, 600_000L),
                "starred" to false,
                "createdAt" to FieldValue.serverTimestamp()
            )
            msgRef.set(msgPayload).await()

            convRef.update(
                mapOf(
                    "messageCount" to FieldValue.increment(1L),
                    "lastPreview" to cleanContent.replace("\n", " ").take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(msgRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateCloudMessage(
        conversationId: String,
        messageId: String,
        content: String,
        modelLabel: String? = null,
        verificationStatus: String? = null,
        latencyMs: Long? = null
    ): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId/messages/$messageId"
        return try {
            val uid = requireUserId()
            val cleanContent = content.trim().take(31_500).ifBlank { "(empty)" }
            val convRef = db.collection("users").document(uid).collection("conversations").document(conversationId)
            val msgRef = convRef.collection("messages").document(messageId)
            path = msgRef.path

            val updates = mutableMapOf<String, Any>("content" to cleanContent)
            if (!modelLabel.isNullOrBlank()) updates["modelLabel"] = modelLabel.take(80)
            if (!verificationStatus.isNullOrBlank()) updates["verificationStatus"] = verificationStatus.take(60)
            if (latencyMs != null) updates["latencyMs"] = latencyMs.coerceIn(0L, 600_000L)

            msgRef.update(updates).await()
            convRef.update(
                mapOf(
                    "lastPreview" to cleanContent.replace("\n", " ").take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteCloudMessage(conversationId: String, messageId: String): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId/messages/$messageId"
        return try {
            val uid = requireUserId()
            val msgRef = db.collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .collection("messages").document(messageId)
            path = msgRef.path
            msgRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleMessageStar(conversationId: String, messageId: String, currentStarred: Boolean): Result<Unit> {
        var path = "users/unknown/conversations/$conversationId/messages/$messageId"
        return try {
            val uid = requireUserId()
            val msgRef = db.collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .collection("messages").document(messageId)
            path = msgRef.path
            msgRef.update(mapOf("starred" to !currentStarred)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addMemoryItem(
        title: String,
        category: String,
        content: String,
        languageCode: String,
        tags: List<String>,
        pinned: Boolean = false
    ): Result<Unit> {
        var path = "users/unknown/memories"
        return try {
            val uid = requireUserId()
            val cleanTitle = title.trim().take(140)
            val cleanContent = content.trim().take(12_000)
            require(cleanTitle.isNotEmpty() && cleanContent.isNotEmpty()) { "Title and content are required." }
            val validCat = if (category in listOf("knowledge", "prompt_template", "preference", "code_snippet")) {
                category
            } else "knowledge"
            val cleanTags = tags.map { it.trim() }.filter { it.isNotBlank() }.take(8)
            val docRef = db.collection("users").document(uid).collection("memories").document()
            path = docRef.path
            val payload = mapOf(
                "userId" to uid,
                "title" to cleanTitle,
                "category" to validCat,
                "content" to cleanContent,
                "languageCode" to languageCode.take(12).ifBlank { "en" },
                "pinned" to pinned,
                "tags" to cleanTags,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateMemoryItem(
        memoryId: String,
        title: String,
        category: String,
        content: String,
        tags: List<String>,
        pinned: Boolean? = null
    ): Result<Unit> {
        var path = "users/unknown/memories/$memoryId"
        return try {
            val uid = requireUserId()
            val cleanTitle = title.trim().take(140)
            val cleanContent = content.trim().take(12_000)
            require(cleanTitle.isNotEmpty() && cleanContent.isNotEmpty()) { "Title and content are required." }
            val validCat = if (category in listOf("knowledge", "prompt_template", "preference", "code_snippet")) {
                category
            } else "knowledge"
            val cleanTags = tags.map { it.trim() }.filter { it.isNotBlank() }.take(8)
            val docRef = db.collection("users").document(uid).collection("memories").document(memoryId)
            path = docRef.path
            val updates = mutableMapOf<String, Any>(
                "title" to cleanTitle,
                "category" to validCat,
                "content" to cleanContent,
                "tags" to cleanTags,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (pinned != null) updates["pinned"] = pinned
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleMemoryPin(memory: CloudMemoryItem): Result<Unit> {
        var path = "users/unknown/memories/${memory.id}"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("memories").document(memory.id)
            path = docRef.path
            docRef.update(
                mapOf(
                    "pinned" to !memory.pinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteMemoryItem(memoryId: String): Result<Unit> {
        var path = "users/unknown/memories/$memoryId"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid).collection("memories").document(memoryId)
            path = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
