package com.example.genix.firebase

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object CloudyIntegrationsEngine {

    suspend fun fetchGitHubRepoSummary(repoInput: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanRepo = repoInput.trim()
                .removePrefix("https://github.com/")
                .removePrefix("http://github.com/")
                .trim('/')
            require(cleanRepo.contains("/")) { "Enter repo as owner/repo (e.g. google/generative-ai-android)" }

            val url = URL("https://api.github.com/repos/$cleanRepo")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("User-Agent", "CloudyAI-Android/2.0")
            }

            try {
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
                if (code !in 200..299) {
                    error("GitHub HTTP $code: ${body.take(180)}")
                }
                val json = JSONObject(body)
                val fullName = json.optString("full_name", cleanRepo)
                val desc = json.optString("description", "No description")
                val stars = json.optInt("stargazers_count", 0)
                val forks = json.optInt("forks_count", 0)
                val issues = json.optInt("open_issues_count", 0)
                val lang = json.optString("language", "Unknown")
                val branch = json.optString("default_branch", "main")
                "GitHub Repo [$fullName] | Language: $lang | Stars: $stars | Forks: $forks | Open Issues: $issues | Branch: $branch\nDescription: $desc"
            } finally {
                conn.disconnect()
            }
        }
    }

    suspend fun fetchWebOrRssSnippet(rawUrl: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val normalized = rawUrl.trim().let {
                if (it.startsWith("http://") || it.startsWith("https://")) it else "https://$it"
            }
            val url = URL(normalized)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "CloudyAI-Android/2.0")
            }

            try {
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
                if (code !in 200..299) {
                    error("HTTP $code from $normalized")
                }
                val stripped = body
                    .replace(Regex("<script[^>]*>[\\s\\S]*?</script>", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("<style[^>]*>[\\s\\S]*?</style>", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("<[^>]+>"), " ")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                "Web/RSS Feed [$normalized] (HTTP $code):\n${stripped.take(1600)}"
            } finally {
                conn.disconnect()
            }
        }
    }

    suspend fun dispatchWebhook(
        webhookUrl: String,
        title: String,
        content: String,
        modelName: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val target = webhookUrl.trim()
            require(target.startsWith("https://") || target.startsWith("http://")) {
                "Webhook URL must start with http:// or https://"
            }
            val payload = JSONObject().apply {
                put("app", "Cloudy AI")
                put("model", modelName)
                put("title", title.take(120))
                put("content", content.take(4000))
                put("text", "[$modelName] $title\n${content.take(1800)}")
            }.toString()

            val conn = (URL(target).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("User-Agent", "CloudyAI-Android/2.0")
            }

            try {
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(payload)
                    writer.flush()
                }
                val code = conn.responseCode
                val resp = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.let { BufferedReader(InputStreamReader(it)).readText() }
                    .orEmpty()
                if (code !in 200..299) {
                    error("Webhook HTTP $code: ${resp.take(140)}")
                }
                "Webhook delivered (HTTP $code)"
            } finally {
                conn.disconnect()
            }
        }
    }

    fun shareTextViaAndroidSheet(context: Context, title: String, content: String) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, content)
            type = "text/plain"
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share via Cloudy AI").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(shareIntent)
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    }
}
