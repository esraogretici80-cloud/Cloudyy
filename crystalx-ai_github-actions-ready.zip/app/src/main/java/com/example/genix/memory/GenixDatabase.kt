package com.example.genix.memory

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ShortTermMessageEntity::class,
        LongTermMemoryEntity::class,
        KnowledgeDocumentEntity::class,
        AuditLogEntity::class,
        GeneratedImageEntity::class,
        DocumentArtifactEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class GenixDatabase : RoomDatabase() {
    abstract fun shortTermMemoryDao(): ShortTermMemoryDao
    abstract fun longTermMemoryDao(): LongTermMemoryDao
    abstract fun knowledgeMemoryDao(): KnowledgeMemoryDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun generatedImageDao(): GeneratedImageDao
    abstract fun documentArtifactDao(): DocumentArtifactDao

    companion object {
        @Volatile
        private var INSTANCE: GenixDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `generated_images` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `userId` TEXT NOT NULL,
                        `prompt` TEXT NOT NULL,
                        `modelId` TEXT NOT NULL,
                        `aspectRatio` TEXT NOT NULL,
                        `filePath` TEXT NOT NULL,
                        `createdAtMs` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `document_artifacts` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `userId` TEXT NOT NULL,
                        `fileName` TEXT NOT NULL,
                        `mimeType` TEXT NOT NULL,
                        `sizeBytes` INTEGER NOT NULL,
                        `pageCount` INTEGER NOT NULL,
                        `extractedText` TEXT NOT NULL,
                        `createdAtMs` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): GenixDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    GenixDatabase::class.java,
                    "genix_foundation.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
