package com.example.genix.ai.multimodal

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

data class ExtractedDocumentPayload(
    val fileName: String,
    val mimeType: String,
    val extractedText: String,
    val pagePreviewBitmaps: List<Bitmap>,
    val charCount: Int,
    val estimatedTokens: Int,
    val chunks: List<String>,
    val summaryNote: String
)

/**
 * Multi-format Document Intelligence Engine:
 * - PDF: Extracts embedded text operators AND renders up to 3 pages via Android PdfRenderer so Vision models read scanned/complex PDFs natively.
 * - DOCX: Parses `word/document.xml` safely via ZipInputStream + XML DOM.
 * - TXT, MD, CSV, JSON, Kotlin, Python, JS/TS, SQL, HTML, XML: Full UTF-8 read + chunking.
 */
class DocumentIntelligenceEngine(private val context: Context) {

    suspend fun extractFromUri(uri: Uri): Result<ExtractedDocumentPayload> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val mime = resolver.getType(uri).orEmpty().lowercase(Locale.ROOT)
            val fileName = resolveDisplayName(uri).ifBlank { "document" }
            val lowerName = fileName.lowercase(Locale.ROOT)

            val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Could not read file bytes from selected document.")

            when {
                mime.contains("pdf") || lowerName.endsWith(".pdf") -> {
                    extractPdf(fileName, mime.ifBlank { "application/pdf" }, rawBytes)
                }
                mime.contains("wordprocessingml") || lowerName.endsWith(".docx") -> {
                    val text = extractDocxXmlText(rawBytes)
                    buildTextPayload(
                        fileName = fileName,
                        mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        rawText = text,
                        previews = emptyList()
                    )
                }
                else -> {
                    val decoded = rawBytes.toString(Charsets.UTF_8)
                    buildTextPayload(
                        fileName = fileName,
                        mimeType = mime.ifBlank { "text/plain" },
                        rawText = decoded,
                        previews = emptyList()
                    )
                }
            }
        }
    }

    private fun extractPdf(fileName: String, mimeType: String, rawBytes: ByteArray): ExtractedDocumentPayload {
        val tempPdf = File(context.cacheDir, "cloudy_doc_${System.currentTimeMillis()}.pdf")
        val pageBitmaps = mutableListOf<Bitmap>()
        var pageCount = 0

        try {
            FileOutputStream(tempPdf).use { it.write(rawBytes) }
            ParcelFileDescriptor.open(tempPdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    pageCount = renderer.pageCount
                    val maxPagesToRender = minOf(pageCount, 3)
                    for (idx in 0 until maxPagesToRender) {
                        renderer.openPage(idx).use { page ->
                            val targetW = 1080
                            val ratio = page.height.toFloat() / page.width.coerceAtLeast(1).toFloat()
                            val targetH = (targetW * ratio).toInt().coerceIn(400, 1800)
                            val bmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(android.graphics.Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            pageBitmaps.add(bmp)
                        }
                    }
                }
            }
        } finally {
            runCatching { tempPdf.delete() }
        }

        val parsedText = extractPdfReadableStrings(rawBytes)
        val headerNote = buildString {
            append("[PDF Metadata] File: $fileName | Pages: $pageCount | Rendered visual pages: ${pageBitmaps.size}\n")
            if (parsedText.isNotBlank()) {
                append("[Extracted PDF Text Operators]:\n")
                append(parsedText)
            } else {
                append("No uncompressed ASCII/UTF text operators found; rendered page images are attached for multimodal Vision inspection.")
            }
        }
        return buildTextPayload(
            fileName = fileName,
            mimeType = mimeType,
            rawText = headerNote,
            previews = pageBitmaps
        )
    }

    private fun extractPdfReadableStrings(bytes: ByteArray): String {
        val raw = String(bytes, Charsets.ISO_8859_1)
        val matches = Regex("\\(([\\x20-\\x7E]{4,240})\\)\\s*Tj").findAll(raw)
            .map { it.groupValues[1].replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\") }
            .toList()
        return matches.joinToString(" ").replace(Regex("\\s+"), " ").trim().take(18_000)
    }

    private fun extractDocxXmlText(bytes: ByteArray): String {
        val sb = StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (entry.name == "word/document.xml") {
                    val xmlBytes = zis.readBytes()
                    val factory = DocumentBuilderFactory.newInstance().apply {
                        setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
                    }
                    val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(xmlBytes))
                    val paragraphs = doc.getElementsByTagName("w:p")
                    for (i in 0 until paragraphs.length) {
                        val line = paragraphs.item(i).textContent?.trim().orEmpty()
                        if (line.isNotBlank()) {
                            sb.append(line).append("\n")
                        }
                    }
                    break
                }
                entry = zis.nextEntry
            }
        }
        return sb.toString().trim().ifBlank { "DOCX archive parsed, but no paragraph text nodes were found." }
    }

    fun chunkDocumentText(text: String, chunkSizeChars: Int = 1800, overlapChars: Int = 180): List<String> {
        val clean = text.trim()
        if (clean.isEmpty()) return emptyList()
        if (clean.length <= chunkSizeChars) return listOf(clean)

        val chunks = mutableListOf<String>()
        var cursor = 0
        while (cursor < clean.length) {
            val end = minOf(cursor + chunkSizeChars, clean.length)
            chunks.add(clean.substring(cursor, end))
            if (end >= clean.length) break
            cursor = (end - overlapChars).coerceAtLeast(cursor + 1)
        }
        return chunks
    }

    private fun buildTextPayload(
        fileName: String,
        mimeType: String,
        rawText: String,
        previews: List<Bitmap>
    ): ExtractedDocumentPayload {
        val trimmed = rawText.trim().take(36_000)
        val chunks = chunkDocumentText(trimmed)
        val estTokens = (trimmed.length / 4).coerceAtLeast(1)
        val summary = "$fileName • ${trimmed.length} chars • ~$estTokens tok • ${chunks.size} chunks" +
            if (previews.isNotEmpty()) " • ${previews.size} page image(s)" else ""

        return ExtractedDocumentPayload(
            fileName = fileName,
            mimeType = mimeType,
            extractedText = trimmed,
            pagePreviewBitmaps = previews,
            charCount = trimmed.length,
            estimatedTokens = estTokens,
            chunks = chunks,
            summaryNote = summary
        )
    }

    private fun resolveDisplayName(uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return cursor.getString(idx).orEmpty()
                }
            }
        return uri.lastPathSegment?.substringAfterLast('/').orEmpty()
    }
}
