package com.example.genix.memory

import com.example.genix.core.GenixEventLog
import com.example.genix.core.LogSeverity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Locale
import kotlin.math.sqrt

data class KnowledgeSearchHit(
    val document: KnowledgeDocumentEntity,
    val similarityScore: Double,
    val isolationBoundary: String = "UNTRUSTED_RETRIEVED_CONTEXT"
)

/**
 * GENIX 3-Layer Memory Repository (Section 8):
 * - Short-Term Memory: Active conversation buffer
 * - Long-Term Memory: User-approved preferences & persistent project metadata with expiration
 * - Knowledge Memory: Document indexing & local character-trigram/word cosine similarity retrieval
 *
 * Security Rule: Retrieved knowledge documents are strictly tagged UNTRUSTED_RETRIEVED_CONTEXT
 * and are never executed or promoted to system instructions.
 */
class MemoryRepository(
    private val db: GenixDatabase
) {
    private val shortTermDao = db.shortTermMemoryDao()
    private val longTermDao = db.longTermMemoryDao()
    private val knowledgeDao = db.knowledgeMemoryDao()
    private val auditLogDao = db.auditLogDao()
    private val generatedImageDao = db.generatedImageDao()
    private val documentArtifactDao = db.documentArtifactDao()

    fun observeGeneratedImages(userId: String): Flow<List<GeneratedImageEntity>> =
        generatedImageDao.observeForUser(userId)

    suspend fun saveGeneratedImage(entity: GeneratedImageEntity): Long =
        generatedImageDao.insert(entity)

    suspend fun deleteGeneratedImage(id: Long) {
        generatedImageDao.deleteById(id)
    }

    suspend fun clearGeneratedImages(userId: String) {
        generatedImageDao.clearForUser(userId)
    }

    fun observeDocumentArtifacts(userId: String): Flow<List<DocumentArtifactEntity>> =
        documentArtifactDao.observeForUser(userId)

    suspend fun saveDocumentArtifact(entity: DocumentArtifactEntity): Long =
        documentArtifactDao.insert(entity)

    suspend fun deleteDocumentArtifact(id: Long) {
        documentArtifactDao.deleteById(id)
    }

    fun observeConversation(sessionId: String): Flow<List<ShortTermMessageEntity>> =
        shortTermDao.observeMessages(sessionId)

    fun observeLongTermMemories(userId: String = "local-researcher"): Flow<List<LongTermMemoryEntity>> =
        longTermDao.observeMemories(userId)

    fun observeKnowledgeDocuments(userId: String = "local-researcher"): Flow<List<KnowledgeDocumentEntity>> =
        knowledgeDao.observeDocuments(userId)

    fun observeAuditLogs(): Flow<List<GenixEventLog>> =
        auditLogDao.observeRecentLogs().map { list ->
            list.map {
                GenixEventLog(
                    id = it.id.toString(),
                    timestampMs = it.timestampMs,
                    component = it.component,
                    severity = runCatching { LogSeverity.valueOf(it.severity) }.getOrDefault(LogSeverity.INFO),
                    message = it.message,
                    metadataJson = it.metadataJson
                )
            }
        }

    suspend fun appendShortTermMessage(message: ShortTermMessageEntity) {
        shortTermDao.insertMessage(message)
    }

    suspend fun clearConversation(sessionId: String) {
        shortTermDao.clearSession(sessionId)
    }

    suspend fun saveLongTermMemory(
        category: String,
        keyName: String,
        valueText: String,
        ttlHours: Long? = null
    ) {
        val expiresAt = ttlHours?.let { System.currentTimeMillis() + it * 3_600_000L }
        longTermDao.insertOrUpdate(
            LongTermMemoryEntity(
                category = category.trim(),
                keyName = keyName.trim(),
                valueText = valueText.trim(),
                userApproved = true,
                expiresAtMs = expiresAt
            )
        )
    }

    suspend fun deleteLongTermMemory(id: Long) {
        longTermDao.deleteById(id)
    }

    suspend fun purgeExpiredLongTerm() {
        longTermDao.purgeExpired(System.currentTimeMillis())
    }

    suspend fun indexKnowledgeDocument(
        title: String,
        sourceLabel: String,
        content: String,
        languageCode: String
    ) {
        knowledgeDao.insertDocument(
            KnowledgeDocumentEntity(
                title = title.trim(),
                sourceLabel = sourceLabel.trim().ifBlank { "user-notes" },
                content = content.trim(),
                languageCode = languageCode,
                trustBoundary = "UNTRUSTED_RETRIEVED_CONTEXT"
            )
        )
    }

    suspend fun deleteKnowledgeDocument(id: Long) {
        knowledgeDao.deleteDocumentById(id)
    }

    suspend fun searchKnowledge(
        query: String,
        userId: String = "local-researcher",
        topK: Int = 3
    ): List<KnowledgeSearchHit> {
        val docs = knowledgeDao.getAllDocumentsOnce(userId)
        if (docs.isEmpty() || query.isBlank()) return emptyList()

        val queryVec = vectorize(query)
        return docs.map { doc ->
            val docVec = vectorize("${doc.title} ${doc.content}")
            val sim = cosineSimilarity(queryVec, docVec)
            KnowledgeSearchHit(
                document = doc,
                similarityScore = sim
            )
        }
            .filter { it.similarityScore > 0.08 }
            .sortedByDescending { it.similarityScore }
            .take(topK)
    }

    suspend fun persistAuditLog(log: GenixEventLog) {
        auditLogDao.insertLog(
            AuditLogEntity(
                component = log.component,
                severity = log.severity.name,
                message = log.message,
                metadataJson = log.metadataJson,
                timestampMs = log.timestampMs
            )
        )
    }

    suspend fun clearAuditLogs() {
        auditLogDao.clearAll()
    }

    suspend fun seedInitialFoundationDataIfEmpty() {
        val existingDocs = knowledgeDao.getAllDocumentsOnce("local-researcher")
        if (existingDocs.isEmpty()) {
            knowledgeDao.insertDocument(
                KnowledgeDocumentEntity(
                    title = "GENIX Foundation Architecture Spec",
                    sourceLabel = "genix/docs/foundation.md",
                    content = "GENIX AI is an independent AI platform with Core Engine, Language, Reasoning, Coding, Planning engines, Model Router, 3-layer Memory System, and GENIX Base Phase A Unicode Tokenizer.",
                    languageCode = "en"
                )
            )
            knowledgeDao.insertDocument(
                KnowledgeDocumentEntity(
                    title = "GENIX Çok Dilli Sistem İlkeleri",
                    sourceLabel = "genix/docs/multilingual_tr.md",
                    content = "GENIX AI kullanıcının mesaj dilini ticari API olmadan otomatik algılar: Türkçe, İngilizce, Almanca, Fransızca, İspanyolca, Arapça, Japonca ve Çince desteklenir.",
                    languageCode = "tr"
                )
            )
            longTermDao.insertOrUpdate(
                LongTermMemoryEntity(
                    category = "architecture",
                    keyName = "inference_independence",
                    valueText = "Zero mandatory dependency on commercial third-party AI APIs.",
                    userApproved = true
                )
            )
        }
    }

    fun vectorize(text: String): Map<String, Double> {
        val normalized = text.lowercase(Locale.ROOT).trim()
        val counts = mutableMapOf<String, Double>()

        // Word tokens
        val words = normalized.split(Regex("[^\\p{L}0-9_]+")).filter { it.length >= 2 }
        for (w in words) {
            counts[w] = (counts[w] ?: 0.0) + 2.0
        }

        // Character 3-grams (great for Turkish agglutinative morphology & multilingual matching)
        val padded = " $normalized "
        for (i in 0..(padded.length - 3)) {
            val gram = padded.substring(i, i + 3)
            if (gram.isNotBlank()) {
                counts["g:$gram"] = (counts["g:$gram"] ?: 0.0) + 1.0
            }
        }
        return counts
    }

    fun cosineSimilarity(a: Map<String, Double>, b: Map<String, Double>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        var dot = 0.0
        for ((k, v) in a) {
            val bv = b[k] ?: continue
            dot += v * bv
        }
        val normA = sqrt(a.values.sumOf { it * it })
        val normB = sqrt(b.values.sumOf { it * it })
        return if (normA == 0.0 || normB == 0.0) 0.0 else dot / (normA * normB)
    }
}
