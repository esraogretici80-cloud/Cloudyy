package com.example.genix.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.genix.voice.CloudyVoicePersona
import com.example.genix.voice.VoiceApiProvider
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.genixDataStore: DataStore<Preferences> by preferencesDataStore(name = "cloudy_config")

enum class ResponseStyle(
    val id: String,
    val labelEn: String,
    val labelTr: String,
    val promptDirective: String
) {
    CONCISE(
        id = "CONCISE",
        labelEn = "Concise",
        labelTr = "Öz & Net",
        promptDirective = "Be concise, high-signal, and direct without unnecessary filler."
    ),
    BALANCED(
        id = "BALANCED",
        labelEn = "Balanced",
        labelTr = "Dengeli",
        promptDirective = "Provide a clear, well-structured, balanced explanation with helpful examples."
    ),
    DETAILED(
        id = "DETAILED",
        labelEn = "Detailed",
        labelTr = "Detaylı",
        promptDirective = "Provide thorough, comprehensive analysis with step-by-step reasoning and edge cases."
    );

    companion object {
        fun fromId(raw: String?): ResponseStyle =
            entries.firstOrNull { it.id.equals(raw, ignoreCase = true) } ?: BALANCED
    }
}

data class GenixConfig(
    val executionMode: ExecutionMode = ExecutionMode.LOCAL_CPU_FOUNDATION,
    val controlPlaneUrl: String = "http://10.0.2.2:8000",
    val preferredLanguageCode: String = "system",
    val countryCode: String = "TR",
    val strictVerification: Boolean = true,
    val cpuOnlySafeMode: Boolean = true,
    val maxContextTokens: Int = 4096,
    val themeMode: AppThemeMode = AppThemeMode.LIGHT_WHITE,
    val proCrystalUnlocked: Boolean = false,
    val subscriptionPlan: SubscriptionPlan = SubscriptionPlan.FREE,
    val voiceProfileId: String = CloudyVoicePersona.AOEDE.id,
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val autoSpeakLiveReplies: Boolean = true,
    val customVoiceApiProvider: String = VoiceApiProvider.CUSTOM_HTTP.id,
    val customVoiceApiUrl: String = "",
    val customVoiceApiKey: String = "",
    val customVoiceId: String = "nova",
    val autoRouteEnabled: Boolean = false,
    val responseStyle: ResponseStyle = ResponseStyle.BALANCED,
    val customInstructions: String = "",
    val hapticsEnabled: Boolean = true,
    val streamAnimationEnabled: Boolean = true,
    val activePlatformModelId: String = "cloudy-1.1-neo"
) {
    val darkTheme: Boolean
        get() = themeMode == AppThemeMode.DARK_OBSIDIAN
}

class GenixConfigRepository(private val context: Context) {

    private object Keys {
        val EXECUTION_MODE = stringPreferencesKey("execution_mode")
        val CONTROL_PLANE_URL = stringPreferencesKey("control_plane_url")
        val PREFERRED_LANGUAGE = stringPreferencesKey("preferred_language")
        val COUNTRY_CODE = stringPreferencesKey("country_code")
        val STRICT_VERIFICATION = booleanPreferencesKey("strict_verification")
        val CPU_ONLY_SAFE_MODE = booleanPreferencesKey("cpu_only_safe_mode")
        val MAX_CONTEXT_TOKENS = intPreferencesKey("max_context_tokens")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DARK_THEME_LEGACY = booleanPreferencesKey("dark_theme")
        val PRO_CRYSTAL_UNLOCKED = booleanPreferencesKey("pro_crystal_unlocked")
        val SUBSCRIPTION_PLAN = stringPreferencesKey("subscription_plan")
        val VOICE_PROFILE_ID = stringPreferencesKey("voice_profile_id")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val AUTO_SPEAK_LIVE = booleanPreferencesKey("auto_speak_live")
        val CUSTOM_VOICE_PROVIDER = stringPreferencesKey("custom_voice_provider")
        val CUSTOM_VOICE_URL = stringPreferencesKey("custom_voice_url")
        val CUSTOM_VOICE_KEY = stringPreferencesKey("custom_voice_key")
        val CUSTOM_VOICE_ID = stringPreferencesKey("custom_voice_id")
        val AUTO_ROUTE_ENABLED = booleanPreferencesKey("auto_route_enabled")
        val RESPONSE_STYLE = stringPreferencesKey("response_style")
        val CUSTOM_INSTRUCTIONS = stringPreferencesKey("custom_instructions")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val STREAM_ANIMATION_ENABLED = booleanPreferencesKey("stream_animation_enabled")
        val ACTIVE_PLATFORM_MODEL_ID = stringPreferencesKey("active_platform_model_id")
    }

    val configFlow: Flow<GenixConfig> = context.genixDataStore.data.map { prefs ->
        val mode = prefs[Keys.EXECUTION_MODE]?.let {
            runCatching { ExecutionMode.valueOf(it) }.getOrNull()
        } ?: ExecutionMode.LOCAL_CPU_FOUNDATION

        val savedTheme = prefs[Keys.THEME_MODE]?.let { AppThemeMode.fromId(it) }
            ?: if (prefs[Keys.DARK_THEME_LEGACY] == true) AppThemeMode.DARK_OBSIDIAN else AppThemeMode.LIGHT_WHITE

        val plan = SubscriptionPlan.fromId(prefs[Keys.SUBSCRIPTION_PLAN])
        val proUnlocked = (prefs[Keys.PRO_CRYSTAL_UNLOCKED] ?: false) || plan.rank >= SubscriptionPlan.PRO.rank

        GenixConfig(
            executionMode = mode,
            controlPlaneUrl = prefs[Keys.CONTROL_PLANE_URL] ?: "http://10.0.2.2:8000",
            preferredLanguageCode = prefs[Keys.PREFERRED_LANGUAGE] ?: "system",
            countryCode = prefs[Keys.COUNTRY_CODE] ?: "TR",
            strictVerification = prefs[Keys.STRICT_VERIFICATION] ?: true,
            cpuOnlySafeMode = prefs[Keys.CPU_ONLY_SAFE_MODE] ?: true,
            maxContextTokens = prefs[Keys.MAX_CONTEXT_TOKENS] ?: 4096,
            themeMode = savedTheme,
            proCrystalUnlocked = proUnlocked,
            subscriptionPlan = plan,
            voiceProfileId = prefs[Keys.VOICE_PROFILE_ID] ?: CloudyVoicePersona.AOEDE.id,
            voiceSpeed = prefs[Keys.VOICE_SPEED] ?: 1.0f,
            voicePitch = prefs[Keys.VOICE_PITCH] ?: 1.0f,
            autoSpeakLiveReplies = prefs[Keys.AUTO_SPEAK_LIVE] ?: true,
            customVoiceApiProvider = prefs[Keys.CUSTOM_VOICE_PROVIDER] ?: VoiceApiProvider.CUSTOM_HTTP.id,
            customVoiceApiUrl = prefs[Keys.CUSTOM_VOICE_URL] ?: "",
            customVoiceApiKey = prefs[Keys.CUSTOM_VOICE_KEY] ?: "",
            customVoiceId = prefs[Keys.CUSTOM_VOICE_ID] ?: "nova",
            autoRouteEnabled = prefs[Keys.AUTO_ROUTE_ENABLED] ?: false,
            responseStyle = ResponseStyle.fromId(prefs[Keys.RESPONSE_STYLE]),
            customInstructions = prefs[Keys.CUSTOM_INSTRUCTIONS] ?: "",
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
            streamAnimationEnabled = prefs[Keys.STREAM_ANIMATION_ENABLED] ?: true,
            activePlatformModelId = prefs[Keys.ACTIVE_PLATFORM_MODEL_ID] ?: "cloudy-1.1-neo"
        )
    }

    suspend fun updateExecutionMode(mode: ExecutionMode) {
        context.genixDataStore.edit { it[Keys.EXECUTION_MODE] = mode.name }
    }

    suspend fun updateControlPlaneUrl(url: String) {
        context.genixDataStore.edit { it[Keys.CONTROL_PLANE_URL] = url.trim().trimEnd('/') }
    }

    suspend fun updatePreferredLanguage(code: String) {
        context.genixDataStore.edit { it[Keys.PREFERRED_LANGUAGE] = code }
    }

    suspend fun updateCountryCode(countryCode: String) {
        context.genixDataStore.edit { it[Keys.COUNTRY_CODE] = countryCode }
    }

    suspend fun updateStrictVerification(enabled: Boolean) {
        context.genixDataStore.edit { it[Keys.STRICT_VERIFICATION] = enabled }
    }

    suspend fun updateThemeMode(mode: AppThemeMode) {
        context.genixDataStore.edit {
            it[Keys.THEME_MODE] = mode.id
            it[Keys.DARK_THEME_LEGACY] = (mode == AppThemeMode.DARK_OBSIDIAN)
            if (mode == AppThemeMode.ICE_CRYSTAL_PRO) {
                it[Keys.PRO_CRYSTAL_UNLOCKED] = true
                val currentPlan = SubscriptionPlan.fromId(it[Keys.SUBSCRIPTION_PLAN])
                if (currentPlan == SubscriptionPlan.FREE) {
                    it[Keys.SUBSCRIPTION_PLAN] = SubscriptionPlan.PRO.id
                }
            }
        }
    }

    suspend fun updateSubscriptionPlan(plan: SubscriptionPlan) {
        context.genixDataStore.edit {
            it[Keys.SUBSCRIPTION_PLAN] = plan.id
            it[Keys.PRO_CRYSTAL_UNLOCKED] = plan.rank >= SubscriptionPlan.PRO.rank
        }
    }

    suspend fun updateVoiceProfile(profileId: String) {
        context.genixDataStore.edit { it[Keys.VOICE_PROFILE_ID] = profileId }
    }

    suspend fun updateVoiceTuning(speed: Float, pitch: Float, autoSpeak: Boolean) {
        context.genixDataStore.edit {
            it[Keys.VOICE_SPEED] = speed.coerceIn(0.65f, 1.65f)
            it[Keys.VOICE_PITCH] = pitch.coerceIn(0.75f, 1.45f)
            it[Keys.AUTO_SPEAK_LIVE] = autoSpeak
        }
    }

    suspend fun updateCustomVoiceApi(
        providerId: String,
        url: String,
        apiKey: String,
        voiceId: String
    ) {
        context.genixDataStore.edit {
            it[Keys.CUSTOM_VOICE_PROVIDER] = providerId
            it[Keys.CUSTOM_VOICE_URL] = url.trim()
            it[Keys.CUSTOM_VOICE_KEY] = apiKey.trim()
            it[Keys.CUSTOM_VOICE_ID] = voiceId.trim().ifBlank { "nova" }
        }
    }

    suspend fun updatePersonalization(style: ResponseStyle, customInstructions: String) {
        context.genixDataStore.edit {
            it[Keys.RESPONSE_STYLE] = style.id
            it[Keys.CUSTOM_INSTRUCTIONS] = customInstructions.trim().take(2000)
        }
    }

    suspend fun updatePersonalization(
        autoRouteEnabled: Boolean,
        responseStyle: ResponseStyle,
        customInstructions: String,
        hapticsEnabled: Boolean,
        streamAnimationEnabled: Boolean
    ) {
        context.genixDataStore.edit {
            it[Keys.AUTO_ROUTE_ENABLED] = autoRouteEnabled
            it[Keys.RESPONSE_STYLE] = responseStyle.id
            it[Keys.CUSTOM_INSTRUCTIONS] = customInstructions.trim().take(2000)
            it[Keys.HAPTICS_ENABLED] = hapticsEnabled
            it[Keys.STREAM_ANIMATION_ENABLED] = streamAnimationEnabled
        }
    }

    suspend fun updateAutoRouteEnabled(enabled: Boolean) {
        context.genixDataStore.edit { it[Keys.AUTO_ROUTE_ENABLED] = enabled }
    }

    suspend fun updateActivePlatformModelId(modelId: String) {
        context.genixDataStore.edit { it[Keys.ACTIVE_PLATFORM_MODEL_ID] = modelId.trim().take(80) }
    }

    suspend fun updateHapticsAndStream(haptics: Boolean, streamAnimation: Boolean) {
        context.genixDataStore.edit {
            it[Keys.HAPTICS_ENABLED] = haptics
            it[Keys.STREAM_ANIMATION_ENABLED] = streamAnimation
        }
    }
}
